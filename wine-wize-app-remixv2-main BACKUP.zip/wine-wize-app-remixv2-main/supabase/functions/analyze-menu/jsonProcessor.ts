
export function cleanJsonResponse(text: string): string {
  // More aggressive cleaning for JSON responses
  let cleaned = text.trim();
  
  // Remove markdown code block formatting
  cleaned = cleaned.replace(/^```(?:json)?\s*/i, '');
  cleaned = cleaned.replace(/\s*```\s*$/i, '');
  
  // Remove any leading/trailing text that isn't JSON
  const jsonStart = cleaned.indexOf('{');
  const jsonEnd = cleaned.lastIndexOf('}');
  
  if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
    cleaned = cleaned.substring(jsonStart, jsonEnd + 1);
  }
  
  return cleaned.trim();
}

export function validateAndRepairJson(jsonString: string): string {
  let repaired = jsonString;
  
  // Enhanced bracket counting for better repair
  const openBrackets = (repaired.match(/\{/g) || []).length;
  const closeBrackets = (repaired.match(/\}/g) || []).length;
  const openArrays = (repaired.match(/\[/g) || []).length;
  const closeArrays = (repaired.match(/\]/g) || []).length;
  
  console.log(`JSON validation - Open brackets: ${openBrackets}, Close brackets: ${closeBrackets}`);
  console.log(`JSON validation - Open arrays: ${openArrays}, Close arrays: ${closeArrays}`);
  
  // If JSON appears truncated, attempt sophisticated repair
  if (openBrackets > closeBrackets || openArrays > closeArrays) {
    console.log('Detected truncated JSON, attempting advanced repair...');
    
    // Find the last complete item in the array
    const lastCompletePattern = /\}\s*(?:,\s*)?$/;
    const lastCompleteMatch = repaired.match(lastCompletePattern);
    
    if (lastCompleteMatch) {
      // Truncate at the last complete item
      const truncateIndex = lastCompleteMatch.index! + lastCompleteMatch[0].length;
      repaired = repaired.substring(0, truncateIndex);
      
      // Remove trailing comma if present
      repaired = repaired.replace(/,\s*$/, '');
    } else {
      // Find the last complete closing brace
      const lastValidBrace = repaired.lastIndexOf('"}');
      if (lastValidBrace !== -1) {
        repaired = repaired.substring(0, lastValidBrace + 2);
      }
    }
    
    // Recount after truncation
    const newOpenBrackets = (repaired.match(/\{/g) || []).length;
    const newCloseBrackets = (repaired.match(/\}/g) || []).length;
    const newOpenArrays = (repaired.match(/\[/g) || []).length;
    const newCloseArrays = (repaired.match(/\]/g) || []).length;
    
    // Close arrays first, then objects
    const arrayDiff = newOpenArrays - newCloseArrays;
    const bracketDiff = newOpenBrackets - newCloseBrackets;
    
    for (let i = 0; i < arrayDiff; i++) {
      repaired += ']';
    }
    for (let i = 0; i < bracketDiff; i++) {
      repaired += '}';
    }
    
    console.log('Advanced JSON repair completed');
  }
  
  return repaired;
}

export function parseAnalysisResult(analysisResult: string, analysisType: string, chunkIndex: number) {
  console.log(`Processing ${analysisType} analysis result (chunk ${chunkIndex + 1}) - Length: ${analysisResult.length} characters`);
  
  try {
    const cleanedResult = cleanJsonResponse(analysisResult);
    console.log(`Cleaned ${analysisType} result (chunk ${chunkIndex + 1}) - Length: ${cleanedResult.length} characters`);
    
    const repairedResult = validateAndRepairJson(cleanedResult);
    if (repairedResult !== cleanedResult) {
      console.log(`Applied advanced JSON repair for ${analysisType} chunk ${chunkIndex + 1}`);
    }
    
    const parsed = JSON.parse(repairedResult);
    
    // Validate the response structure
    const itemKey = analysisType === 'menu' ? 'menuItems' : 'wines';
    if (!parsed[itemKey] || !Array.isArray(parsed[itemKey])) {
      throw new Error(`Invalid response structure: missing ${itemKey} array`);
    }
    
    // Log detailed extraction results
    const itemCount = parsed[itemKey].length;
    console.log(`Successfully extracted ${itemCount} ${analysisType} items from chunk ${chunkIndex + 1}`);
    
    // Log extraction summary if available
    if (parsed.extractionSummary) {
      console.log(`Extraction summary for chunk ${chunkIndex + 1}:`, parsed.extractionSummary);
      
      // Validate completeness
      const confidence = parsed.extractionSummary.completionConfidence;
      if (typeof confidence === 'string' && confidence.includes('%')) {
        const percentage = parseInt(confidence);
        if (percentage < 95) {
          console.warn(`Low completion confidence (${confidence}) for chunk ${chunkIndex + 1}`);
        }
      }
    }
    
    return parsed;
  } catch (parseError) {
    console.error(`Critical JSON parsing failure for ${analysisType} chunk ${chunkIndex + 1}:`, parseError);
    console.error('Raw response preview (first 500 chars):', analysisResult.substring(0, 500));
    console.error('Raw response preview (last 500 chars):', analysisResult.substring(Math.max(0, analysisResult.length - 500)));
    
    // Enhanced fallback extraction
    try {
      console.log(`Attempting emergency fallback extraction for chunk ${chunkIndex + 1}`);
      
      const itemType = analysisType === 'menu' ? 'menuItems' : 'wines';
      
      // Try to find any valid JSON objects in the response
      const objectMatches = analysisResult.match(/\{[^{}]*"(?:dishName|name)"[^{}]*\}/g);
      
      if (objectMatches && objectMatches.length > 0) {
        console.log(`Found ${objectMatches.length} potential items in fallback extraction`);
        
        const fallbackItems = [];
        for (const match of objectMatches) {
          try {
            const item = JSON.parse(match);
            fallbackItems.push(item);
          } catch (itemError) {
            console.warn('Failed to parse individual item:', match);
          }
        }
        
        if (fallbackItems.length > 0) {
          console.log(`Emergency fallback succeeded: extracted ${fallbackItems.length} items from chunk ${chunkIndex + 1}`);
          return {
            [itemType]: fallbackItems,
            extractionSummary: {
              [`total${analysisType === 'menu' ? 'Items' : 'Wines'}Found`]: fallbackItems.length,
              [`${analysisType === 'menu' ? 'sections' : 'categories'}Processed`]: ['emergency_fallback'],
              completionConfidence: "partial - emergency extraction"
            }
          };
        }
      }
    } catch (fallbackError) {
      console.error(`Emergency fallback also failed for chunk ${chunkIndex + 1}:`, fallbackError);
    }
    
    throw new Error(`Complete failure to parse ${analysisType} analysis result for chunk ${chunkIndex + 1}: ${parseError.message}`);
  }
}
