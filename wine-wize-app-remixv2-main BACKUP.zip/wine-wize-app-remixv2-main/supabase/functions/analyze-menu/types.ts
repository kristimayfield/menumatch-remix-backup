
export interface Restaurant {
  id?: string;
  name: string;
  address?: string;
  cuisine_type?: string;
}

export interface MenuItem {
  dishName: string;
  description?: string;
  price?: string;
  ingredients?: string[];
  dishType?: string;
  restaurantName?: string;
  restaurantAddress?: string;
  restaurantCuisine?: string;
}

export interface Wine {
  name: string;
  vintage?: string;
  varietal?: string;
  region?: string;
  price_bottle?: string;
  price_glass?: string;
  wineType?: string;
  wineStyle?: string;
  description?: string;
}
