
export interface TransactionResult {
  savedMenuCount: number;
  savedWineCount: number;
  actualMenuCount: number;
  actualWineCount: number;
}

export async function executeDataTransaction(
  preparedMenuItems: any[],
  preparedWines: any[],
  restaurantId: string,
  supabaseClient: any
): Promise<TransactionResult> {
  console.log('=== STARTING DATABASE TRANSACTION ===');

  // Clear existing data for this restaurant
  console.log('Clearing existing restaurant data...');
  
  if (preparedMenuItems.length > 0) {
    const { error: clearMenuError } = await supabaseClient
      .from('restaurant_menus')
      .delete()
      .eq('restaurant_id', restaurantId);
    
    if (clearMenuError) {
      throw new Error(`Failed to clear existing menu items: ${clearMenuError.message}`);
    }
    console.log('✓ Existing menu items cleared successfully');
  }

  if (preparedWines.length > 0) {
    const { error: clearWineError } = await supabaseClient
      .from('restaurant_wines')
      .delete()
      .eq('restaurant_id', restaurantId);
    
    if (clearWineError) {
      throw new Error(`Failed to clear existing wines: ${clearWineError.message}`);
    }
    console.log('✓ Existing wines cleared successfully');
  }

  // Save menu items with enhanced error handling
  let savedMenuCount = 0;
  if (preparedMenuItems.length > 0) {
    console.log(`Inserting ${preparedMenuItems.length} menu items...`);
    
    const { data: menuInsertData, error: menuInsertError } = await supabaseClient
      .from('restaurant_menus')
      .insert(preparedMenuItems)
      .select();

    if (menuInsertError) {
      console.error('Menu insert error details:', JSON.stringify(menuInsertError, null, 2));
      throw new Error(`Failed to insert menu items: ${menuInsertError.message}`);
    }

    savedMenuCount = menuInsertData?.length || 0;
    
    if (savedMenuCount !== preparedMenuItems.length) {
      throw new Error(`Menu save count mismatch: prepared ${preparedMenuItems.length}, saved ${savedMenuCount}`);
    }
    
    console.log(`✓ Successfully saved ${savedMenuCount} menu items`);
  }

  // Save wines with enhanced error handling
  let savedWineCount = 0;
  if (preparedWines.length > 0) {
    console.log(`Inserting ${preparedWines.length} wines...`);
    
    const { data: wineInsertData, error: wineInsertError } = await supabaseClient
      .from('restaurant_wines')
      .insert(preparedWines)
      .select();

    if (wineInsertError) {
      console.error('Wine insert error details:', JSON.stringify(wineInsertError, null, 2));
      throw new Error(`Failed to insert wines: ${wineInsertError.message}`);
    }

    savedWineCount = wineInsertData?.length || 0;
    
    if (savedWineCount !== preparedWines.length) {
      throw new Error(`Wine save count mismatch: prepared ${preparedWines.length}, saved ${savedWineCount}`);
    }
    
    console.log(`✓ Successfully saved ${savedWineCount} wines`);
  }

  // Enhanced verification strategy - immediate post-save verification
  console.log('=== PERFORMING IMMEDIATE POST-SAVE VERIFICATION ===');
  
  const { data: verifyMenus, error: verifyMenuError } = await supabaseClient
    .from('restaurant_menus')
    .select('id, dish_name')
    .eq('restaurant_id', restaurantId);

  const { data: verifyWines, error: verifyWineError } = await supabaseClient
    .from('restaurant_wines')
    .select('id, name')
    .eq('restaurant_id', restaurantId);

  if (verifyMenuError || verifyWineError) {
    throw new Error(`Post-save verification failed: ${verifyMenuError?.message || verifyWineError?.message}`);
  }

  const actualMenuCount = verifyMenus?.length || 0;
  const actualWineCount = verifyWines?.length || 0;

  console.log(`VERIFICATION RESULTS: Found ${actualMenuCount} menu items and ${actualWineCount} wines in database`);

  // Strict verification - must match what we intended to save
  if (preparedMenuItems.length > 0 && actualMenuCount !== savedMenuCount) {
    throw new Error(`Verification failed: Expected ${savedMenuCount} menu items, found ${actualMenuCount}`);
  }
  
  if (preparedWines.length > 0 && actualWineCount !== savedWineCount) {
    throw new Error(`Verification failed: Expected ${savedWineCount} wines, found ${actualWineCount}`);
  }

  // Log sample saved data for debugging
  if (actualMenuCount > 0) {
    console.log('Sample saved menu items:', verifyMenus.slice(0, 3).map(item => item.dish_name));
  }
  if (actualWineCount > 0) {
    console.log('Sample saved wines:', verifyWines.slice(0, 3).map(item => item.name));
  }

  return {
    savedMenuCount,
    savedWineCount,
    actualMenuCount,
    actualWineCount
  };
}
