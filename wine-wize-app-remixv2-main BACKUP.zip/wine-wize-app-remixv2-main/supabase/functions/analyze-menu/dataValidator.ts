
import { 
  deduplicateMenuItems, 
  deduplicateWines, 
  prepareRestaurantMenuItems,
  prepareRestaurantWines
} from './dataProcessor.ts';

export interface ValidationResult {
  uniqueMenuItems: any[];
  uniqueWines: any[];
  preparedMenuItems: any[];
  preparedWines: any[];
}

export function validateAndPrepareData(
  menuItems: any[],
  wines: any[],
  restaurantId: string
): ValidationResult {
  console.log('Raw menu items sample:', JSON.stringify(menuItems.slice(0, 2), null, 2));
  console.log('Raw wines sample:', JSON.stringify(wines.slice(0, 2), null, 2));

  // Enhanced deduplication with logging
  const uniqueMenuItems = deduplicateMenuItems(menuItems);
  const uniqueWines = deduplicateWines(wines);

  console.log(`After deduplication: ${uniqueMenuItems.length} unique menu items, ${uniqueWines.length} unique wines`);

  if (uniqueMenuItems.length === 0 && uniqueWines.length === 0) {
    throw new Error('CRITICAL: No valid menu items or wines found after deduplication');
  }

  // Prepare and validate data before transaction
  let preparedMenuItems: any[] = [];
  let preparedWines: any[] = [];
  
  if (uniqueMenuItems.length > 0) {
    console.log('Preparing menu items for database insertion...');
    preparedMenuItems = prepareRestaurantMenuItems(uniqueMenuItems, restaurantId);
    console.log(`Prepared ${preparedMenuItems.length} menu items`);
    console.log('Sample prepared menu item:', JSON.stringify(preparedMenuItems[0], null, 2));
    
    // Validate prepared menu items
    for (let i = 0; i < preparedMenuItems.length; i++) {
      const item = preparedMenuItems[i];
      if (!item.restaurant_id || !item.dish_name) {
        throw new Error(`Invalid menu item at index ${i}: missing required fields restaurant_id or dish_name`);
      }
    }
    console.log('✓ All menu items validated successfully');
  }
  
  if (uniqueWines.length > 0) {
    console.log('Preparing wines for database insertion...');
    preparedWines = prepareRestaurantWines(uniqueWines, restaurantId);
    console.log(`Prepared ${preparedWines.length} wines`);
    console.log('Sample prepared wine:', JSON.stringify(preparedWines[0], null, 2));
    
    // Validate prepared wines
    for (let i = 0; i < preparedWines.length; i++) {
      const wine = preparedWines[i];
      if (!wine.restaurant_id || !wine.name) {
        throw new Error(`Invalid wine at index ${i}: missing required fields restaurant_id or name`);
      }
    }
    console.log('✓ All wines validated successfully');
  }

  return {
    uniqueMenuItems,
    uniqueWines,
    preparedMenuItems,
    preparedWines
  };
}
