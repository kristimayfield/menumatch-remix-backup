
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

export function createSuccessResponse(data: any) {
  console.log(`=== ANALYSIS COMPLETE ===`);
  console.log(`Results: ${data.menuItems?.length || 0} dishes, ${data.wines?.length || 0} wines for restaurant: ${data.restaurantName} (${data.restaurantId})`);

  // Only return success if we actually have data OR if both input arrays were empty
  const hasValidData = (data.menuItems && data.menuItems.length > 0) || 
                      (data.wines && data.wines.length > 0);

  if (!hasValidData) {
    console.error('ERROR: Attempting to return success response with no data');
    throw new Error('Cannot return success response: No menu items or wines were saved');
  }

  // Ensure we always return valid data structure
  const responseData = {
    success: true,
    menuItems: data.menuItems || [],
    wines: data.wines || [],
    restaurantId: data.restaurantId,
    restaurantName: data.restaurantName,
    extractionStats: data.extractionStats || {
      menuImagesProcessed: 0,
      wineImagesProcessed: 0,
      totalMenuItems: data.menuItems?.length || 0,
      totalWines: data.wines?.length || 0,
      processingTime: new Date().toISOString()
    }
  };

  console.log('Returning success response with data:', {
    menuItems: responseData.menuItems.length,
    wines: responseData.wines.length,
    restaurantId: responseData.restaurantId
  });

  return new Response(
    JSON.stringify(responseData),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    }
  );
}

export function createErrorResponse(error: any) {
  console.error('=== CRITICAL ERROR IN ANALYZE-MENU FUNCTION ===');
  console.error('Error details:', error);
  console.error('Error stack:', error.stack);
  
  // Determine appropriate error response based on error type
  let statusCode = 500;
  let errorMessage = error.message || 'Unknown error occurred';
  
  if (errorMessage.includes('Authentication') || errorMessage.includes('Authorization')) {
    statusCode = 401;
  } else if (errorMessage.includes('Invalid request') || errorMessage.includes('required')) {
    statusCode = 400;
  } else if (errorMessage.includes('too large') || errorMessage.includes('Maximum')) {
    statusCode = 413;
  } else if (errorMessage.includes('timeout') || errorMessage.includes('Timeout')) {
    statusCode = 408;
  }

  // Remove partial success logic - if we error, we error completely
  return new Response(
    JSON.stringify({ 
      success: false, 
      error: errorMessage,
      details: 'Image processing system encountered an error',
      timestamp: new Date().toISOString(),
      menuItems: [],
      wines: [],
      restaurantId: null,
      restaurantName: null
    }),
    {
      status: statusCode,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    }
  );
}

export function createCorsResponse() {
  return new Response(null, { headers: corsHeaders });
}
