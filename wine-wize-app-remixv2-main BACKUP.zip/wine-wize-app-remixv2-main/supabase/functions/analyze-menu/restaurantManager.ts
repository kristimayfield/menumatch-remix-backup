
import { createOrFindRestaurant } from './dataProcessor.ts';

export async function createOrFindRestaurantWithValidation(
  restaurantName: string,
  supabaseClient: any,
  userId: string
): Promise<string> {
  console.log(`Creating/finding restaurant: "${restaurantName}" for user: ${userId}`);
  
  const restaurantId = await createOrFindRestaurant(restaurantName, supabaseClient, userId);
  
  if (!restaurantId) {
    throw new Error('Restaurant creation returned null/undefined ID');
  }
  
  console.log(`SUCCESS: Restaurant resolved with ID: ${restaurantId}`);
  
  // Verify restaurant exists in database
  const { data: restaurantCheck, error: restaurantCheckError } = await supabaseClient
    .from('restaurants')
    .select('id, name')
    .eq('id', restaurantId)
    .single();
    
  if (restaurantCheckError || !restaurantCheck) {
    throw new Error(`Restaurant verification failed: ${restaurantCheckError?.message || 'Restaurant not found after creation'}`);
  }
  
  console.log(`VERIFIED: Restaurant exists in database: ${restaurantCheck.name} (${restaurantCheck.id})`);
  
  return restaurantId;
}
