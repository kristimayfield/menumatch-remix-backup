
export async function authenticateUser(req: Request, supabaseClient: any) {
  console.log('=== AUTHENTICATION STARTED ===');
  
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) {
    throw new Error('Authorization header is required');
  }

  const token = authHeader.replace('Bearer ', '');
  if (!token) {
    throw new Error('Invalid authorization header format');
  }

  try {
    console.log('Attempting to authenticate with token...');
    
    const { data: { user: authUser }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError) {
      console.error('Authentication error:', authError);
      
      // Provide more specific error messages
      if (authError.message?.includes('expired') || authError.message?.includes('invalid')) {
        throw new Error('Your session has expired. Please log in again.');
      } else if (authError.message?.includes('malformed')) {
        throw new Error('Invalid authentication token. Please log in again.');
      } else {
        throw new Error(`Authentication failed: ${authError.message}`);
      }
    }

    if (!authUser) {
      throw new Error('No user found for the provided token. Please log in again.');
    }

    console.log('Authenticated user:', authUser.id);
    
    // Verify the user's profile exists
    try {
      const { data: profile, error: profileError } = await supabaseClient
        .from('profiles')
        .select('id, first_name, last_name, email')
        .eq('id', authUser.id)
        .maybeSingle();

      if (profileError) {
        console.error('Profile check error:', profileError);
        // Don't fail authentication for profile issues, just log
      } else if (!profile) {
        console.warn('No profile found for authenticated user:', authUser.id);
      } else {
        console.log('User profile verified:', profile.id);
      }
    } catch (profileError) {
      console.error('Error checking user profile:', profileError);
      // Don't fail authentication for profile check issues
    }

    return authUser;
  } catch (authError) {
    console.error('Authentication process failed:', authError);
    
    // Re-throw with appropriate error message
    if (authError.message) {
      throw authError;
    } else {
      throw new Error('Authentication failed. Please log in again.');
    }
  }
}
