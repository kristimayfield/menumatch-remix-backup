
import { createOrFindRestaurantWithValidation } from './restaurantManager.ts';
import { validateAndPrepareData } from './dataValidator.ts';
import { executeDataTransaction } from './databaseTransactions.ts';

export async function saveAnalysisResults(
  menuItems: any[],
  wines: any[],
  restaurantName: string,
  supabaseClient: any,
  userId: string
) {
  console.log(`=== STARTING ENHANCED DATABASE SAVE OPERATIONS ===`);
  console.log(`Input: ${menuItems.length} menu items, ${wines.length} wines for restaurant: ${restaurantName}`);
  console.log(`User ID: ${userId}`);
  
  try {
    // Phase 1: Restaurant creation with detailed error handling
    console.log('Phase 1: Creating/finding restaurant...');
    const restaurantId = await createOrFindRestaurantWithValidation(
      restaurantName, 
      supabaseClient, 
      userId
    );
    console.log(`Phase 1 completed: Restaurant ID = ${restaurantId}`);

    // Phase 2: Data validation and preparation
    console.log('Phase 2: Validating and preparing data...');
    const {
      uniqueMenuItems,
      uniqueWines,
      preparedMenuItems,
      preparedWines
    } = validateAndPrepareData(menuItems, wines, restaurantId);
    console.log(`Phase 2 completed: ${preparedMenuItems.length} menu items, ${preparedWines.length} wines prepared`);

    // Phase 3: Database transaction execution
    console.log('Phase 3: Executing database transaction...');
    const transactionResult = await executeDataTransaction(
      preparedMenuItems,
      preparedWines,
      restaurantId,
      supabaseClient
    );
    console.log(`Phase 3 completed: ${transactionResult.actualMenuCount} menu items, ${transactionResult.actualWineCount} wines saved`);

    console.log(`=== DATABASE SAVE OPERATIONS COMPLETED SUCCESSFULLY ===`);
    console.log(`Final verified counts: ${transactionResult.actualMenuCount} menu items, ${transactionResult.actualWineCount} wines saved for restaurant ${restaurantId}`);

    return {
      restaurantId,
      uniqueMenuItems: uniqueMenuItems.slice(0, transactionResult.actualMenuCount),
      uniqueWines: uniqueWines.slice(0, transactionResult.actualWineCount)
    };

  } catch (error) {
    console.error('=== CRITICAL DATABASE TRANSACTION FAILURE ===');
    console.error('Transaction error:', error);
    console.error('Error stack:', error.stack);
    console.error('Restaurant name:', restaurantName);
    console.error('User ID:', userId);
    console.error('Menu items count:', menuItems.length);
    console.error('Wines count:', wines.length);
    
    // Log sample data for debugging
    if (menuItems.length > 0) {
      console.error('Sample menu item:', JSON.stringify(menuItems[0], null, 2));
    }
    if (wines.length > 0) {
      console.error('Sample wine:', JSON.stringify(wines[0], null, 2));
    }
    
    // No partial success - if we fail, we fail completely
    throw new Error(`Complete database save failure for restaurant "${restaurantName}": ${error.message}`);
  }
}
