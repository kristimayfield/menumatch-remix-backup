
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import type { AnalysisRequest } from './types.ts';
import { analyzeImagesInParallel } from './parallelProcessor.ts';
import { findOrCreateRestaurant } from './restaurantManager.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const authenticateUser = async (req: Request, supabaseClient: any) => {
  console.log('=== FAST AUTHENTICATION ===');
  
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) {
    throw new Error('Authorization header is required');
  }

  const token = authHeader.replace('Bearer ', '');
  if (!token || token === authHeader) {
    throw new Error('Invalid authorization header format');
  }

  try {
    const { data: { user: authUser }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !authUser) {
      throw new Error('Authentication failed. Please log in again.');
    }

    console.log('Fast authentication successful for user:', authUser.id);
    return authUser;
  } catch (authError) {
    console.error('Authentication failed:', authError);
    throw new Error('Authentication failed. Please log in again.');
  }
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('=== OPTIMIZED FAST ANALYSIS STARTED ===');

    if (!Deno.env.get('OPENAI_API_KEY')) {
      throw new Error('Missing OPENAI_API_KEY');
    }

    const requestBody: AnalysisRequest = await req.json();
    const { images, menuCount, wineCount, restaurantName, sessionOnly } = requestBody;
    
    if (!images || !Array.isArray(images)) {
      throw new Error('Invalid images array');
    }
    
    console.log('OPTIMIZED processing request:', {
      imageCount: images.length,
      menuCount,
      wineCount,
      restaurantName,
      sessionOnly
    });

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const user = await authenticateUser(req, supabaseClient);

    const menuImages = images.slice(0, menuCount);
    const wineImages = images.slice(menuCount, menuCount + wineCount);
    
    console.log('OPTIMIZED image processing:', {
      menuImages: menuImages.length,
      wineImages: wineImages.length
    });

    // OPTIMIZED PARALLEL PROCESSING with enhanced extraction
    const analysisPromises = [];
    
    if (menuImages.length > 0) {
      console.log('Starting ENHANCED menu image analysis...');
      analysisPromises.push(analyzeImagesInParallel(menuImages, 'menu'));
    }
    
    if (wineImages.length > 0) {
      console.log('Starting ENHANCED wine image analysis...');
      analysisPromises.push(analyzeImagesInParallel(wineImages, 'wine'));
    }

    console.log('Processing with ENHANCED extraction prompts...');
    const results = await Promise.all(analysisPromises);

    let allMenuItems: any[] = [];
    let allWines: any[] = [];
    
    results.forEach((result) => {
      if (result.menuItems) {
        allMenuItems = allMenuItems.concat(result.menuItems);
      }
      if (result.wines) {
        allWines = allWines.concat(result.wines);
      }
    });

    console.log('ENHANCED extraction results:', {
      totalMenuItems: allMenuItems.length,
      totalWines: allWines.length
    });

    // Enhanced validation with detailed logging
    if (allMenuItems.length === 0 && allWines.length === 0) {
      console.error('CRITICAL: No items extracted from any images');
      return new Response(
        JSON.stringify({
          success: false,
          error: 'No menu items or wines were found in the uploaded images. Please ensure images show clear menu content.',
          extractionStats: {
            menuImagesProcessed: menuImages.length,
            wineImagesProcessed: wineImages.length,
            totalMenuItems: 0,
            totalWines: 0
          }
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // PERFORMANCE OPTIMIZATION: Skip restaurant operations for session-only mode
    let restaurantId = null;
    if (!sessionOnly) {
      try {
        console.log('Finding/creating restaurant for potential future save...');
        restaurantId = await findOrCreateRestaurant(restaurantName, supabaseClient, user.id);
      } catch (restaurantError) {
        console.warn('Restaurant resolution failed - will skip background save:', restaurantError.message);
      }
    } else {
      console.log('PERFORMANCE: Skipping restaurant operations - session only mode');
    }

    // Prepare optimized response data
    const responseData = {
      success: true,
      menuItems: allMenuItems,
      wines: allWines,
      restaurantName: restaurantName,
      restaurantId: restaurantId,
      sessionOnly: sessionOnly || false,
      extractionStats: {
        menuImagesProcessed: menuImages.length,
        wineImagesProcessed: wineImages.length,
        totalMenuItems: allMenuItems.length,
        totalWines: allWines.length,
        processingTime: new Date().toISOString()
      }
    };

    console.log('OPTIMIZED processing completed successfully');

    return new Response(JSON.stringify(responseData), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('OPTIMIZED analysis error:', error);
    
    const errorResponse = {
      success: false,
      error: error.message,
      timestamp: new Date().toISOString(),
      context: 'analyze-menu-fast-optimized'
    };
    
    let statusCode = 500;
    if (error.message?.includes('Authentication') || error.message?.includes('authorization')) {
      statusCode = 401;
    } else if (error.message?.includes('Invalid') || error.message?.includes('required')) {
      statusCode = 400;
    }
    
    return new Response(
      JSON.stringify(errorResponse),
      {
        status: statusCode,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
