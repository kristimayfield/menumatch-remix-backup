
import type { ExtractedData } from './types.ts';
import { analyzeImageChunk } from './imageProcessor.ts';

export async function analyzeImagesInParallel(images: string[], analysisType: string): Promise<ExtractedData> {
  console.log(`Starting parallel analysis of ${images.length} ${analysisType} images`);
  
  const analysisPromises = images.map(async (imageBase64: string, index: number) => {
    try {
      return await analyzeImageChunk(imageBase64, analysisType, index, images.length);
    } catch (error) {
      console.error(`Failed to analyze ${analysisType} image ${index + 1}:`, error);
      return {
        [analysisType === 'menu' ? 'menuItems' : 'wines']: [],
        extractionSummary: {
          [`total${analysisType === 'menu' ? 'Items' : 'Wines'}Found`]: 0,
          [`${analysisType === 'menu' ? 'sections' : 'categories'}Processed`]: [],
          completionConfidence: "0% - analysis failed",
          errorMessage: error.message
        }
      };
    }
  });
  
  const results = await Promise.all(analysisPromises);
  const combinedItems = results.flatMap(result => result.menuItems || result.wines || []);
  
  console.log(`Analysis complete for ${analysisType}: ${combinedItems.length} items extracted`);
  
  return {
    [analysisType === 'menu' ? 'menuItems' : 'wines']: combinedItems,
    totalExtracted: combinedItems.length,
    imageCount: images.length
  };
}
