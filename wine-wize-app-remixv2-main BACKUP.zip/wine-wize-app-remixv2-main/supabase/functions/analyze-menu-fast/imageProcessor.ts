
import type { AnalysisResult } from './types.ts';
import { menuAnalysisPrompt, wineAnalysisPrompt } from './prompts.ts';

export function extractBase64FromDataUrl(dataUrl: string): string {
  if (dataUrl.startsWith('data:')) {
    const base64Index = dataUrl.indexOf(',');
    if (base64Index !== -1) {
      return dataUrl.substring(base64Index + 1);
    }
  }
  return dataUrl;
}

export async function analyzeImageChunk(imageBase64: string, analysisType: string, chunkIndex: number = 0, totalChunks: number = 1): Promise<AnalysisResult> {
  const basePrompt = analysisType === 'wine' ? wineAnalysisPrompt : menuAnalysisPrompt;
  
  let prompt = basePrompt;
  if (totalChunks > 1) {
    prompt += `\n\nCRITICAL: This is chunk ${chunkIndex + 1} of ${totalChunks}. Extract EVERY visible item from this section.`;
  }
  
  console.log(`Starting FAST analysis for ${analysisType} chunk ${chunkIndex + 1}/${totalChunks}`);
  
  const cleanBase64 = extractBase64FromDataUrl(imageBase64);
  console.log(`Image data format: ${imageBase64.substring(0, 50)}...`);
  console.log(`Cleaned base64 length: ${cleanBase64.length}`);
  
  const requestPayload = {
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: prompt
          },
          {
            type: 'image_url',
            image_url: {
              url: `data:image/jpeg;base64,${cleanBase64}`,
              detail: 'high'
            }
          }
        ]
      }
    ],
    max_tokens: analysisType === 'wine' ? 3000 : 4000,
    temperature: 0.1,
    response_format: { "type": "json_object" }
  };

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestPayload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`OpenAI API error: ${response.status} - ${errorText}`);
    throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  
  if (data.choices[0].finish_reason === 'length') {
    console.warn(`${analysisType} response was truncated due to max_tokens limit`);
  }
  
  const analysisResult = data.choices[0].message.content;
  
  console.log(`Raw analysis result for ${analysisType}:`, analysisResult.substring(0, 500) + '...');
  
  try {
    let parsedResult = JSON.parse(analysisResult);
    
    if (analysisType === 'menu') {
      if (!parsedResult.menuItems) {
        console.warn('No menuItems array found, creating empty array');
        parsedResult.menuItems = [];
      }
      if (!Array.isArray(parsedResult.menuItems)) {
        console.warn('menuItems is not an array, converting');
        parsedResult.menuItems = [];
      }
      parsedResult.menuItems = parsedResult.menuItems.map((item: any) => ({
        id: crypto.randomUUID(),
        dish_name: item.dish_name || item.name || 'Unknown Dish',
        description: item.description || '',
        price: item.price || '',
        dish_type: item.dish_type || item.type || 'entree',
        ingredients: Array.isArray(item.ingredients) ? item.ingredients : []
      }));
    } else {
      if (!parsedResult.wines) {
        console.warn('No wines array found, creating empty array');
        parsedResult.wines = [];
      }
      if (!Array.isArray(parsedResult.wines)) {
        console.warn('wines is not an array, converting');
        parsedResult.wines = [];
      }
      parsedResult.wines = parsedResult.wines.map((wine: any) => ({
        id: crypto.randomUUID(),
        name: wine.name || 'Unknown Wine',
        vintage: wine.vintage || '',
        varietal: wine.varietal || '',
        region: wine.region || '',
        price_glass: wine.price_glass || '',
        price_bottle: wine.price_bottle || '',
        wine_type: wine.wine_type || '',
        wine_style: wine.wine_style || '',
        description: wine.description || ''
      }));
    }
    
    console.log(`Successfully parsed ${analysisType} result:`, {
      menuItems: parsedResult.menuItems?.length || 0,
      wines: parsedResult.wines?.length || 0
    });
    
    return parsedResult;
  } catch (parseError) {
    console.error(`JSON parsing failed for ${analysisType}:`, parseError.message);
    console.error(`Raw content that failed:`, analysisResult);
    
    if (analysisType === 'wine') {
      console.log('Attempting to recover partial wine data...');
      try {
        const wineMatches = analysisResult.match(/"name":\s*"([^"]+)"/g);
        
        if (wineMatches && wineMatches.length > 0) {
          console.log(`Found ${wineMatches.length} wine names in truncated response`);
          const recoveredWines = wineMatches.map((match: string, index: number) => {
            const name = match.match(/"name":\s*"([^"]+)"/)?.[1] || `Wine ${index + 1}`;
            return {
              id: crypto.randomUUID(),
              name: name,
              vintage: '',
              varietal: '',
              region: '',
              price_glass: '',
              price_bottle: '',
              wine_type: '',
              wine_style: '',
              description: 'Recovered from truncated response'
            };
          });
          
          return {
            wines: recoveredWines,
            extractionSummary: {
              totalWinesFound: recoveredWines.length,
              categoriesProcessed: ['recovered'],
              completionConfidence: "50% - recovered from truncated response",
              errorMessage: 'JSON truncated but recovered partial data'
            }
          };
        }
      } catch (recoveryError) {
        console.error('Failed to recover partial wine data:', recoveryError);
      }
    }
    
    if (analysisType === 'menu') {
      return {
        menuItems: [],
        extractionSummary: {
          totalItemsFound: 0,
          sectionsProcessed: [],
          completionConfidence: "0% - JSON parsing failed",
          errorMessage: parseError.message
        }
      };
    } else {
      return {
        wines: [],
        extractionSummary: {
          totalWinesFound: 0,
          categoriesProcessed: [],
          completionConfidence: "0% - JSON parsing failed",
          errorMessage: parseError.message
        }
      };
    }
  }
}
