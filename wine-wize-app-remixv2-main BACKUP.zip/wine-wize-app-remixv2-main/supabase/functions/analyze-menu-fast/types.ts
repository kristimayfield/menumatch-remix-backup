
export interface AnalysisRequest {
  images: string[];
  analysisType?: string;
  menuCount: number;
  wineCount: number;
  selectedWineTypes?: string[];
  budget?: number;
  restaurantName: string;
  restaurantId?: string;
  fastMode?: boolean;
  sessionOnly?: boolean; // New flag for session-only mode
}

export interface MenuItem {
  dish_name: string;
  description: string;
  price: string;
  dish_type: string;
  ingredients: string[];
}

export interface Wine {
  name: string;
  vintage: string;
  varietal: string;
  region: string;
  price_glass: string;
  price_bottle: string;
  wine_type: string;
  wine_style: string;
  description: string;
}

export interface AnalysisResult {
  menuItems: MenuItem[];
  wines: Wine[];
}
