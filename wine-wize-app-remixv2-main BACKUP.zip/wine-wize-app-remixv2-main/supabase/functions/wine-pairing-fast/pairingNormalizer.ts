
import { DishRecommendation, WineRecommendation, WineData } from './types.ts';
import { detectWineTypeFromName, mapToValidWineStyle, validateWinePairings } from './wineValidation.ts';

export const normalizePairings = (
  pairings: any[],
  formattedWines: WineData[]
): DishRecommendation[] => {
  console.log('Normalizing pairings:', pairings);
  
  let normalizedPairings = pairings.map((dishPairing, index) => {
    console.log(`Processing pairing ${index}:`, dishPairing);
    
    // Enhanced dish name extraction - handle multiple field variations
    const dishName = dishPairing.dish || 
                    dishPairing.dishName || 
                    dishPairing.name || 
                    dishPairing.dish_name ||
                    `Unknown Dish ${index + 1}`;
    
    // Log if we had to use fallback
    if (!dishPairing.dish && !dishPairing.dishName) {
      console.warn(`Using fallback dish name for index ${index}:`, dishName);
    }
    
    // Enhanced wine pairings extraction - handle multiple field variations
    let winePairings = dishPairing.pairings || 
                      dishPairing.wines || 
                      dishPairing.wine_pairings ||
                      dishPairing.recommendations ||
                      dishPairing.winePairings ||
                      [];

    if (!Array.isArray(winePairings)) {
      console.warn(`Invalid pairings structure for dish: ${dishName}. Expected array, got:`, typeof winePairings, winePairings);
      winePairings = [];
    }

    console.log(`Found ${winePairings.length} wine pairings for ${dishName}`);

    // Process wine pairings with post-processing style detection
    const normalizedWinePairings = winePairings.map((wine: any, wineIndex: number) => {
      console.log(`Processing wine ${wineIndex} for ${dishName}:`, wine);
      
      // Handle multiple field variations for wine name
      const wineName = wine.wineName || wine.name || wine.wine_name || wine.wine || `Unknown Wine ${wineIndex + 1}`;
      
      // Handle multiple field variations for wine type
      const wineType = wine.wineType || wine.wine_type || wine.type || detectWineTypeFromName(wineName);
      
      // Get pure description from OpenAI (no forced Wine Wize style)
      const originalDescription = wine.description || wine.pairing_description || wine.pairingDescription || 'Pairing details not available';
      
      // Detect Wine Wize style based on the description content
      const detectedWineStyle = mapToValidWineStyle('', wineType, wineName, originalDescription);
      
      console.log(`Wine style detection: ${wineName} -> Type: ${wineType}, Style: ${detectedWineStyle}`);

      // Enhanced price handling - ensure no generic symbols
      let finalPrice = wine.price || wine.wine_price || wine.winePrice || 'Price not listed';
      if (finalPrice === '$$' || finalPrice === '$' || finalPrice.includes('$$')) {
        // Find the wine in our formatted list to get the correct price
        const matchingWine = formattedWines.find(fw => 
          fw.name === wineName || fw.wine_name === wineName
        );
        finalPrice = matchingWine?.formattedPrice || 'Price not listed';
      }

      // Validate price format - if it's still generic, fix it
      if (finalPrice.includes('$$') || finalPrice === '$') {
        finalPrice = 'Price not listed';
      }

      // Handle confidence level variations
      const confidenceLevel = wine.confidenceLevel || wine.confidence || wine.confidence_level || 'Medium';

      return {
        wineName,
        wineType,
        wineStyle: detectedWineStyle,
        description: originalDescription, // Keep OpenAI's pure research-based description
        confidenceLevel,
        price: finalPrice
      } as WineRecommendation;
    });

    // Enhanced dish description and price extraction
    const dishDescription = dishPairing.dishDescription || 
                           dishPairing.description || 
                           dishPairing.dish_description || 
                           dishPairing.desc || 
                           '';
    
    const dishPrice = dishPairing.dishPrice || 
                     dishPairing.price || 
                     dishPairing.dish_price || 
                     dishPairing.cost || 
                     '';

    return {
      dish: dishName,
      dishDescription,
      dishPrice,
      pairings: normalizedWinePairings
    } as DishRecommendation;
  });

  // CRITICAL: Validate wine names against available wines
  console.log('🍷 VALIDATING WINE RECOMMENDATIONS AGAINST AVAILABLE WINES...');
  normalizedPairings = validateWinePairings(normalizedPairings, formattedWines);
  
  return normalizedPairings;
};
