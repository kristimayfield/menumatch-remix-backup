
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { PairingRequest } from './types.ts';
import { formatWineData, validateInputs } from './utils.ts';
import { createPairingPrompt, createConsolidatedPairingPrompt } from './prompts.ts';
import { parseOpenAIResponse, normalizePairings, normalizeConsolidatedPairings, callOpenAI } from './processor.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== FAST WINE PAIRING FUNCTION STARTED ===');

    const requestData: PairingRequest = await req.json();
    const { dishes, availableWines, userPreferences, budget, restaurantName, sessionMode, consolidatedMode } = requestData;

    console.log('Fast pairing request:', {
      dishCount: dishes?.length || 0,
      wineCount: availableWines?.length || 0,
      budget,
      restaurantName,
      sessionMode,
      consolidatedMode
    });

    // Validate inputs
    validateInputs(dishes, availableWines);

    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    // Format wine data for better price handling
    const formattedWines = availableWines.map(formatWineData);

    // Create appropriate pairing prompt based on mode
    const pairingPrompt = consolidatedMode 
      ? createConsolidatedPairingPrompt(dishes, formattedWines, userPreferences, budget || 50, restaurantName)
      : createPairingPrompt(dishes, formattedWines, userPreferences, budget || 50, restaurantName);

    console.log(`Sending ${consolidatedMode ? 'consolidated' : 'individual'} prompt to OpenAI for fast pairing...`);

    // Call OpenAI API
    const pairingContent = await callOpenAI(pairingPrompt, openAIApiKey);

    console.log('OpenAI fast pairing response received');
    console.log('Raw pairing content:', pairingContent.substring(0, 500) + '...');

    // Parse and normalize response based on mode
    let normalizedPairings;
    if (consolidatedMode) {
      const parsedPairings = parseOpenAIResponse(pairingContent);
      normalizedPairings = normalizeConsolidatedPairings(parsedPairings, formattedWines);
    } else {
      const parsedPairings = parseOpenAIResponse(pairingContent);
      normalizedPairings = normalizePairings(parsedPairings, formattedWines);
    }

    console.log('Fast pairing generation completed:', {
      mode: consolidatedMode ? 'consolidated' : 'individual',
      resultCount: normalizedPairings?.length || 0,
      totalPairings: consolidatedMode ? normalizedPairings?.length || 0 : normalizedPairings?.reduce((sum, dish) => sum + (dish.pairings?.length || 0), 0) || 0
    });

    return new Response(JSON.stringify({
      success: true,
      pairings: normalizedPairings,
      sessionMode: true,
      consolidatedMode: consolidatedMode || false,
      restaurantName: restaurantName
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Fast wine pairing error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
