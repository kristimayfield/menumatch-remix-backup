
// Wine varietal to type mapping
const RED_WINE_VARIETALS = [
  'pinot noir', 'cabernet sauvignon', 'merlot', 'syrah', 'shiraz', 'malbec', 
  'tempranillo', 'sangiovese', 'chianti', 'barolo', 'beaujolais', 'grenache', 
  'zinfandel', 'nebbiolo', 'gamay', 'cab sauv', 'cabernet'
];

const WHITE_WINE_VARIETALS = [
  'chardonnay', 'sauvignon blanc', 'pinot grigio', 'pinot gris', 'riesling', 
  'gewürztraminer', 'viognier', 'albariño', 'albarino', 'chenin blanc', 
  'vermentino', 'grüner veltliner', 'gruner veltliner', 'sauv blanc'
];

const VALID_WINE_STYLES = [
  'Fresh & Crisp',
  'Funky & Floral', 
  'Rich & Creamy',
  'Fresh & Fruity',
  'Dry & Dirty',
  'Packed with a Punch'
];

export const detectWineTypeFromName = (wineName: string): string => {
  const lowerName = wineName.toLowerCase();
  
  // Check for red wine varietals
  for (const varietal of RED_WINE_VARIETALS) {
    if (lowerName.includes(varietal)) {
      return 'Red';
    }
  }
  
  // Check for white wine varietals
  for (const varietal of WHITE_WINE_VARIETALS) {
    if (lowerName.includes(varietal)) {
      return 'White';
    }
  }
  
  // Default fallback logic
  if (lowerName.includes('red') || lowerName.includes('rouge')) return 'Red';
  if (lowerName.includes('white') || lowerName.includes('blanc')) return 'White';
  if (lowerName.includes('rosé') || lowerName.includes('rose')) return 'Rosé';
  if (lowerName.includes('sparkling') || lowerName.includes('champagne')) return 'Sparkling';
  
  return 'White'; // Ultimate fallback
};

// NEW: Wine name validation function
export const validateWineNameExists = (wineName: string, availableWines: any[]): boolean => {
  if (!wineName || wineName === 'No suitable pairing available') {
    return true; // Allow fallback messages
  }
  
  // Check if wine name exists exactly in the available wines list
  return availableWines.some(wine => {
    const availableWineName = wine.name || wine.wine_name || '';
    return availableWineName.toLowerCase().trim() === wineName.toLowerCase().trim();
  });
};

// NEW: Get exact wine name from available wines (case-insensitive matching)
export const getExactWineName = (searchName: string, availableWines: any[]): string => {
  if (!searchName || searchName === 'No suitable pairing available') {
    return searchName;
  }
  
  const foundWine = availableWines.find(wine => {
    const availableWineName = wine.name || wine.wine_name || '';
    return availableWineName.toLowerCase().trim() === searchName.toLowerCase().trim();
  });
  
  return foundWine ? (foundWine.name || foundWine.wine_name) : searchName;
};

export const validateWineStyle = (wineStyle: string, wineType: string, wineName: string): string => {
  if (VALID_WINE_STYLES.includes(wineStyle)) {
    // Detect wine type from name for validation
    const detectedType = detectWineTypeFromName(wineName);
    const finalType = detectedType || wineType;
    
    // Validate style matches wine type
    const whiteStyles = ['Fresh & Crisp', 'Funky & Floral', 'Rich & Creamy'];
    const redStyles = ['Fresh & Fruity', 'Dry & Dirty', 'Packed with a Punch'];
    
    if (finalType === 'Red' && whiteStyles.includes(wineStyle)) {
      console.warn(`Correcting red wine "${wineName}" from white style "${wineStyle}" to red style`);
      return 'Fresh & Fruity'; // Default red style
    }
    
    if (finalType === 'White' && redStyles.includes(wineStyle)) {
      console.warn(`Correcting white wine "${wineName}" from red style "${wineStyle}" to white style`);
      return 'Fresh & Crisp'; // Default white style
    }
    
    return wineStyle;
  }
  
  // Fallback mapping
  const detectedType = detectWineTypeFromName(wineName);
  const finalType = detectedType || wineType;
  const lowerStyle = wineStyle.toLowerCase();
  
  if (finalType === 'White' || finalType === 'Sparkling') {
    if (lowerStyle.includes('crisp') || lowerStyle.includes('fresh')) return 'Fresh & Crisp';
    if (lowerStyle.includes('floral') || lowerStyle.includes('funky')) return 'Funky & Floral';
    if (lowerStyle.includes('rich') || lowerStyle.includes('creamy')) return 'Rich & Creamy';
    return 'Fresh & Crisp';
  }
  
  if (finalType === 'Red') {
    if (lowerStyle.includes('light') || lowerStyle.includes('fruity')) return 'Fresh & Fruity';
    if (lowerStyle.includes('medium') || lowerStyle.includes('dry')) return 'Dry & Dirty';
    if (lowerStyle.includes('full') || lowerStyle.includes('bold')) return 'Packed with a Punch';
    return 'Fresh & Fruity';
  }
  
  return 'Fresh & Crisp';
};

export const mapToValidWineStyle = (
  rawWineStyle: string,
  wineType: string,
  wineName: string,
  description?: string
): string => {
  // If we have a valid raw style, validate it
  if (rawWineStyle && VALID_WINE_STYLES.includes(rawWineStyle)) {
    return validateWineStyle(rawWineStyle, wineType, wineName);
  }
  
  // Detect wine type from name if not provided
  const detectedType = detectWineTypeFromName(wineName);
  const finalType = detectedType || wineType;
  
  // Analyze description to determine appropriate Wine Wize style
  if (description) {
    const lowerDesc = description.toLowerCase();
    
    // FIXED: Proper wine type detection first, then style mapping
    if (finalType === 'Red') {
      // Red wine style mapping based on description
      if (lowerDesc.includes('light') || lowerDesc.includes('fruity') || lowerDesc.includes('fresh') || 
          lowerDesc.includes('bright') || lowerDesc.includes('silky') || lowerDesc.includes('elegant') ||
          lowerDesc.includes('cherry') || lowerDesc.includes('raspberry') || lowerDesc.includes('delicate')) {
        return 'Fresh & Fruity';
      }
      if (lowerDesc.includes('full-bodied') || lowerDesc.includes('bold') || lowerDesc.includes('powerful') || 
          lowerDesc.includes('intense') || lowerDesc.includes('robust') || lowerDesc.includes('structured') ||
          lowerDesc.includes('tannic') || lowerDesc.includes('concentrated') || lowerDesc.includes('punch')) {
        return 'Packed with a Punch';
      }
      if (lowerDesc.includes('earthy') || lowerDesc.includes('medium') || lowerDesc.includes('dry') || 
          lowerDesc.includes('savory') || lowerDesc.includes('spice') || lowerDesc.includes('herb') ||
          lowerDesc.includes('balanced') || lowerDesc.includes('food-friendly') || lowerDesc.includes('undertones')) {
        return 'Dry & Dirty';
      }
      // Default for reds
      return 'Fresh & Fruity';
    }
    
    if (finalType === 'White' || finalType === 'Sparkling') {
      // White wine style mapping based on description
      if (lowerDesc.includes('crisp') || lowerDesc.includes('bright') || lowerDesc.includes('citrus') || 
          lowerDesc.includes('mineral') || lowerDesc.includes('lean') || lowerDesc.includes('zippy') ||
          lowerDesc.includes('refreshing') || lowerDesc.includes('clean')) {
        return 'Fresh & Crisp';
      }
      if (lowerDesc.includes('floral') || lowerDesc.includes('aromatic') || lowerDesc.includes('funky') || 
          lowerDesc.includes('unique') || lowerDesc.includes('orange wine') || lowerDesc.includes('natural') ||
          lowerDesc.includes('spice') || lowerDesc.includes('exotic')) {
        return 'Funky & Floral';
      }
      if (lowerDesc.includes('rich') || lowerDesc.includes('creamy') || lowerDesc.includes('oak') || 
          lowerDesc.includes('butter') || lowerDesc.includes('full-bodied') || lowerDesc.includes('luxurious') ||
          lowerDesc.includes('barrel') || lowerDesc.includes('vanilla')) {
        return 'Rich & Creamy';
      }
      // Default for whites
      return 'Fresh & Crisp';
    }
  }
  
  // Fallback mapping based on wine type only
  if (finalType === 'Red') {
    return 'Fresh & Fruity';
  }
  if (finalType === 'White' || finalType === 'Sparkling') {
    return 'Fresh & Crisp';
  }
  if (finalType === 'Rosé') {
    return 'Fresh & Crisp';
  }
  
  return 'Fresh & Crisp';
};

export const validateAndCorrectWineStyles = (pairings: any[]): any[] => {
  return pairings.map(pairing => {
    if (pairing.pairings) {
      pairing.pairings = pairing.pairings.map((wine: any) => {
        const correctedStyle = mapToValidWineStyle(
          wine.wineStyle,
          wine.wineType,
          wine.wineName,
          wine.description
        );
        
        return {
          ...wine,
          wineStyle: correctedStyle
        };
      });
    }
    return pairing;
  });
};

// NEW: Validate and filter wine pairings to only include existing wines
export const validateWinePairings = (pairings: any[], availableWines: any[]): any[] => {
  console.log('🍷 Validating wine pairings against available wines list...');
  
  return pairings.map(dishPairing => {
    if (!dishPairing.pairings) {
      return dishPairing;
    }
    
    const validatedPairings = dishPairing.pairings
      .map((wine: any) => {
        const wineName = wine.wineName || wine.name || '';
        
        // Allow "No suitable pairing available" messages
        if (wineName === 'No suitable pairing available' || wineName.includes('General Recommendation')) {
          return wine;
        }
        
        // Check if wine exists in available wines
        const isValidWine = validateWineNameExists(wineName, availableWines);
        
        if (!isValidWine) {
          console.warn(`❌ REJECTED FICTIONAL WINE: "${wineName}" - not found in available wines list`);
          return null; // Filter out fictional wines
        }
        
        // Get exact wine name (proper capitalization)
        const exactWineName = getExactWineName(wineName, availableWines);
        console.log(`✅ VALIDATED WINE: "${exactWineName}"`);
        
        return {
          ...wine,
          wineName: exactWineName
        };
      })
      .filter(wine => wine !== null); // Remove rejected wines
    
    // If no valid wines found, add fallback message
    if (validatedPairings.length === 0) {
      validatedPairings.push({
        wineName: 'No suitable pairing available',
        wineType: 'N/A',
        wineStyle: 'Fresh & Crisp',
        description: 'Unfortunately, no wines from the current wine list pair well with this dish. Consider asking your server for recommendations from their full selection.',
        confidenceLevel: 'Low',
        price: 'N/A'
      });
    }
    
    return {
      ...dishPairing,
      pairings: validatedPairings
    };
  });
};
