
import { detectWineTypeFromName, mapToValidWineStyle } from './wineValidation.ts';

export const processWinePairings = async (
  analysisResults: any[],
  requestData: any,
  supabaseClient: any
): Promise<any> => {
  console.log('🍷 Processing wine pairings with enhanced style validation...');
  
  try {
    const processedPairings = analysisResults.map(result => {
      if (result.pairings) {
        return {
          ...result,
          pairings: result.pairings.map((pairing: any) => ({
            ...pairing,
            wines: pairing.wines?.map((wine: any) => {
              const wineName = wine.wineName || wine.name || 'Unknown Wine';
              const detectedType = detectWineTypeFromName(wineName);
              const validatedStyle = mapToValidWineStyle(wine.wineStyle || '', wine.wineType || detectedType, wineName);
              
              return {
                ...wine,
                wineType: detectedType,
                wineStyle: validatedStyle
              };
            }) || []
          }))
        };
      }
      return result;
    });

    console.log('✅ Wine styles validated and mapped to correct Wine Wize categories');
    return processedPairings;
  } catch (error) {
    console.error('❌ Error processing wine pairings:', error);
    throw error;
  }
};

// Re-export functions from other modules for backward compatibility
export { parseOpenAIResponse, normalizePairings, normalizeConsolidatedPairings } from './responseParser.ts';
export { callOpenAI } from './apiClient.ts';
