
import { DishRecommendation, WineData, ConsolidatedWineRecommendation } from './types.ts';
import { parseOpenAIResponse } from './jsonParser.ts';
import { normalizePairings } from './pairingNormalizer.ts';
import { normalizeConsolidatedPairings } from './consolidatedNormalizer.ts';

// Re-export the main functions for backward compatibility
export { parseOpenAIResponse } from './jsonParser.ts';
export { normalizePairings } from './pairingNormalizer.ts';
export { normalizeConsolidatedPairings } from './consolidatedNormalizer.ts';
