
import { WineData } from './types.ts';

export const formatWineData = (wine: WineData): WineData => {
  let priceInfo = 'Price not available';
  
  // Enhanced price extraction and formatting with validation
  if (wine.price_bottle) {
    const bottlePrice = wine.price_bottle.toString().replace(/[^\d.-]/g, '');
    if (bottlePrice && !isNaN(parseFloat(bottlePrice))) {
      const price = parseFloat(bottlePrice);
      // Validate bottle price reasonableness (typically $20-300)
      if (price >= 15 && price <= 500) {
        priceInfo = `$${price.toFixed(0)} bottle`;
      } else {
        console.warn(`Unusual bottle price detected: $${price} for wine: ${wine.name}`);
        priceInfo = `$${price.toFixed(0)} bottle`;
      }
    }
  } else if (wine.price_glass) {
    const glassPrice = wine.price_glass.toString().replace(/[^\d.-]/g, '');
    if (glassPrice && !isNaN(parseFloat(glassPrice))) {
      const price = parseFloat(glassPrice);
      // Validate glass price reasonableness (typically $8-30)
      if (price >= 5 && price <= 50) {
        priceInfo = `$${price.toFixed(0)} glass`;
      } else {
        console.warn(`Unusual glass price detected: $${price} for wine: ${wine.name}`);
        priceInfo = `$${price.toFixed(0)} glass`;
      }
    }
  } else if (wine.price) {
    const price = wine.price.toString().replace(/[^\d.-]/g, '');
    if (price && !isNaN(parseFloat(price))) {
      priceInfo = `$${parseFloat(price).toFixed(0)}`;
    }
  }

  // Ensure we handle the ww_style field properly from the database
  const wineStyle = wine.ww_style || wine.wine_style || wine.style || '';
  
  return {
    ...wine,
    formattedPrice: priceInfo,
    wineType: wine.wine_type || wine.type || 'wine',
    // Prioritize ww_style from database over other style fields
    wineStyle: wineStyle,
    varietal: wine.varietal || 'Unknown varietal'
  };
};

export const validateInputs = (dishes: any[], availableWines: any[]) => {
  if (!dishes || dishes.length === 0) {
    throw new Error('No dishes provided for pairing');
  }

  if (!availableWines || availableWines.length === 0) {
    throw new Error('No wines available for pairing');
  }

  // Enhanced validation for wine data structure
  const invalidWines = availableWines.filter(wine => !wine.name && !wine.wine_name);
  if (invalidWines.length > 0) {
    console.warn(`Found ${invalidWines.length} wines without proper names:`, invalidWines);
  }

  // Validate wine source integrity
  const winesWithSessionMarkers = availableWines.filter(wine => 
    wine.restaurant_id || wine.id || wine.created_at
  );
  
  if (winesWithSessionMarkers.length > 0) {
    console.warn('WARNING: Some wines may be from database rather than session upload');
    console.warn('Database wine markers found:', winesWithSessionMarkers.length);
  }

  console.log(`Validation passed: ${dishes.length} dishes, ${availableWines.length} wines`);
  console.log('Wine source validation complete');
};

export const extractNumericPrice = (priceString: string): number | null => {
  // Enhanced price extraction with validation
  if (!priceString) return null;
  
  // First try to extract bottle price specifically
  const bottleMatch = priceString.match(/(?:bottle|btl):\s*\$?(\d+(?:\.\d{2})?)/i);
  if (bottleMatch) {
    const price = parseFloat(bottleMatch[1]);
    return price >= 15 && price <= 500 ? price : null;
  }
  
  // Look for glass price
  const glassMatch = priceString.match(/(?:glass|gl):\s*\$?(\d+(?:\.\d{2})?)/i);
  if (glassMatch) {
    const price = parseFloat(glassMatch[1]);
    return price >= 5 && price <= 50 ? price : null;
  }
  
  // General price extraction with validation
  const priceMatch = priceString.match(/\$?(\d+(?:\.\d{2})?)/);
  if (priceMatch) {
    const price = parseFloat(priceMatch[1]);
    // Validate price is reasonable (could be either glass or bottle)
    return price >= 5 && price <= 500 ? price : null;
  }
  
  return null;
};

// Enhanced data validation for session integrity
export const validateSessionWineData = (wines: any[]): boolean => {
  if (!wines || wines.length === 0) {
    console.error('No wines provided for validation');
    return false;
  }

  // Check for database contamination markers
  const databaseMarkers = ['restaurant_id', 'created_at', 'updated_at', 'id'];
  const contaminated = wines.filter(wine => 
    databaseMarkers.some(marker => wine[marker])
  );

  if (contaminated.length > 0) {
    console.warn(`${contaminated.length}/${wines.length} wines show database contamination`);
    console.warn('Sample contaminated wine:', contaminated[0]);
    return false;
  }

  console.log(`✓ Session wine data validation passed: ${wines.length} clean session wines`);
  return true;
};
