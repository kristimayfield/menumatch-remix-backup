
export const createPairingPrompt = (
  dishes: any[],
  availableWines: any[],
  userPreferences: any,
  budget: number,
  restaurantName: string
): string => {
  const dishList = dishes.map(dish => 
    `- ${dish.name} (${dish.type || 'main'}): ${dish.description || 'No description'} - ${dish.price || 'Price not listed'}`
  ).join('\n');

  // Enhanced wine list formatting with exact names
  const wineList = availableWines.map((wine, index) => {
    const wineName = wine.name || wine.wine_name;
    const pricing = [];
    if (wine.price_glass) pricing.push(`Glass: ${wine.price_glass}`);
    if (wine.price_bottle) pricing.push(`Bottle: ${wine.price_bottle}`);
    const priceInfo = pricing.length > 0 ? ` (${pricing.join(', ')})` : '';
    
    return `${index + 1}. EXACT WINE NAME: "${wineName}"${wine.vintage ? ` ${wine.vintage}` : ''} - ${wine.varietal || 'Unknown varietal'} (${wine.wine_type || 'Unknown type'})${wine.region ? ` from ${wine.region}` : ''}${priceInfo}${wine.description ? ` - ${wine.description}` : ''}`;
  }).join('\n');

  const preferencesText = userPreferences ? 
    `User preferences: Budget $${userPreferences.budget || budget}, Preferred red wines: ${userPreferences.ww_red_style || 'Any'}, Preferred white wines: ${userPreferences.ww_white_style || 'Any'}` :
    `User budget: $${budget}`;

  return `You're helping a guest at ${restaurantName} find the perfect wine pairings! Your mission is to create wine recommendations that make their dining experience absolutely fantastic.

CRITICAL WINE SELECTION RULES - MUST FOLLOW EXACTLY:
🚨 NEVER CREATE FICTIONAL WINES OR WINE NAMES 🚨
🚨 ONLY USE EXACT WINE NAMES FROM THE PROVIDED LIST BELOW 🚨
🚨 DO NOT INVENT, MODIFY, OR CREATE NEW WINE NAMES 🚨
🚨 IF NO SUITABLE WINE EXISTS, SAY "No suitable pairing available" 🚨

MANDATORY WINE SELECTION PROCESS:
1. Look at the EXACT WINE NAMES from the numbered list below
2. Choose ONLY from these specific wines by copying the exact name
3. NEVER combine wine names or create variations
4. NEVER add regions, vineyards, or details not in the exact name
5. If no wine works well, use "No suitable pairing available" as wineName

AVAILABLE WINES AT ${restaurantName} (USE EXACT NAMES ONLY):
${wineList}

EXAMPLES OF CORRECT WINE SELECTION:
✅ CORRECT: Use exact name like "Caymus Cabernet Sauvignon" (if that's on the list)
❌ WRONG: Creating "Languedoc Cinsault, Loire" (not on the list)
❌ WRONG: "Napa Valley Pinot Noir" (unless exactly that name is listed)
❌ WRONG: Adding regions or descriptors not in the exact wine name

CRITICAL RESPONSE FORMAT: You MUST respond with ONLY a JSON array in this EXACT structure:
[
  {
    "dish": "Exact dish name from the list",
    "dishDescription": "Brief description of the dish",
    "dishPrice": "Price from the dish list",
    "pairings": [
      {
        "wineName": "EXACT wine name from available wines list OR 'No suitable pairing available'",
        "wineType": "Red, White, Rosé, or Sparkling", 
        "description": "Your amazing, friendly wine description (300-400 characters) that gets people excited about this pairing!",
        "confidenceLevel": "High, Medium, or Low",
        "price": "Exact price from wine list (Glass: $X, Bottle: $Y format) OR 'Price not available'"
      }
    ]
  }
]

Restaurant: ${restaurantName}
${preferencesText}

DISHES TO PAIR:
${dishList}

WINE VALIDATION CHECKLIST BEFORE RESPONDING:
☐ Did I use ONLY exact wine names from the numbered list above?
☐ Did I avoid creating any fictional wine names?
☐ Did I copy wine names exactly as written?
☐ If no suitable wine exists, did I use "No suitable pairing available"?

YOUR WINE DESCRIPTION MISSION:
🍷 Create descriptions that are 300-400 characters long - enough to tell a mini wine story!
🍷 Start each description with the wine's "personality" or vibe (bright & zesty, rich & cozy, bold & adventurous, etc.)
🍷 Include 2-3 specific but relatable flavor notes using everyday language:
   - Instead of "stone fruit notes" → "tastes like biting into a perfect summer peach"
   - Instead of "herbaceous qualities" → "has that fresh-cut grass brightness"
   - Instead of "mineral undertones" → "crisp like morning dew on rocks"
🍷 Explain WHY this wine loves this dish - make it about flavor harmony and enhancement
🍷 Use enthusiastic, conversational language that builds excitement
🍷 Mention regional character in a way that adds to the story, not intimidates
🍷 End with why this choice will make their meal memorable

PAIRING PHILOSOPHY:
- Think about how flavors dance together, not just traditional rules
- Focus on the experience: "This pairing will make you close your eyes and smile"
- Explain texture harmony: creamy wines with rich dishes, crisp wines cutting through richness
- Use food analogies: "This wine is like the perfect friend for this dish"
- Make it personal: "You'll love how the wine's brightness plays with the dish's richness"

CONFIDENCE LEVELS:
- High: Classic, time-tested pairings that always work beautifully
- Medium: Creative matches that complement each other really well
- Low: Adventurous pairings for the curious palate

Remember: Include 2-3 wine recommendations per dish, use ONLY wines from the available list with exact names, and make every description a mini celebration of why this pairing rocks!

FINAL VALIDATION: Before submitting, verify every wineName appears EXACTLY in the available wines list above.

JSON Response:`;
};

export const createConsolidatedPairingPrompt = (
  dishes: any[],
  availableWines: any[],
  userPreferences: any,
  budget: number,
  restaurantName: string
): string => {
  const dishList = dishes.map(dish => 
    `- ${dish.name} (${dish.type || 'main'}): ${dish.description || 'No description'} - ${dish.price || 'Price not listed'}`
  ).join('\n');

  // Enhanced wine list formatting with exact names
  const wineList = availableWines.map((wine, index) => {
    const wineName = wine.name || wine.wine_name;
    const pricing = [];
    if (wine.price_glass) pricing.push(`Glass: ${wine.price_glass}`);
    if (wine.price_bottle) pricing.push(`Bottle: ${wine.price_bottle}`);
    const priceInfo = pricing.length > 0 ? ` (${pricing.join(', ')})` : '';
    
    return `${index + 1}. EXACT WINE NAME: "${wineName}"${wine.vintage ? ` ${wine.vintage}` : ''} - ${wine.varietal || 'Unknown varietal'} (${wine.wine_type || 'Unknown type'})${wine.region ? ` from ${wine.region}` : ''}${priceInfo}${wine.description ? ` - ${wine.description}` : ''}`;
  }).join('\n');

  const preferencesText = userPreferences ? 
    `User preferences: Budget $${userPreferences.budget || budget}, Preferred red wines: ${userPreferences.ww_red_style || 'Any'}, Preferred white wines: ${userPreferences.ww_white_style || 'Any'}` :
    `User budget: $${budget}`;

  return `You're the friendly sommelier at ${restaurantName} helping choose versatile wines that work beautifully with a complete meal! Your goal is to find wines that are like the perfect dinner party guests - they get along with everyone.

CRITICAL WINE SELECTION RULES - MUST FOLLOW EXACTLY:
🚨 NEVER CREATE FICTIONAL WINES OR WINE NAMES 🚨
🚨 ONLY USE EXACT WINE NAMES FROM THE PROVIDED LIST BELOW 🚨
🚨 DO NOT INVENT, MODIFY, OR CREATE NEW WINE NAMES 🚨
🚨 IF NO SUITABLE WINE EXISTS, SAY "No suitable pairing available" 🚨

AVAILABLE WINES AT ${restaurantName} (USE EXACT NAMES ONLY):
${wineList}

CRITICAL RESPONSE FORMAT: You MUST respond with ONLY a JSON array in this EXACT structure:
[
  {
    "wineName": "EXACT wine name from available wines list OR 'No suitable pairing available'",
    "wineType": "Red, White, Rosé, or Sparkling",
    "description": "Your engaging description of why this wine is perfect as a table wine (300-400 characters)",
    "confidenceLevel": "High, Medium, or Low",
    "price": "Exact price from wine list (Glass: $X, Bottle: $Y format) OR 'Price not available'",
    "dishCompatibility": "Fun explanation of how this wine plays well with all the dishes"
  }
]

Restaurant: ${restaurantName}
${preferencesText}

SELECTED DISHES:
${dishList}

WINE VALIDATION CHECKLIST BEFORE RESPONDING:
☐ Did I use ONLY exact wine names from the numbered list above?
☐ Did I avoid creating any fictional wine names?
☐ Did I copy wine names exactly as written?
☐ If no suitable wine exists, did I use "No suitable pairing available"?

YOUR WINE SELECTION MISSION:
🍷 Choose 3-4 versatile, food-friendly wines that work as fantastic table wines
🍷 Focus on wines with broad appeal and compatibility
🍷 Create 300-400 character descriptions that showcase each wine's versatility
🍷 Use enthusiastic, approachable language that makes people excited to share these wines
🍷 Explain why each wine is the perfect "dinner companion" for the whole meal

VERSATILITY FACTORS TO HIGHLIGHT:
- Balanced acidity that refreshes between bites
- Moderate intensity that won't overpower any dish
- Flavor profile that complements multiple courses
- Food-friendly characteristics that enhance rather than compete

DESCRIPTION STYLE:
- Start with the wine's "social personality" (the life of the party, the reliable friend, etc.)
- Mention 2-3 key flavors using relatable comparisons
- Explain its versatility in terms of "playing well with others"
- Use enthusiastic language about the shared dining experience

CRITICAL REQUIREMENTS:
- Select wines suitable for multiple dishes using ONLY exact names from the list
- Use exact wine names from the list
- Create engaging 300-400 character descriptions
- Use friendly, accessible language
- Use exact prices from the wine list
- Respond with ONLY the JSON array

FINAL VALIDATION: Before submitting, verify every wineName appears EXACTLY in the available wines list above.

JSON Response:`;
};
