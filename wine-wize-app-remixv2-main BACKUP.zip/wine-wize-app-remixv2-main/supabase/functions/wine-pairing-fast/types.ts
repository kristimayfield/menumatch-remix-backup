
export interface DishData {
  id: string;
  name: string;
  description: string;
  price: string;
  ingredients?: string[];
  type: string;
}

export interface WineData {
  id: string;
  name: string;
  wine_name?: string;
  vintage?: string;
  varietal?: string;
  region?: string;
  price_glass?: string;
  price_bottle?: string;
  wineType: string;
  wine_type?: string;
  wineStyle: string;
  wine_style?: string;
  ww_style?: string;
  description?: string;
  formattedPrice: string;
}

export interface UserPreferences {
  budget?: number;
  ww_red_style?: string;
  ww_white_style?: string;
  sweetness?: string;
  acidity?: string;
  tannin?: string;
  alcohol?: string;
}

export interface WineRecommendation {
  wineName: string;
  wineType: string;
  wineStyle: string;
  description: string;
  confidenceLevel: string;
  price: string;
}

export interface ConsolidatedWineRecommendation {
  wineName: string;
  wineType: string;
  wineStyle: string;
  description: string;
  confidenceLevel: string;
  price: string;
  dishCompatibility: string;
}

export interface DishRecommendation {
  dish: string;
  dishDescription: string;
  dishPrice: string;
  pairings: WineRecommendation[];
}

export interface PairingRequest {
  dishes: DishData[];
  availableWines: WineData[];
  userPreferences?: UserPreferences | null;
  budget?: number;
  restaurantName: string;
  sessionMode?: boolean;
  consolidatedMode?: boolean;
}
