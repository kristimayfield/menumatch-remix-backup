
export const parseOpenAIResponse = (content: string): any[] => {
  console.log('Raw OpenAI response content:', content.substring(0, 1000) + '...');
  
  try {
    // Try to extract JSON from response - handle multiple possible formats
    let jsonString = content;
    
    // Remove markdown code blocks if present
    jsonString = jsonString.replace(/```json\s*/g, '').replace(/```\s*/g, '');
    
    // Try to find JSON array or object in the response
    const jsonMatch = jsonString.match(/\[[\s\S]*\]/) || jsonString.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.error('No JSON found in response. Full content:', content);
      throw new Error('No JSON array or object found in response');
    }
    
    const parsed = JSON.parse(jsonMatch[0]);
    console.log('Parsed JSON structure:', JSON.stringify(parsed, null, 2));
    
    // Handle different response structures with better validation
    let pairingsArray = [];
    
    if (Array.isArray(parsed)) {
      pairingsArray = parsed;
    } else if (parsed.pairings && Array.isArray(parsed.pairings)) {
      pairingsArray = parsed.pairings;
    } else if (parsed.dishes && Array.isArray(parsed.dishes)) {
      pairingsArray = parsed.dishes;
    } else if (parsed.recommendations && Array.isArray(parsed.recommendations)) {
      pairingsArray = parsed.recommendations;
    } else {
      console.error('Unexpected JSON structure, attempting to extract pairings:', parsed);
      // Try to find any array in the response
      for (const [key, value] of Object.entries(parsed)) {
        if (Array.isArray(value) && value.length > 0) {
          console.log(`Found array in key "${key}":`, value);
          pairingsArray = value;
          break;
        }
      }
      
      if (pairingsArray.length === 0) {
        throw new Error('No valid pairings array found in response structure');
      }
    }
    
    console.log(`Successfully extracted ${pairingsArray.length} pairing items`);
    return pairingsArray;
    
  } catch (error) {
    console.error('Error parsing OpenAI response:', error);
    console.error('Full response content:', content);
    throw new Error(`Failed to parse OpenAI response: ${error.message}`);
  }
};
