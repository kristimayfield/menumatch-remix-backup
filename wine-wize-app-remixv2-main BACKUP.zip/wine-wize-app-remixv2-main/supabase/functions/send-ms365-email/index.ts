
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface EmailRequest {
  to: string;
  subject: string;
  body: string;
  isHtml?: boolean;
}

interface MSGraphTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

const logStep = (step: string, details?: any) => {
  const timestamp = new Date().toISOString();
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[${timestamp}] [MS365-EMAIL] ${step}${detailsStr}`);
};

const getAccessToken = async (tenantId: string, clientId: string, clientSecret: string): Promise<string> => {
  logStep("Starting MS 365 access token request");
  
  const tokenUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
  
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: clientId,
    client_secret: clientSecret,
    scope: 'https://graph.microsoft.com/.default'
  });

  logStep("Making token request to Microsoft", { url: tokenUrl, clientId });

  const response = await fetch(tokenUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: body.toString(),
  });

  if (!response.ok) {
    const errorText = await response.text();
    logStep("Token request failed", { status: response.status, statusText: response.statusText, error: errorText });
    throw new Error(`Failed to get access token: ${response.status} ${response.statusText} - ${errorText}`);
  }

  const tokenData: MSGraphTokenResponse = await response.json();
  logStep("Access token obtained successfully", { expiresIn: tokenData.expires_in });
  return tokenData.access_token;
};

const sendEmail = async (accessToken: string, fromEmail: string, emailData: EmailRequest): Promise<void> => {
  logStep("Preparing to send email via Microsoft Graph", { 
    to: emailData.to, 
    subject: emailData.subject, 
    fromEmail: fromEmail,
    isHtml: emailData.isHtml 
  });

  const graphUrl = `https://graph.microsoft.com/v1.0/users/${fromEmail}/sendMail`;
  
  const emailPayload = {
    message: {
      subject: emailData.subject,
      body: {
        contentType: emailData.isHtml ? "HTML" : "Text",
        content: emailData.body
      },
      toRecipients: [
        {
          emailAddress: {
            address: emailData.to
          }
        }
      ]
    }
  };

  logStep("Sending email via Graph API", { url: graphUrl, payload: emailPayload });

  const response = await fetch(graphUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(emailPayload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    logStep("Email send failed", { status: response.status, statusText: response.statusText, error: errorText });
    throw new Error(`Failed to send email: ${response.status} ${response.statusText} - ${errorText}`);
  }

  logStep("Email sent successfully via Microsoft Graph");
};

serve(async (req) => {
  const timestamp = new Date().toISOString();
  logStep("MS 365 email function invoked", { method: req.method, timestamp });

  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    logStep("Handling CORS preflight request");
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get required environment variables with detailed logging
    const tenantId = Deno.env.get('MS365_TENANT_ID');
    const clientId = Deno.env.get('MS365_CLIENT_ID');
    const clientSecret = Deno.env.get('MS365_CLIENT_SECRET');
    const fromEmail = Deno.env.get('MS365_FROM_EMAIL');

    logStep("Environment variables check", {
      hasTenantId: !!tenantId,
      hasClientId: !!clientId,
      hasClientSecret: !!clientSecret,
      hasFromEmail: !!fromEmail,
      tenantIdLength: tenantId?.length || 0,
      clientIdLength: clientId?.length || 0,
      fromEmail: fromEmail // Safe to log email
    });

    if (!tenantId || !clientId || !clientSecret || !fromEmail) {
      const missingVars = [];
      if (!tenantId) missingVars.push('MS365_TENANT_ID');
      if (!clientId) missingVars.push('MS365_CLIENT_ID');
      if (!clientSecret) missingVars.push('MS365_CLIENT_SECRET');
      if (!fromEmail) missingVars.push('MS365_FROM_EMAIL');
      
      logStep("Missing required environment variables", { missing: missingVars });
      return new Response(
        JSON.stringify({ 
          error: 'Missing required MS 365 configuration',
          missing: missingVars,
          timestamp: timestamp
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Parse request body with error handling
    let emailData: EmailRequest;
    try {
      const rawBody = await req.text();
      logStep("Raw request body received", { bodyLength: rawBody.length });
      emailData = JSON.parse(rawBody);
      logStep("Request body parsed successfully", { 
        hasTo: !!emailData.to, 
        hasSubject: !!emailData.subject, 
        hasBody: !!emailData.body,
        to: emailData.to,
        subject: emailData.subject
      });
    } catch (parseError) {
      logStep("Failed to parse request body", { error: parseError.message });
      return new Response(
        JSON.stringify({ 
          error: 'Invalid JSON in request body',
          details: parseError.message,
          timestamp: timestamp
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    if (!emailData.to || !emailData.subject || !emailData.body) {
      logStep("Invalid request data - missing required fields", { 
        hasTo: !!emailData.to, 
        hasSubject: !!emailData.subject, 
        hasBody: !!emailData.body 
      });
      return new Response(
        JSON.stringify({ 
          error: 'Missing required fields: to, subject, body',
          received: {
            to: !!emailData.to,
            subject: !!emailData.subject,
            body: !!emailData.body
          },
          timestamp: timestamp
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get access token
    logStep("Attempting to get access token");
    const accessToken = await getAccessToken(tenantId, clientId, clientSecret);
    logStep("Access token retrieved successfully");
    
    // Send email
    logStep("Attempting to send email");
    await sendEmail(accessToken, fromEmail, emailData);
    logStep("Email sending completed successfully");

    const successResponse = {
      success: true, 
      message: 'Email sent successfully via MS 365',
      timestamp: timestamp,
      details: {
        to: emailData.to,
        subject: emailData.subject,
        fromEmail: fromEmail
      }
    };

    logStep("Returning success response", successResponse);

    return new Response(
      JSON.stringify(successResponse),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    logStep("Critical error in MS 365 email function", { 
      error: error.message, 
      stack: error.stack,
      name: error.name
    });
    
    const errorResponse = {
      error: 'Failed to send email via MS 365',
      details: error.message,
      timestamp: timestamp,
      type: error.name || 'UnknownError'
    };

    return new Response(
      JSON.stringify(errorResponse),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
