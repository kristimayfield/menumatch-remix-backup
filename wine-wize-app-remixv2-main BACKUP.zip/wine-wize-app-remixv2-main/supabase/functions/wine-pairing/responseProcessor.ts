
// Function to clean JSON response from OpenAI that might be wrapped in markdown
export const cleanJsonResponse = (responseText: string): string => {
  let cleanedText = responseText.trim();
  
  if (cleanedText.startsWith('```json')) {
    cleanedText = cleanedText.replace(/^```json\s*/, '');
  }
  if (cleanedText.startsWith('```')) {
    cleanedText = cleanedText.replace(/^```\s*/, '');
  }
  if (cleanedText.endsWith('```')) {
    cleanedText = cleanedText.replace(/\s*```$/, '');
  }
  
  return cleanedText.trim();
};

export const parseOpenAIResponse = (pairingResult: string): any => {
  console.log('Raw OpenAI response:', pairingResult);
  
  // Clean the JSON response to remove markdown wrappers
  const cleanedResult = cleanJsonResponse(pairingResult);
  console.log('Cleaned response for parsing:', cleanedResult);
  
  // Try to parse the cleaned JSON response
  try {
    return JSON.parse(cleanedResult);
  } catch (parseError) {
    console.error('Failed to parse cleaned JSON response:', cleanedResult);
    console.error('Parse error:', parseError.message);
    throw new Error('Failed to parse wine pairing recommendations');
  }
};

export const callOpenAI = async (prompt: string, openAIApiKey: string): Promise<string> => {
  console.log('Sending request to OpenAI...');

  const openAIResponse = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openAIApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are an expert sommelier specializing in wine and food pairings. Always determine wine type (Red/White) from varietal first, then assign correct Wine Wize style within that color category. NEVER assign red wines to white wine styles or vice versa.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 3000,
      temperature: 0.3
    }),
  });

  if (!openAIResponse.ok) {
    const errorText = await openAIResponse.text();
    console.error('OpenAI API error:', errorText);
    throw new Error(`OpenAI API error: ${openAIResponse.status}`);
  }

  const openAIData = await openAIResponse.json();
  console.log('OpenAI response received');

  return openAIData.choices[0].message.content;
};
