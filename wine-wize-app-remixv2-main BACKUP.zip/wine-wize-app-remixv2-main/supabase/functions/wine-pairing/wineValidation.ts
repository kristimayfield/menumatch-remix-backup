
// Wine varietal to type mapping utilities
const RED_WINE_VARIETALS = [
  'pinot noir', 'cabernet sauvignon', 'merlot', 'syrah', 'shiraz', 'malbec', 
  'tempranillo', 'sangiovese', 'chianti', 'barolo', 'beaujolais', 'grenache', 
  'zinfandel', 'nebbiolo', 'gamay', 'cab sauv', 'cabernet'
];

const WHITE_WINE_VARIETALS = [
  'chardonnay', 'sauvignon blanc', 'pinot grigio', 'pinot gris', 'riesling', 
  'gewürztraminer', 'viognier', 'albariño', 'albarino', 'chenin blanc', 
  'vermentino', 'grüner veltliner', 'gruner veltliner', 'sauv blanc'
];

export const detectWineTypeFromName = (wineName: string): string => {
  const lowerName = wineName.toLowerCase();
  
  for (const varietal of RED_WINE_VARIETALS) {
    if (lowerName.includes(varietal)) return 'Red';
  }
  
  for (const varietal of WHITE_WINE_VARIETALS) {
    if (lowerName.includes(varietal)) return 'White';
  }
  
  if (lowerName.includes('red') || lowerName.includes('rouge')) return 'Red';
  if (lowerName.includes('white') || lowerName.includes('blanc')) return 'White';
  if (lowerName.includes('rosé') || lowerName.includes('rose')) return 'Rosé';
  if (lowerName.includes('sparkling') || lowerName.includes('champagne')) return 'Sparkling';
  
  return 'White';
};

export const validateAndCorrectWineStyles = (parsedResult: any[]): any[] => {
  if (!Array.isArray(parsedResult)) return parsedResult;
  
  return parsedResult.map(dish => ({
    ...dish,
    pairings: dish.pairings?.map((wine: any) => {
      const detectedType = detectWineTypeFromName(wine.wineName || '');
      const wineType = detectedType || wine.wineType || 'White';
      
      // Validate wine style matches wine type
      const whiteStyles = ['Fresh & Crisp', 'Funky & Floral', 'Rich & Creamy'];
      const redStyles = ['Fresh & Fruity', 'Dry & Dirty', 'Packed with a Punch'];
      let correctedStyle = wine.wineStyle;
      
      if (wineType === 'Red' && whiteStyles.includes(wine.wineStyle)) {
        console.warn(`Correcting red wine "${wine.wineName}" from white style "${wine.wineStyle}" to red style`);
        correctedStyle = 'Fresh & Fruity';
      } else if (wineType === 'White' && redStyles.includes(wine.wineStyle)) {
        console.warn(`Correcting white wine "${wine.wineName}" from red style "${wine.wineStyle}" to white style`);
        correctedStyle = 'Fresh & Crisp';
      }
      
      return {
        ...wine,
        wineType,
        wineStyle: correctedStyle
      };
    }) || []
  }));
};
