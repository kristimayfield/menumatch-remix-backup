
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { detectWineTypeFromName, validateAndCorrectWineStyles } from './wineValidation.ts';
import { buildWinePairingPrompt } from './promptBuilder.ts';
import { parseOpenAIResponse, callOpenAI } from './responseProcessor.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== WINE PAIRING FUNCTION STARTED ===');

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Authorization header is required');
    }

    // Parse request body
    const requestBody = await req.json();
    console.log('Request body received:', JSON.stringify(requestBody, null, 2));

    const { 
      dishes,
      availableWines,
      userPreferences,
      budget,
      restaurantName,
      restaurantId
    } = requestBody;

    // Validate required fields
    if (!dishes || !Array.isArray(dishes) || dishes.length === 0) {
      throw new Error('Dishes array is required and cannot be empty');
    }

    console.log(`Processing ${dishes.length} dishes for restaurant: ${restaurantName}`);
    console.log(`Available wines: ${availableWines?.length || 0}`);

    // Get fresh restaurant wines from database if restaurantId is provided
    let restaurantWines = availableWines || [];
    
    if (restaurantId && restaurantWines.length === 0) {
      console.log(`Fetching wines from database for restaurant ID: ${restaurantId}`);
      const { data: dbWines, error: wineError } = await supabaseClient
        .from('restaurant_wines')
        .select('*')
        .eq('restaurant_id', restaurantId);

      if (wineError) {
        console.error('Error fetching wines from database:', wineError);
      } else if (dbWines && dbWines.length > 0) {
        restaurantWines = dbWines;
        console.log(`Found ${restaurantWines.length} wines in database`);
      }
    }

    // Build the personalized prompt
    const personalizedPrompt = buildWinePairingPrompt(
      dishes, 
      restaurantWines, 
      userPreferences, 
      budget, 
      restaurantName
    );

    console.log('Available wines being sent:', restaurantWines.map(wine => wine.name).join(', '));

    // Call OpenAI API
    const pairingResult = await callOpenAI(personalizedPrompt, Deno.env.get('OPENAI_API_KEY') ?? '');
    
    // Parse and validate the response
    let parsedResult = parseOpenAIResponse(pairingResult);
    
    // Validate and correct wine styles in the parsed result
    parsedResult = validateAndCorrectWineStyles(parsedResult);

    console.log('=== WINE PAIRING COMPLETE ===');
    console.log(`Generated ${parsedResult?.length || 0} pairing recommendations`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        pairings: parsedResult || [] 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('=== ERROR IN WINE-PAIRING FUNCTION ===');
    console.error('Error details:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        details: 'Wine pairing system encountered an error',
        timestamp: new Date().toISOString()
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
