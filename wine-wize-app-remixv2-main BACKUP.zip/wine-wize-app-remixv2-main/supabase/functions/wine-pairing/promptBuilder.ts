
export const buildWinePairingPrompt = (
  dishes: any[],
  restaurantWines: any[],
  userPreferences: any,
  budget: any,
  restaurantName: string
): string => {
  const basePrompt = `
You are a professional sommelier providing wine pairing recommendations. Analyze the selected dishes and wine list to create perfect pairings.

CRITICAL WINE SELECTION RULES - MUST FOLLOW EXACTLY:
🚨 NEVER CREATE FICTIONAL WINES OR WINE NAMES 🚨
🚨 ONLY USE EXACT WINE NAMES FROM THE PROVIDED RESTAURANT WINE LIST 🚨
🚨 DO NOT INVENT, MODIFY, OR CREATE NEW WINE NAMES 🚨
🚨 IF NO SUITABLE WINE EXISTS FROM THE LIST, CREATE "General Recommendation" ONLY 🚨

MANDATORY WINE SELECTION PROCESS:
1. First, look for wines from the restaurant's actual wine list that match well
2. Use the EXACT wine names as provided in the restaurant wine list
3. NEVER modify wine names or add regions/details not in the original name
4. Only suggest "General Recommendation" wines if NO good matches exist in the restaurant list
5. NEVER create fictional wines with made-up names or regions

CRITICAL WINE STYLE CATEGORIZATION:
You must categorize each wine into one of these 6 Wine Wize styles ONLY:

WHITE WINES:
- "Fresh & Crisp" - Light, acidic white wines (Sauvignon Blanc, Pinot Grigio, Albariño)
- "Funky & Floral" - Aromatic, unique white wines (Gewürztraminer, Orange wines, Natural wines)  
- "Rich & Creamy" - Full-bodied, oak-aged whites (Chardonnay, White Rioja, Viognier)

RED WINES:
- "Fresh & Fruity" - Light, fruit-forward reds (Pinot Noir, Beaujolais, light Sangiovese)
- "Dry & Dirty" - Medium-bodied, earthy reds (Malbec, Tempranillo, Chianti)
- "Packed with a Punch" - Full-bodied, intense reds (Cabernet Sauvignon, Syrah, Barolo)

WINE TYPE DETECTION - CRITICAL RULES:
1. First determine if the wine is RED or WHITE based on varietal:
   - RED: Pinot Noir, Cabernet Sauvignon, Merlot, Syrah/Shiraz, Malbec, Tempranillo, Sangiovese, Chianti, Barolo, Beaujolais, Grenache, Zinfandel, Nebbiolo
   - WHITE: Chardonnay, Sauvignon Blanc, Pinot Grigio/Gris, Riesling, Gewürztraminer, Viognier, Albariño, Chenin Blanc, Vermentino, Grüner Veltliner

2. NEVER assign red wine varietals to white wine styles
3. NEVER assign white wine varietals to red wine styles

INSTRUCTIONS:
- Provide exactly 3 wine recommendations per dish
- Prioritize wines from the provided wine list when good matches exist using EXACT names
- Include "General Recommendation" entries ONLY if the wine list lacks suitable options
- Base recommendations on classic pairing principles (complement/contrast flavors, wine body, acidity, tannins)
- Use confidence levels: "High" for classic pairings, "Medium" for good matches, "Low" for experimental pairings

USER PREFERENCES:
- Budget: {{userBudget}}
- White Wine Style Preference: {{whiteWinePreference}}
- Red Wine Style Preference: {{redWinePreference}}
- Taste Preferences: {{tastePreferences}}

RESTAURANT: {{restaurantName}}

SELECTED DISHES:
{{selectedDishes}}

AVAILABLE WINES FROM RESTAURANT WINE LIST (USE EXACT NAMES):
{{availableWines}}

WINE VALIDATION CHECKLIST BEFORE EACH RECOMMENDATION:
☐ Is this wine name EXACTLY as it appears in the restaurant wine list?
☐ Did I avoid creating any fictional wine names or regions?
☐ If no suitable restaurant wine exists, am I using "General Recommendation"?
☐ Did I assign the correct Wine Wize style based on wine type?

PAIRING LOGIC TO EMPHASIZE:
- Light fish/seafood → Crisp whites (Sauvignon Blanc, Pinot Grigio)
- Rich fish/salmon → Chardonnay or light reds (Pinot Noir)
- Chicken/poultry → Versatile (Chardonnay, Pinot Noir, light reds)
- Red meat/steak → Bold reds (Cabernet Sauvignon, Malbec)
- Mushroom dishes → Earthy reds (Pinot Noir, Burgundy)
- Pasta/Italian → Medium reds (Chianti, Sangiovese) or rich whites
- Spicy food → Off-dry whites or fruity reds
- Desserts → Sweet wines, Port, or Moscato

CONFIDENCE SCORING:
- High: Classic textbook pairings (Steak + Cabernet)
- Medium: Good complementary matches
- Low: Creative/experimental pairings

For each dish, first look for wines from the restaurant list that match well using EXACT names. If no good matches exist, suggest "General Recommendation" wines that would pair perfectly.

Return response in this exact JSON format:
[
  {
    "dish": "dish_name",
    "dishDescription": "dish_description",
    "dishPrice": "dish_price",
    "pairings": [
      {
        "wineName": "EXACT Wine Name from Restaurant List OR General Recommendation Type",
        "wineType": "Red/White/Rosé/Sparkling/Dessert",
        "wineStyle": "MUST BE ONE OF THE 6 WINE WIZE STYLES ABOVE",
        "description": "Detailed explanation of why this pairing works including flavor notes",
        "confidenceLevel": "High/Medium/Low",
        "price": "Price from wine list or estimated range"
      }
    ]
  }
]

MANDATORY: The wineStyle field MUST ONLY contain one of these 6 exact values:
- "Fresh & Crisp" (WHITE wines only)
- "Funky & Floral" (WHITE wines only)
- "Rich & Creamy" (WHITE wines only)
- "Fresh & Fruity" (RED wines only)
- "Dry & Dirty" (RED wines only)
- "Packed with a Punch" (RED wines only)

FINAL VALIDATION: Before submitting response, verify every wine recommendation either:
1. Uses EXACT wine name from restaurant list, OR
2. Is clearly marked as "General Recommendation" for missing wine types
`;

  // Format selected dishes for the prompt
  const dishesText = dishes.map(dish => 
    `- ${dish.name}: ${dish.description || ''} (${dish.price || 'Price not listed'})`
  ).join('\n');

  // Enhanced wine list formatting with exact names prominently displayed
  const winesText = restaurantWines.map((wine, index) => {
    const wineName = wine.name || wine.wine_name;
    const priceInfo = [];
    if (wine.price_glass) priceInfo.push(`Glass: ${wine.price_glass}`);
    if (wine.price_bottle) priceInfo.push(`Bottle: ${wine.price_bottle}`);
    const pricing = priceInfo.length > 0 ? ` (${priceInfo.join(', ')})` : '';
    
    return `${index + 1}. EXACT NAME: "${wineName}"${wine.vintage ? ` ${wine.vintage}` : ''}: ${wine.wine_type || 'Wine'} - ${wine.varietal || 'Unknown varietal'}${wine.region ? ` from ${wine.region}` : ''}${pricing}${wine.description ? ` - ${wine.description}` : ''}`;
  }).join('\n');

  // Replace placeholders in the prompt
  return basePrompt
    .replace('{{userBudget}}', budget?.toString() || userPreferences?.budget?.toString() || 'No specific budget')
    .replace('{{whiteWinePreference}}', userPreferences?.preferred_white_style || 'No preference')
    .replace('{{redWinePreference}}', userPreferences?.preferred_red_style || 'No preference')
    .replace('{{tastePreferences}}', `Tannin: ${userPreferences?.tannin || 'No preference'}, Sweetness: ${userPreferences?.sweetness || 'No preference'}, Acidity: ${userPreferences?.acidity || 'No preference'}`)
    .replace('{{restaurantName}}', restaurantName || 'Restaurant')
    .replace('{{selectedDishes}}', dishesText)
    .replace('{{availableWines}}', winesText || 'No wines available from restaurant list - use General Recommendations only');
};
