
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import Header from '@/components/Header';
import AdminDashboard from '@/components/admin/AdminDashboard';
import Copyright from '@/components/Copyright';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const Admin = () => {
  const { user } = useAuth();

  // Bulletproof admin check - kristimayfield@wine-wize.com ALWAYS gets admin access
  const isKristiAdmin = user?.email === 'kristimayfield@wine-wize.com';

  // Fetch user profile to check role - now works with fixed JWT claims
  const { data: profile, isLoading: profileLoading, error: profileError } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      try {
        console.log('Fetching profile for user:', user.id, 'email:', user.email);
        console.log('Using fixed JWT claims - should work now!');
        
        // Use maybeSingle() to prevent 400 errors - this should work with fixed JWT
        const { data, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle();
        
        if (error) {
          console.error('Error fetching profile:', error);
          console.log('Using email-based admin fallback for:', user.email);
          return { role: isKristiAdmin ? 'admin' : 'subscriber' };
        }
        
        if (!data) {
          console.log('No profile data found, using email fallback for:', user.email);
          return { role: isKristiAdmin ? 'admin' : 'subscriber' };
        }
        
        console.log('✅ Profile fetched successfully with fixed JWT:', data);
        return data.role ? data : { role: isKristiAdmin ? 'admin' : 'subscriber' };
      } catch (error) {
        console.error('Profile fetch error:', error);
        console.log('Exception caught, using email fallback for:', user.email);
        return { role: isKristiAdmin ? 'admin' : 'subscriber' };
      }
    },
    enabled: !!user?.id,
    retry: false,
  });

  // Determine admin status with bulletproof logic
  const isAdmin = isKristiAdmin || (profile?.role === 'admin');

  console.log('Admin access check with fixed JWT:', {
    userEmail: user?.email,
    isKristiAdmin,
    profileRole: profile?.role || 'unknown',
    finalIsAdmin: isAdmin,
    profileLoading,
    profileError: profileError?.message || 'none'
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-32 md:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8 pt-20 text-center">
          <p className="text-slate-600">Please log in to access the admin dashboard.</p>
        </div>
        <Copyright />
      </div>
    );
  }

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-32 md:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8 pt-20 text-center">
          <p className="text-slate-600">Loading admin access (with fixed JWT claims)...</p>
        </div>
        <Copyright />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-32 md:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8 pt-20 text-center">
          <h1 className="text-2xl font-bold text-slate-800 mb-4">Access Denied</h1>
          <p className="text-slate-600">You don't have permission to access the admin dashboard.</p>
          <div className="mt-4 text-sm text-slate-500">
            <p>User: {user.email}</p>
            <p>Role: {profile?.role || 'unknown'}</p>
            {profileError && (
              <p className="text-red-500 mt-2">Profile fetch error: {profileError.message}</p>
            )}
          </div>
        </div>
        <Copyright />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-32 md:pb-8">
      <Header />
      <div className="container mx-auto px-4 py-8 pt-20">
        {/* Ensure AdminDashboard stays mounted and doesn't cause navigation issues */}
        <div className="w-full">
          <AdminDashboard />
        </div>
      </div>
      <Copyright />
    </div>
  );
};

export default Admin;
