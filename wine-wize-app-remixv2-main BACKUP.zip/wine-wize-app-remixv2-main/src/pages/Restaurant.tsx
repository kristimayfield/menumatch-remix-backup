
import React from 'react';
import RestaurantPageHeader from '@/components/restaurant/RestaurantPageHeader';
import RestaurantLoadingState from '@/components/restaurant/RestaurantLoadingState';
import RestaurantErrorState from '@/components/restaurant/RestaurantErrorState';
import RestaurantSearch from '@/components/RestaurantSearch';
import RestaurantAgeWarning from '@/components/restaurant/RestaurantAgeWarning';
import RestaurantSearchWithImport from '@/components/restaurant/RestaurantSearchWithImport';
import RestaurantBottomNav from '@/components/restaurant/RestaurantBottomNav';
import BackButton from '@/components/navigation/BackButton';
import Copyright from '@/components/Copyright';
import SessionValidator from '@/components/auth/SessionValidator';
import { useRestaurantPage } from '@/hooks/useRestaurantPage';

const Restaurant = () => {
  const {
    searchTerm,
    setSearchTerm,
    restaurants,
    selectedRestaurant,
    isLoading,
    hasError,
    showAgeWarning,
    setShowAgeWarning,
    showImportOptions,
    filteredRestaurants,
    handleRestaurantSelect,
    handleUseExistingMenu,
    handleUploadNewImages,
    handleImportMenu,
    handleContinueToUpload
  } = useRestaurantPage();

  if (isLoading) {
    return <RestaurantLoadingState />;
  }

  return (
    <SessionValidator>
      <div className="min-h-screen bg-white pb-32 md:pb-8">
        <RestaurantPageHeader />
        <div className="container mx-auto px-4 max-w-2xl">
          {/* Back Button - prominently placed */}
          <div className="pt-4">
            <BackButton fallbackPath="/welcome" label="← Back to Welcome" />
          </div>

          {/* Error State */}
          <RestaurantErrorState 
            hasError={hasError} 
            restaurantsCount={restaurants.length} 
          />

          {/* Import Options Modal */}
          {showImportOptions && selectedRestaurant && (
            <div className="mb-8">
              <RestaurantSearchWithImport
                selectedRestaurant={selectedRestaurant}
                onImportMenu={handleImportMenu}
                onUploadImages={handleUploadNewImages}
              />
            </div>
          )}

          {/* Search Section - Hide when showing import options */}
          {!showImportOptions && (
            <RestaurantSearch
              restaurants={restaurants}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              filteredRestaurants={filteredRestaurants}
              onRestaurantSelect={handleRestaurantSelect}
              onContinueToMenu={handleContinueToUpload}
            />
          )}

          {/* Age Warning Modal */}
          <RestaurantAgeWarning
            isOpen={showAgeWarning}
            onClose={() => setShowAgeWarning(false)}
            restaurantName={selectedRestaurant?.name || ''}
            onUseExisting={handleUseExistingMenu}
            onUploadNew={handleUploadNewImages}
          />

          {/* Navigation - Fixed bottom bar */}
          <RestaurantBottomNav />
        </div>
        <Copyright />
      </div>
    </SessionValidator>
  );
};

export default Restaurant;
