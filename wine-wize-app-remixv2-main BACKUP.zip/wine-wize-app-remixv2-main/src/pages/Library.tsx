
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Wine, Star, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import Header from '@/components/Header';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface WineLibraryItem {
  id: string;
  wine_name: string;
  wine_description: string;
  wine_style: string;
  confidence_level: string;
  price: string;
  dish_paired_with: string;
  rating: number | null;
  created_at: string;
}

const Library = () => {
  const [wines, setWines] = useState<WineLibraryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [selectedWine, setSelectedWine] = useState<WineLibraryItem | null>(null);
  const [rating, setRating] = useState(0);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      loadWineLibrary();
    }
  }, [user]);

  const loadWineLibrary = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_wine_library')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setWines(data || []);
    } catch (error) {
      console.error('Error loading wine library:', error);
      toast({
        title: "Error",
        description: "Failed to load your wine library",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRateWine = async (wine: WineLibraryItem) => {
    setSelectedWine(wine);
    setRating(wine.rating || 0);
    setShowRatingModal(true);
  };

  const submitRating = async () => {
    if (!selectedWine || !user) return;

    try {
      const { error } = await supabase
        .from('user_wine_library')
        .update({ rating })
        .eq('id', selectedWine.id);

      if (error) throw error;

      // Track rating interaction
      await supabase
        .from('wine_interactions')
        .insert({
          user_id: user.id,
          interaction_type: 'rate',
          wine_name: selectedWine.wine_name,
          wine_style: selectedWine.wine_style,
          dish_name: selectedWine.dish_paired_with,
          rating
        });

      // Update local state
      setWines(wines.map(wine => 
        wine.id === selectedWine.id ? { ...wine, rating } : wine
      ));

      toast({
        title: "Rating saved!",
        description: `You rated ${selectedWine.wine_name} ${rating} star${rating !== 1 ? 's' : ''}`,
      });

      setShowRatingModal(false);
    } catch (error) {
      console.error('Error saving rating:', error);
      toast({
        title: "Error",
        description: "Failed to save rating",
        variant: "destructive",
      });
    }
  };

  const removeWine = async (wineId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('user_wine_library')
        .delete()
        .eq('id', wineId);

      if (error) throw error;

      setWines(wines.filter(wine => wine.id !== wineId));
      toast({
        title: "Wine removed",
        description: "Wine has been removed from your library",
      });
    } catch (error) {
      console.error('Error removing wine:', error);
      toast({
        title: "Error",
        description: "Failed to remove wine",
        variant: "destructive",
      });
    }
  };

  const getRatingLabel = (stars: number) => {
    switch (stars) {
      case 1: return "Not my favorite";
      case 2: return "Not great";
      case 3: return "I'd drink it again";
      case 4: return "Really good";
      case 5: return "I want more!";
      default: return "Rate this wine";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <Wine className="w-8 h-8 animate-pulse mx-auto mb-4 text-purple-600" />
          <p className="text-slate-600">Loading your wine library...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <Header />
      <div className="container mx-auto px-4 py-8 pt-20">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to="/pairings">
            <ArrowLeft className="w-6 h-6 text-slate-600 hover:text-slate-800" />
          </Link>
          <h1 className="text-2xl font-bold text-slate-800">My Wine Library</h1>
        </div>

        {/* Wine Library */}
        {wines.length > 0 ? (
          <div className="space-y-4">
            {wines.map((wine) => (
              <div key={wine.id} className="bg-white rounded-xl p-6 shadow-lg border border-slate-100">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-800 mb-2">{wine.wine_name}</h3>
                    <p className="text-slate-600 mb-2">{wine.wine_style}</p>
                    <p className="text-sm text-purple-600 mb-2">Paired with: {wine.dish_paired_with}</p>
                    <p className="text-green-600 font-semibold">{wine.price}</p>
                  </div>
                  <Wine className="w-8 h-8 text-purple-600" />
                </div>

                <p className="text-slate-600 mb-4">{wine.wine_description}</p>

                <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                  <div className="flex items-center gap-4">
                    {/* Rating Display/Button */}
                    <Button
                      variant="outline"
                      onClick={() => handleRateWine(wine)}
                      className="flex items-center gap-2"
                    >
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              wine.rating && wine.rating >= star 
                                ? 'text-amber-400 fill-current' 
                                : 'text-slate-300'
                            }`}
                          />
                        ))}
                      </div>
                      {wine.rating ? getRatingLabel(wine.rating) : 'Rate Wine'}
                    </Button>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => removeWine(wine.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100 text-center">
            <Wine className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-800 mb-2">Your Library is Empty</h2>
            <p className="text-slate-600 mb-6">
              Start discovering wines by exploring restaurant pairings!
            </p>
            <Link to="/welcome">
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
                Discover Wines
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* Rating Modal */}
      <Dialog open={showRatingModal} onOpenChange={setShowRatingModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Rate Your Wine</DialogTitle>
          </DialogHeader>
          <div className="text-center">
            {selectedWine && (
              <>
                <h3 className="font-semibold text-lg mb-4">{selectedWine.wine_name}</h3>
                <p className="text-slate-600 mb-6">How would you rate this wine?</p>
                
                <div className="flex justify-center gap-2 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRating(star)}
                      className={`w-8 h-8 ${
                        rating >= star ? 'text-amber-400' : 'text-slate-300'
                      } hover:text-amber-400 transition-colors`}
                    >
                      <Star className="w-8 h-8 fill-current" />
                    </button>
                  ))}
                </div>
                
                <p className="text-sm text-slate-600 mb-6">{getRatingLabel(rating)}</p>
                
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setShowRatingModal(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button 
                    onClick={submitRating}
                    disabled={rating === 0}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                  >
                    Save Rating
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Library;
