
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { RotateCcw, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { usePairingPopup } from '@/contexts/PairingPopupContext';
import Header from '@/components/Header';
import ProgressSteps from '@/components/ProgressSteps';
import LoadingAnimation from '@/components/LoadingAnimation';
import DishWinePairingBlock from '@/components/DishWinePairingBlock';
import ConsolidatedPairingCard from '@/components/ConsolidatedPairingCard';
import BackButton from '@/components/navigation/BackButton';

interface WineRecommendation {
  wineName: string;
  wineType: string;
  wineStyle: string;
  description: string;
  confidenceLevel: string;
  price: string;
}

interface DishRecommendation {
  dish: string;
  dishDescription: string;
  dishPrice: string;
  pairings: WineRecommendation[];
}

const Pairings = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [recommendations, setRecommendations] = useState<DishRecommendation[]>([]);
  const [restaurantName, setRestaurantName] = useState<string>('');
  const [debugInfo, setDebugInfo] = useState<any>(null);
  const [isRecentlyGenerated, setIsRecentlyGenerated] = useState(false);
  const [selectedDishes, setSelectedDishes] = useState<string[]>([]);
  const [consolidatedPairings, setConsolidatedPairings] = useState<any[]>([]);
  const { user } = useAuth();
  const { toast } = useToast();
  const { hidePopup } = usePairingPopup();

  useEffect(() => {
    // Show loading animation for 2 seconds
    const loadingTimer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    // Load recommendations from session storage (fast mode)
    const loadSessionRecommendations = () => {
      try {
        // Try session storage first (fast mode)
        const sessionRecommendations = sessionStorage.getItem('sessionWinePairings');
        const sessionRestaurant = sessionStorage.getItem('currentSessionRestaurant');
        const sessionSelectedDishes = sessionStorage.getItem('sessionSelectedDishes');
        
        console.log('Loading session recommendations...');
        console.log('Raw sessionRecommendations:', sessionRecommendations);
        console.log('Raw sessionRestaurant:', sessionRestaurant);
        
        if (sessionRecommendations && sessionRestaurant) {
          const parsed = JSON.parse(sessionRecommendations);
          const restaurant = JSON.parse(sessionRestaurant);
          
          console.log('Parsed recommendations:', parsed);
          console.log('Restaurant info:', restaurant);
          
          // Load selected dishes for consolidated pairing card
          if (sessionSelectedDishes) {
            const dishes = JSON.parse(sessionSelectedDishes);
            setSelectedDishes(dishes.map(dish => dish.id));
          }
          
          // Check if this is recently generated data (within last 5 seconds)
          const lastGenerated = sessionStorage.getItem('pairingsGeneratedAt');
          const isRecent = lastGenerated && (Date.now() - parseInt(lastGenerated)) < 5000;
          setIsRecentlyGenerated(!!isRecent);
          
          // Validation and debugging
          if (Array.isArray(parsed) && parsed.length > 0) {
            console.log('Sample recommendation structure:', parsed[0]);
            console.log('First recommendation pairings:', parsed[0]?.pairings);
            
            // Check if pairings exist and are valid
            const totalWines = parsed.reduce((sum, dish) => sum + (dish.pairings?.length || 0), 0);
            console.log(`Total wine pairings found: ${totalWines}`);
            
            setDebugInfo({
              dishCount: parsed.length,
              totalWines,
              sampleStructure: parsed[0],
              isRecentlyGenerated: isRecent
            });

            // Auto-dismiss the global popup when results are loaded
            setTimeout(() => {
              hidePopup();
            }, 500);
          } else {
            console.warn('Parsed recommendations is not a valid array:', parsed);
            setDebugInfo({ error: 'Invalid recommendations structure', data: parsed });
            hidePopup();
          }
          
          setRecommendations(parsed);
          setRestaurantName(restaurant.name);
        } else {
          console.log('No session data found, checking localStorage...');
          // Fallback to localStorage for backward compatibility
          const savedRecommendations = localStorage.getItem('winePairings');
          if (savedRecommendations) {
            const parsed = JSON.parse(savedRecommendations);
            console.log('Loaded localStorage recommendations:', parsed);
            setRecommendations(parsed);
          } else {
            console.log('No recommendations found in session or local storage');
            setDebugInfo({ error: 'No pairing data found' });
          }
          hidePopup();
        }
      } catch (error) {
        console.error('Error loading recommendations:', error);
        setDebugInfo({ error: error.message, stack: error.stack });
        hidePopup();
      }
    };

    loadSessionRecommendations();

    // Track page view interaction
    if (user) {
      supabase
        .from('wine_interactions')
        .insert({
          user_id: user.id,
          interaction_type: 'view',
          wine_name: '',
          dish_name: 'Multiple dishes pairing view'
        });
    }

    return () => {
      clearTimeout(loadingTimer);
    };
  }, [user, hidePopup]);

  const handleConsolidatedPairingsGenerated = (pairings: any[]) => {
    setConsolidatedPairings(pairings);
  };

  if (isLoading) {
    return <LoadingAnimation />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-32 md:pb-8">
      <Header />
      <div className="container mx-auto px-4 py-8 pt-28">
        {/* Header with centered title and left-aligned back button */}
        <div className="relative flex items-center justify-center mb-8">
          <div className="absolute left-0">
            <BackButton fallbackPath="/dishes" />
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-bold text-purple-600 flex items-center justify-center gap-2">
              🍷 ✨ Your Wine Recommendations
              {isRecentlyGenerated && (
                <span className="text-sm bg-green-100 text-green-700 px-2 py-1 rounded-full font-normal">
                  Fresh
                </span>
              )}
            </h1>
            <p className="text-slate-600 mt-2">
              Personalized wine pairings for your selected dishes{restaurantName && ` from ${restaurantName}`}, crafted by AI sommelier expertise.
            </p>
          </div>
        </div>

        {/* Progress Indicator */}
        <ProgressSteps currentStep={5} />

        {/* Debug Information (only show if there are issues) */}
        {debugInfo && (debugInfo.error || debugInfo.totalWines === 0) && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-amber-800 mb-2">Debug Information:</h3>
            <pre className="text-sm text-amber-700 overflow-x-auto">
              {JSON.stringify(debugInfo, null, 2)}
            </pre>
          </div>
        )}

        {/* Success Message */}
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6 mb-8">
          <h2 className="text-xl font-semibold text-green-800 mb-2 flex items-center gap-2">
            🎉 Perfect Pairings Found!
            {isRecentlyGenerated && (
              <span className="text-sm bg-green-200 text-green-800 px-2 py-1 rounded-full font-normal">
                Newly Generated
              </span>
            )}
          </h2>
          <p className="text-green-700">
            Our AI sommelier analyzed your selections and found excellent wine matches from the restaurant's list.
            {recommendations.length > 0 && (
              <span className="block mt-2 font-medium">
                Pairing recommendations for {recommendations.length} dish{recommendations.length > 1 ? 'es' : ''}
                {debugInfo?.totalWines > 0 && ` with ${debugInfo.totalWines} wine pairings`}
              </span>
            )}
          </p>
          <p className="text-green-700 mt-2 text-sm">
            We recognize we may have recommended a wine outside your desired budget, if so, these are identified with a red "💲".
          </p>
        </div>

        {/* Consolidated Pairing Card - only show if we have selected dishes */}
        {selectedDishes.length > 0 && (
          <ConsolidatedPairingCard 
            selectedDishes={selectedDishes}
            onPairingsGenerated={handleConsolidatedPairingsGenerated}
          />
        )}
        
        {/* Show consolidated results if available */}
        {consolidatedPairings.length > 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 border border-amber-200">
            <h3 className="text-xl font-bold text-amber-800 mb-4">
              🍷 Table Wine Recommendations
            </h3>
            <div className="grid gap-4">
              {consolidatedPairings.map((wine, index) => (
                <div key={index} className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-lg p-4 border border-amber-100">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-amber-800">{wine.wineName}</h4>
                    <span className="text-amber-700 font-medium">{wine.price}</span>
                  </div>
                  <p className="text-sm text-amber-700 mb-2">{wine.wineType} • {wine.wineStyle}</p>
                  <p className="text-sm text-amber-700 mb-2">{wine.description}</p>
                  <p className="text-xs text-amber-600 italic">{wine.dishCompatibility}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Wine Pairings Blocks */}
        {recommendations.length > 0 ? (
          <div className="space-y-6">
            {recommendations.map((dishRec, index) => {
              console.log(`Rendering dish ${index}:`, dishRec.dish, 'with', dishRec.pairings?.length || 0, 'wines');
              return (
                <DishWinePairingBlock
                  key={`${dishRec.dish}-${index}`}
                  dishName={dishRec.dish}
                  dishDescription={dishRec.dishDescription}
                  dishPrice={dishRec.dishPrice}
                  wines={dishRec.pairings || []}
                />
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100 text-center mb-8">
            <p className="text-slate-600 text-lg mb-4">
              No wine pairings available. Please go back and generate recommendations.
            </p>
            {debugInfo && (
              <details className="text-left">
                <summary className="cursor-pointer text-sm text-slate-500 mb-2">View Debug Info</summary>
                <pre className="text-xs bg-slate-100 p-2 rounded overflow-x-auto">
                  {JSON.stringify(debugInfo, null, 2)}
                </pre>
              </details>
            )}
          </div>
        )}

        {/* Navigation Actions */}
        <div className="space-y-4 mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <BackButton 
              fallbackPath="/dishes"
              label="Go Back to Dishes"
              className="w-full justify-center border border-slate-300 bg-white hover:bg-slate-50 h-12"
            />
            <Link to="/profile">
              <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white flex items-center gap-2 h-12">
                <BookOpen className="w-4 h-4" />
                Finish and View Library
              </Button>
            </Link>
          </div>
          
          <Link to="/welcome" className="block">
            <Button variant="outline" className="w-full flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              Start Over
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Pairings;
