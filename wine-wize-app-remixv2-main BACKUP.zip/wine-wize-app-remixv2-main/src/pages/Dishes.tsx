
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useFastDishesLogic } from '@/hooks/useFastDishesLogic';
import { useFastWinePairing } from '@/hooks/useFastWinePairing';
import { usePairingPopup } from '@/contexts/PairingPopupContext';
import DishesHeader from '@/components/DishesHeader';
import DishesContent from '@/components/DishesContent';
import DishesLoadingState from '@/components/DishesLoadingState';
import NoMenuDataModal from '@/components/NoMenuDataModal';
import UsageIndicator from '@/components/subscription/UsageIndicator';
import UpgradePrompt from '@/components/subscription/UpgradePrompt';
import BackButton from '@/components/navigation/BackButton';

const Dishes = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { showPopup } = usePairingPopup();
  
  const {
    sessionResults,
    sessionRestaurant,
    isLoading,
    hasValidSession,
    showNoDataModal,
    menuItems,
    filteredItems,
    selectedDishes,
    searchTerm,
    setSearchTerm,
    handleDishSelect,
    clearAllSelections,
    setShowNoDataModal,
  } = useFastDishesLogic();

  const { 
    isGeneratingPairings, 
    generateWinePairings, 
    usageStats,
    showUpgradePrompt,
    setShowUpgradePrompt
  } = useFastWinePairing();

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      navigate('/login');
      return;
    }
  }, [user, authLoading, navigate]);

  const handleGeneratePairings = async () => {
    if (selectedDishes.length === 0) {
      toast({
        title: "No dishes selected",
        description: "Please select dishes to get wine recommendations",
        variant: "destructive",
      });
      return;
    }

    try {
      // Show global popup immediately
      showPopup();
      await generateWinePairings(selectedDishes);
      // Popup will be closed automatically on the pairings page when results load
    } catch (error) {
      console.error('Error generating pairings:', error);
    }
  };

  if (authLoading || isLoading) {
    return <DishesLoadingState restaurantName={sessionRestaurant?.name || 'Loading...'} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-40 md:pb-8">
      <DishesHeader />
      
      {/* Back Button - prominently placed */}
      <div className="container mx-auto px-4 mb-4">
        <BackButton fallbackPath="/upload" label="← Back to Upload" />
      </div>
      
      {/* Usage Indicator */}
      {hasValidSession && (
        <div className="container mx-auto px-4 mb-4">
          <UsageIndicator
            pairingsUsed={usageStats.pairingsUsed}
            pairingsLimit={usageStats.pairingsLimit}
            subscriptionTier={usageStats.subscriptionTier}
          />
        </div>
      )}

      {/* No Session Data Modal */}
      <NoMenuDataModal
        isOpen={showNoDataModal}
        onClose={() => setShowNoDataModal(false)}
        restaurantName={sessionRestaurant?.name || 'Unknown Restaurant'}
      />

      {/* Upgrade Prompt */}
      <UpgradePrompt
        isOpen={showUpgradePrompt}
        onClose={() => setShowUpgradePrompt(false)}
        currentTier={usageStats.subscriptionTier}
        pairingsUsed={usageStats.pairingsUsed}
        pairingsLimit={usageStats.pairingsLimit}
      />

      {/* Only show content if we have valid session data */}
      {hasValidSession && (
        <DishesContent
          restaurantName={sessionRestaurant?.name || 'Unknown Restaurant'}
          menuItems={menuItems}
          filteredItems={filteredItems}
          selectedDishes={selectedDishes}
          searchTerm={searchTerm}
          isGeneratingPairings={isGeneratingPairings}
          onSearchChange={setSearchTerm}
          onDishSelect={handleDishSelect}
          onClearAllSelections={clearAllSelections}
          onGeneratePairings={handleGeneratePairings}
        />
      )}
    </div>
  );
};

export default Dishes;
