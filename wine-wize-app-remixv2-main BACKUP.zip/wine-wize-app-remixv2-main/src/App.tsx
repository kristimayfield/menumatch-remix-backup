
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { PairingPopupProvider } from "@/contexts/PairingPopupContext";
import { useNavigationGuards } from "@/hooks/useNavigationGuards";
import { useAgeVerification } from "@/hooks/useAgeVerification";
import BottomNav from "@/components/navigation/BottomNav";
import QuickActions from "@/components/navigation/QuickActions";
import AgeVerificationModal from "@/components/AgeVerificationModal";
import GlobalPairingPopup from "@/components/GlobalPairingPopup";
import Index from "./pages/Index";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Register from "./pages/Register";
import EmailConfirmation from "./pages/EmailConfirmation";
import ConfirmationHandler from "./pages/ConfirmationHandler";
import ForgotPassword from "./pages/ForgotPassword";
import Welcome from "./pages/Welcome";
import Restaurant from "./pages/Restaurant";
import Upload from "./pages/Upload";
import Dishes from "./pages/Dishes";
import Pairings from "./pages/Pairings";
import Library from "./pages/Library";
import WinePreferences from "./pages/WinePreferences";
import AgeRestricted from "./pages/AgeRestricted";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";
import PaymentSuccess from "./pages/PaymentSuccess";
import PaymentCancel from "./pages/PaymentCancel";
import Subscription from "./pages/Subscription";
import TrialExpiredModal from "./components/modals/TrialExpiredModal";
import { useTrialStatus } from "./hooks/useTrialStatus";
import TermsAndConditions from "./pages/TermsAndConditions";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import CookiePolicy from "./pages/CookiePolicy";

const queryClient = new QueryClient();

// Component that wraps the routes and includes navigation guards
const AppRoutes = () => {
  useNavigationGuards();
  const { showModal, isLoading, verifyAge } = useAgeVerification();
  const { showTrialExpiredModal, dismissTrialModal } = useTrialStatus();
  
  // Don't render anything while checking age verification
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            Wine Wize
          </h1>
          <div className="w-8 h-8 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/home" element={<Home />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/email-confirmation" element={<EmailConfirmation />} />
        <Route path="/confirm" element={<ConfirmationHandler />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/restaurant" element={<Restaurant />} />
        <Route path="/upload" element={<Upload />} />
        <Route path="/dishes" element={<Dishes />} />
        <Route path="/pairings" element={<Pairings />} />
        <Route path="/library" element={<Library />} />
        <Route path="/wine-preferences" element={<WinePreferences />} />
        <Route path="/age-restricted" element={<AgeRestricted />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/payment-success" element={<PaymentSuccess />} />
        <Route path="/payment-cancel" element={<PaymentCancel />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/terms-and-conditions" element={<TermsAndConditions />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/cookie-policy" element={<CookiePolicy />} />
        {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
        <Route path="*" element={<NotFound />} />
      </Routes>
      
      {/* Age Verification Modal */}
      <AgeVerificationModal 
        isOpen={showModal} 
        onVerify={verifyAge} 
      />
      
      {/* Trial Expired Modal */}
      <TrialExpiredModal 
        isOpen={showTrialExpiredModal} 
        onClose={dismissTrialModal} 
      />
      
      {/* Global Pairing Popup */}
      <GlobalPairingPopup />
      
      {/* Global Navigation Components */}
      <BottomNav />
      <QuickActions />
    </>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <PairingPopupProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </PairingPopupProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
