
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

export const useProcessingResults = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleProcessingSuccess = (
    data: any,
    setProcessingProgress: (progress: number) => void,
    setProcessingStep: (step: string) => void,
    setShowProcessingPopup: (show: boolean) => void
  ) => {
    setProcessingProgress(100);
    setProcessingStep('complete');
    
    console.log('=== PROCESSING SUCCESS ===');
    console.log('Results:', {
      menuItems: data.menuItems?.length || 0,
      wines: data.wines?.length || 0,
      restaurantId: data.restaurantId,
      restaurantName: data.restaurantName
    });
    
    // Store restaurant information for dishes page
    if (data.restaurantId && data.restaurantName) {
      localStorage.setItem('currentRestaurantId', data.restaurantId);
      localStorage.setItem('currentRestaurantName', data.restaurantName);
      console.log(`Stored restaurant info: ${data.restaurantName} (${data.restaurantId})`);
    } else {
      console.error('Missing restaurant information in response:', data);
      throw new Error('Invalid response: missing restaurant information');
    }
    
    // Clear legacy localStorage data since we're now using database
    localStorage.removeItem('availableWines');
    localStorage.removeItem('menuItems');
    
    // Small delay to show completion
    setTimeout(() => {
      setShowProcessingPopup(false);
      
      // Only navigate if we have valid data
      if (data.restaurantId && (data.menuItems?.length > 0 || data.wines?.length > 0)) {
        toast({
          title: "Processing complete!",
          description: `Found ${data.menuItems?.length || 0} dishes and ${data.wines?.length || 0} wines`,
        });
        
        console.log('Navigating to dishes page with fresh data');
        navigate('/dishes');
      } else {
        console.error('Cannot navigate: insufficient data');
        throw new Error('Processing completed but insufficient data was saved');
      }
    }, 1000);
  };

  const handleProcessingError = (
    error: any,
    processingSucceeded: boolean,
    setShowProcessingPopup: (show: boolean) => void
  ) => {
    setShowProcessingPopup(false);
    
    console.log('=== PROCESSING ERROR HANDLER ===');
    console.log('Error:', error.message);
    console.log('Processing succeeded:', processingSucceeded);
    
    // Enhanced error messaging with specific guidance
    let errorMessage = "Failed to analyze images. Please try again.";
    let errorTitle = "Processing failed";
    
    if (error.message.includes('session') || error.message.includes('Session')) {
      errorTitle = "Session expired";
      errorMessage = "Your session has expired. Please refresh the page and log in again.";
    } else if (error.message.includes('size') || error.message.includes('large')) {
      errorTitle = "Images too large";
      errorMessage = "Your images are too large. Please try taking new photos with lower resolution.";
    } else if (error.message.includes('timeout')) {
      errorTitle = "Request timed out";
      errorMessage = "The analysis took too long. Try uploading fewer images or ensure you have a stable internet connection.";
    } else if (error.message.includes('NetworkError') || error.message.includes('connection') || error.message.includes('fetch')) {
      errorTitle = "Connection issue";
      errorMessage = "Unable to connect to our servers. Please check your internet connection and try again.";
    } else if (error.message.includes('no menu items or wines')) {
      errorTitle = "No content detected";
      errorMessage = "We couldn't extract any menu items or wines from your images. Please ensure the images are clear and contain readable text.";
    } else if (error.message.includes('restaurant')) {
      errorTitle = "Restaurant setup failed";
      errorMessage = "Failed to set up restaurant record. Please go back and select your restaurant again.";
    } else if (error.message.includes('Edge function') || error.message.includes('analysis service')) {
      errorTitle = "Service temporarily unavailable";
      errorMessage = "Our analysis service is temporarily busy. Please wait a moment and try again.";
    } else if (error.message.includes('invocation failed')) {
      errorTitle = "Service connection failed";
      errorMessage = "Failed to connect to our analysis service. Please try again in a few moments.";
    } else {
      // Use the actual error message if it's descriptive and not too technical
      if (error.message && error.message.length < 100 && !error.message.includes('function') && !error.message.includes('API')) {
        errorMessage = error.message;
      }
    }
    
    console.log('Showing error toast:', { errorTitle, errorMessage });
    toast({
      title: errorTitle,
      description: errorMessage,
      variant: "destructive",
    });
  };

  return {
    handleProcessingSuccess,
    handleProcessingError
  };
};
