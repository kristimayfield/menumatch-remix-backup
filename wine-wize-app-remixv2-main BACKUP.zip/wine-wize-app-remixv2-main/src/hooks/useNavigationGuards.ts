
import { useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useSessionManager } from './useSessionManager';
import { useToast } from '@/hooks/use-toast';

interface NavigationGuard {
  path: string;
  requiresAuth: boolean;
  requiresRestaurant?: boolean;
  requiresSessionData?: boolean;
  redirectTo?: string;
}

const navigationRules: NavigationGuard[] = [
  // Authentication required routes
  { path: '/welcome', requiresAuth: true, redirectTo: '/login' },
  { path: '/restaurant', requiresAuth: true, redirectTo: '/login' },
  { path: '/upload', requiresAuth: true, requiresRestaurant: false, redirectTo: '/restaurant' }, // Made less strict
  { path: '/dishes', requiresAuth: true, requiresSessionData: true, redirectTo: '/restaurant' },
  { path: '/pairings', requiresAuth: true, requiresSessionData: true, redirectTo: '/restaurant' },
  { path: '/profile', requiresAuth: true, redirectTo: '/login' },
  { path: '/library', requiresAuth: true, redirectTo: '/login' },
  { path: '/wine-preferences', requiresAuth: true, redirectTo: '/login' },
];

export const useNavigationGuards = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading, authReady, refreshSession } = useAuth();
  const { hasValidSession } = useSessionManager();
  const { toast } = useToast();
  const lastProcessedPath = useRef<string>('');
  const guardTimeoutRef = useRef<NodeJS.Timeout>();
  const processingRef = useRef<boolean>(false);

  useEffect(() => {
    const currentPath = location.pathname;
    
    // Clear any existing timeout
    if (guardTimeoutRef.current) {
      clearTimeout(guardTimeoutRef.current);
    }

    // Don't process while auth is loading or not ready
    if (loading || !authReady) {
      console.log('Navigation guard: Auth loading or not ready, waiting...');
      return;
    }

    // Prevent duplicate processing
    if (processingRef.current || lastProcessedPath.current === currentPath) {
      return;
    }

    const rule = navigationRules.find(r => r.path === currentPath);
    
    if (!rule) {
      lastProcessedPath.current = currentPath;
      return; // No guard for this route
    }

    // Debounce navigation guard execution
    guardTimeoutRef.current = setTimeout(() => {
      processGuard(currentPath, rule);
    }, 100);

    return () => {
      if (guardTimeoutRef.current) {
        clearTimeout(guardTimeoutRef.current);
      }
    };
  }, [location.pathname, user, loading, authReady, hasValidSession, navigate, toast, refreshSession]);

  const processGuard = async (currentPath: string, rule: NavigationGuard) => {
    if (processingRef.current) return;
    
    processingRef.current = true;
    
    try {
      console.log(`Navigation guard: Processing ${currentPath}`);

      // Check authentication
      if (rule.requiresAuth && !user) {
        console.log(`Navigation guard: ${currentPath} requires auth, attempting session refresh first`);
        
        try {
          await refreshSession();
          // If refresh succeeds, the auth state will update and this effect will re-run
          return;
        } catch (refreshError) {
          console.log('Session refresh failed, redirecting to login');
          toast({
            title: "Authentication required",
            description: "Please log in to continue",
            variant: "destructive",
          });
          navigate(rule.redirectTo || '/login');
          return;
        }
      }

      // Special handling for upload route - more lenient restaurant check
      if (currentPath === '/upload' && user) {
        const restaurantId = localStorage.getItem('currentRestaurantId');
        const restaurantName = localStorage.getItem('currentRestaurantName');
        
        // For upload route, allow access even without restaurant if user is authenticated
        // The upload page itself will handle restaurant selection prompts
        if (!restaurantId || !restaurantName) {
          console.log('Upload route: No restaurant selected, but allowing access with prompt');
          // Don't redirect, let the upload page handle this
        }
      } else if (rule.requiresRestaurant && user) {
        // Strict restaurant check for other routes
        const restaurantId = localStorage.getItem('currentRestaurantId');
        const restaurantName = localStorage.getItem('currentRestaurantName');
        
        if (!restaurantId || !restaurantName) {
          console.log(`Navigation guard: ${currentPath} requires restaurant selection, redirecting to ${rule.redirectTo}`);
          toast({
            title: "Restaurant selection required",
            description: "Please select a restaurant first",
            variant: "destructive",
          });
          navigate(rule.redirectTo || '/restaurant');
          return;
        }
      }

      // Check session data (for dishes/pairings pages)
      if (rule.requiresSessionData && user) {
        if (!hasValidSession()) {
          console.log(`Navigation guard: ${currentPath} requires session data, redirecting to ${rule.redirectTo}`);
          toast({
            title: "No menu data found",
            description: "Please start a new session by selecting a restaurant and uploading images",
            variant: "destructive",
          });
          navigate(rule.redirectTo || '/restaurant');
          return;
        }
      }

      console.log(`Navigation guard: ${currentPath} passed all checks`);
    } catch (error) {
      console.error('Navigation guard error:', error);
      toast({
        title: "Navigation error",
        description: "Please try again or refresh the page",
        variant: "destructive",
      });
    } finally {
      lastProcessedPath.current = currentPath;
      processingRef.current = false;
    }
  };

  return null; // This hook doesn't render anything
};
