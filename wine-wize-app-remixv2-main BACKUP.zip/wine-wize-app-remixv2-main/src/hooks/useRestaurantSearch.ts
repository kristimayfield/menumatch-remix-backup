
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface Restaurant {
  id: string;
  name: string;
  location: string;
  cuisine_type: string;
  last_menu_update: string;
  created_at: string;
  updated_at: string;
}

export const useRestaurantSearch = () => {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const searchRestaurants = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setRestaurants([]);
      return;
    }

    setIsSearching(true);
    try {
      const { data, error } = await supabase
        .from('restaurants')
        .select('*')
        .or(`name.ilike.%${searchTerm}%,location.ilike.%${searchTerm}%,cuisine_type.ilike.%${searchTerm}%`)
        .order('updated_at', { ascending: false });

      if (error) {
        throw error;
      }

      setRestaurants(data || []);
    } catch (error) {
      console.error('Restaurant search error:', error);
      setRestaurants([]);
    } finally {
      setIsSearching(false);
    }
  }, []);

  const checkRestaurantAge = (restaurant: { last_menu_update: string; updated_at: string }): boolean => {
    const lastUpdate = new Date(restaurant.last_menu_update || restaurant.updated_at);
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    
    return lastUpdate < ninetyDaysAgo;
  };

  return {
    restaurants,
    isSearching,
    searchRestaurants,
    checkRestaurantAge
  };
};
