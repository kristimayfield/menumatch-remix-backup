
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const useSessionValidation = () => {
  const { refreshSession } = useAuth();

  const validateSession = async () => {
    console.log('Validating user session...');
    
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError) {
        console.error('Session error:', sessionError);
        
        // Try to refresh the session if there's an error
        try {
          console.log('Attempting to refresh session due to error...');
          await refreshSession();
          
          // Get the session again after refresh
          const { data: { session: refreshedSession }, error: refreshError } = await supabase.auth.getSession();
          
          if (refreshError || !refreshedSession?.access_token) {
            throw new Error('Session refresh failed');
          }
          
          console.log('Session successfully refreshed after error');
          return refreshedSession;
        } catch (refreshError) {
          console.error('Session refresh failed:', refreshError);
          throw new Error(`Session error: ${sessionError.message}. Refresh failed: ${refreshError.message}`);
        }
      }
      
      if (!session?.access_token) {
        console.error('No valid session found');
        
        // Try to refresh before giving up
        try {
          console.log('No valid session, attempting refresh...');
          await refreshSession();
          
          const { data: { session: refreshedSession }, error: refreshError } = await supabase.auth.getSession();
          
          if (refreshError || !refreshedSession?.access_token) {
            throw new Error('No valid session found and refresh failed');
          }
          
          console.log('Session successfully obtained after refresh');
          return refreshedSession;
        } catch (refreshError) {
          console.error('Session refresh failed:', refreshError);
          throw new Error('No valid session found. Please log in again.');
        }
      }

      console.log('Session validated successfully. User ID:', session.user.id);
      
      // Also check if the user's profile exists
      try {
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle();

        if (profileError) {
          console.error('Error fetching user profile:', profileError);
        } else if (profile) {
          console.log('User profile found:', {
            id: profile.id,
            firstName: profile.first_name,
            lastName: profile.last_name,
            email: profile.email,
            location: profile.location
          });
        } else {
          console.warn('No profile found for user:', session.user.id);
        }
      } catch (error) {
        console.error('Error checking user profile:', error);
      }
      
      return session;
    } catch (error) {
      console.error('Session validation failed:', error);
      throw error;
    }
  };

  return {
    validateSession
  };
};
