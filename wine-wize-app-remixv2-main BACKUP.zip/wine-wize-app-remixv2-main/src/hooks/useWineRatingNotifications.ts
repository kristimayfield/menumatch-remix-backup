
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface RatingReminder {
  id: string;
  user_id: string;
  wine_library_id: string;
  scheduled_for: string;
  sent: boolean;
  created_at: string;
  wine_name?: string;
  dish_paired_with?: string;
}

export const useWineRatingNotifications = (userId: string | undefined) => {
  const [reminders, setReminders] = useState<RatingReminder[]>([]);
  const [pendingReminders, setPendingReminders] = useState<RatingReminder[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      fetchReminders();
    }
  }, [userId]);

  const fetchReminders = async () => {
    if (!userId) return;
    
    setIsLoading(true);
    try {
      // Fetch all reminders with wine library details
      const { data: reminderData, error: reminderError } = await supabase
        .from('wine_rating_reminders')
        .select(`
          *,
          wine_library:user_wine_library!wine_rating_reminders_wine_library_id_fkey(
            wine_name,
            dish_paired_with
          )
        `)
        .eq('user_id', userId)
        .order('scheduled_for', { ascending: false });

      if (reminderError) throw reminderError;

      // Transform data to include wine details
      const transformedReminders = reminderData?.map(reminder => ({
        ...reminder,
        wine_name: reminder.wine_library?.wine_name,
        dish_paired_with: reminder.wine_library?.dish_paired_with
      })) || [];

      setReminders(transformedReminders);

      // Filter pending reminders (not sent and scheduled for past or today)
      const now = new Date();
      const pending = transformedReminders.filter(reminder => 
        !reminder.sent && new Date(reminder.scheduled_for) <= now
      );
      setPendingReminders(pending);

    } catch (error) {
      console.error('Error fetching rating reminders:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const markReminderAsSent = async (reminderId: string) => {
    try {
      const { error } = await supabase
        .from('wine_rating_reminders')
        .update({ sent: true })
        .eq('id', reminderId);

      if (error) throw error;

      // Update local state
      setReminders(prev => prev.map(reminder => 
        reminder.id === reminderId ? { ...reminder, sent: true } : reminder
      ));
      setPendingReminders(prev => prev.filter(reminder => reminder.id !== reminderId));

    } catch (error) {
      console.error('Error marking reminder as sent:', error);
    }
  };

  const createReminder = async (wineLibraryId: string, scheduledDate: Date) => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from('wine_rating_reminders')
        .insert({
          user_id: userId,
          wine_library_id: wineLibraryId,
          scheduled_for: scheduledDate.toISOString(),
          sent: false
        })
        .select()
        .single();

      if (error) throw error;

      await fetchReminders(); // Refresh the list
      return data;

    } catch (error) {
      console.error('Error creating reminder:', error);
      throw error;
    }
  };

  const deleteReminder = async (reminderId: string) => {
    try {
      const { error } = await supabase
        .from('wine_rating_reminders')
        .delete()
        .eq('id', reminderId);

      if (error) throw error;

      // Update local state
      setReminders(prev => prev.filter(reminder => reminder.id !== reminderId));
      setPendingReminders(prev => prev.filter(reminder => reminder.id !== reminderId));

    } catch (error) {
      console.error('Error deleting reminder:', error);
    }
  };

  return {
    reminders,
    pendingReminders,
    isLoading,
    markReminderAsSent,
    createReminder,
    deleteReminder,
    refetch: fetchReminders
  };
};
