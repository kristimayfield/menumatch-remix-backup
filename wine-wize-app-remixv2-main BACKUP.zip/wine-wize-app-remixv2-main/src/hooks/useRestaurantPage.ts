import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useSessionManager } from '@/hooks/useSessionManager';
import { useRestaurantSearch } from '@/hooks/useRestaurantSearch';
import { Restaurant, RestaurantData } from '@/types/restaurant';

export const useRestaurantPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [restaurants, setRestaurants] = useState<RestaurantData[]>([]);
  const [selectedRestaurant, setSelectedRestaurant] = useState<RestaurantData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [showAgeWarning, setShowAgeWarning] = useState(false);
  const [showImportOptions, setShowImportOptions] = useState(false);
  
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { startNewSession, clearAllData } = useSessionManager();
  const { checkRestaurantAge } = useRestaurantSearch();

  // Clear any existing session data when entering restaurant selection
  useEffect(() => {
    clearAllData();
  }, [clearAllData]);

  // Fetch restaurants from the restaurants table
  useEffect(() => {
    const fetchRestaurants = async () => {
      if (!user) {
        console.log('🔍 No user found, skipping restaurant fetch');
        return;
      }

      try {
        console.log('🔍 Starting restaurant fetch...');
        console.log('🔍 User ID:', user.id);
        console.log('🔍 User email:', user.email);
        
        // Simple query - JWT validation is handled by SessionValidator
        const { data, error } = await supabase
          .from('restaurants')
          .select('*')
          .order('name');

        if (error) {
          console.error('❌ Restaurant query failed:', error);
          throw error;
        }

        console.log('✅ Query successful. Raw data:', data);
        console.log(`✅ Fetched ${data?.length || 0} restaurants from database`);

        // Transform data to match the expected interface
        const transformedRestaurants: RestaurantData[] = data.map(restaurant => {
          console.log('🔄 Transforming restaurant:', restaurant);
          return {
            id: restaurant.id,
            name: restaurant.name,
            location: restaurant.location || 'Location not available',
            cuisine_type: restaurant.cuisine_type || 'Cuisine not specified',
            last_menu_update: restaurant.last_menu_update,
            created_at: restaurant.created_at,
            updated_at: restaurant.updated_at
          };
        });

        console.log('✅ Transformed restaurants:', transformedRestaurants);
        setRestaurants(transformedRestaurants);
        setHasError(false);
        
        if (transformedRestaurants.length === 0) {
          console.log('ℹ️ No restaurants found in database');
        }
      } catch (error) {
        console.error('❌ Error fetching restaurants:', error);
        setHasError(true);
        
        toast({
          title: "Database error",
          description: 'Failed to load restaurants. Please try again.',
          variant: "destructive",
        });
        setRestaurants([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRestaurants();
  }, [user, toast]);

  const handleRestaurantSelect = (restaurant: Restaurant) => {
    // Find the full restaurant data from our state
    const fullRestaurant = restaurants.find(r => r.id === restaurant.id);
    if (fullRestaurant) {
      setSelectedRestaurant(fullRestaurant);
      console.log('Selected restaurant:', fullRestaurant);
      
      // Create a compatible restaurant object for age checking
      const restaurantForAgeCheck = {
        ...fullRestaurant,
        last_menu_update: fullRestaurant.last_menu_update || fullRestaurant.updated_at
      };
      
      // Check if restaurant data is older than 90 days
      if (checkRestaurantAge(restaurantForAgeCheck)) {
        setShowAgeWarning(true);
      } else {
        setShowImportOptions(true);
      }
      
      // Set restaurant context immediately for proper name display
      localStorage.setItem('currentRestaurantId', fullRestaurant.id);
      localStorage.setItem('currentRestaurantName', fullRestaurant.name);
    } else {
      // Convert to RestaurantData type for new restaurants
      const restaurantData: RestaurantData = {
        ...restaurant,
        last_menu_update: undefined,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      setSelectedRestaurant(restaurantData);
      setShowImportOptions(true);
      localStorage.setItem('currentRestaurantId', restaurantData.id);
      localStorage.setItem('currentRestaurantName', restaurantData.name);
    }
  };

  const handleUseExistingMenu = () => {
    setShowAgeWarning(false);
    console.log('Using existing menu for restaurant:', selectedRestaurant);
    navigate('/dishes');
  };

  const handleUploadNewImages = () => {
    setShowAgeWarning(false);
    setShowImportOptions(false);
    console.log('Uploading new images for restaurant:', selectedRestaurant);
    navigate('/upload');
  };

  const handleImportMenu = async () => {
    if (!selectedRestaurant) return;
    
    setShowImportOptions(false);
    console.log('Importing menu for restaurant:', selectedRestaurant);
    
    try {
      // Clear any session data to ensure we load from database
      sessionStorage.removeItem('currentSessionResults');
      sessionStorage.removeItem('currentSessionRestaurant');
      
      // Ensure restaurant context is set for dishes page
      localStorage.setItem('currentRestaurantId', selectedRestaurant.id);
      localStorage.setItem('currentRestaurantName', selectedRestaurant.name);
      
      console.log('Restaurant context set for import:', {
        id: selectedRestaurant.id,
        name: selectedRestaurant.name
      });
      
      // Navigate to dishes page - it will load data from database
      navigate('/dishes');
    } catch (error) {
      console.error('Error importing menu:', error);
      toast({
        title: "Import failed",
        description: "Failed to import menu data. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleContinueToUpload = () => {
    if (selectedRestaurant) {
      console.log('Continuing to upload page with restaurant:', selectedRestaurant);
      navigate('/upload');
    } else {
      // Allow continuing without a selected restaurant
      console.log('Continuing to upload page without specific restaurant');
      navigate('/upload');
    }
  };

  const filteredRestaurants = restaurants.filter(restaurant =>
    searchTerm.trim() && (
      restaurant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      restaurant.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      restaurant.cuisine_type.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return {
    searchTerm,
    setSearchTerm,
    restaurants,
    selectedRestaurant,
    isLoading,
    hasError,
    showAgeWarning,
    setShowAgeWarning,
    showImportOptions,
    filteredRestaurants,
    handleRestaurantSelect,
    handleUseExistingMenu,
    handleUploadNewImages,
    handleImportMenu,
    handleContinueToUpload
  };
};
