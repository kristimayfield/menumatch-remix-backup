
import { useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export const useForceLogout = () => {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const logoutInProgress = useRef(false);

  const checkAndFixJWTIssue = async () => {
    if (!user || logoutInProgress.current) return false;

    try {
      // Test if the current session has the JWT role issue
      console.log('🔍 Testing for JWT role issue...');
      const { data, error } = await supabase
        .from('restaurants')
        .select('id')
        .limit(1);

      if (error && error.message?.includes('role') && error.message?.includes('does not exist')) {
        console.error('🚨 JWT ROLE CLAIMS ERROR DETECTED - FORCING LOGOUT');
        
        // Prevent multiple simultaneous logout attempts
        if (logoutInProgress.current) return true;
        logoutInProgress.current = true;
        
        toast({
          title: "Authentication Issue Detected",
          description: "Your session has expired. Please log in again.",
          variant: "destructive",
        });

        // Force complete logout immediately
        try {
          await supabase.auth.signOut();
          // Clear any remaining session storage
          sessionStorage.clear();
          localStorage.removeItem('supabase.auth.token');
          
          // Force page reload to completely clear state
          window.location.href = '/login';
        } catch (logoutError) {
          console.error('❌ Error during forced logout:', logoutError);
          // Force page reload as fallback
          window.location.reload();
        }

        return true; // Indicates we detected and are fixing the issue
      }

      console.log('✅ No JWT role issue detected');
      return false;
    } catch (error) {
      console.error('❌ Error checking JWT issue:', error);
      return false;
    }
  };

  return { checkAndFixJWTIssue };
};
