
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useSessionResults } from './useSessionResults';
import { useUsageTracking } from './useUsageTracking';

export const useFastWinePairing = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const { sessionResults } = useSessionResults();
  const { usageStats, trackPairing, canGeneratePairing } = useUsageTracking();
  const [isGeneratingPairings, setIsGeneratingPairings] = useState(false);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);

  const generateWinePairings = async (selectedDishes: string[]) => {
    if (selectedDishes.length === 0) {
      toast({
        title: "No dishes selected",
        description: "Please select at least one dish to get wine pairings.",
        variant: "destructive",
      });
      return;
    }

    // Check usage limits
    if (!canGeneratePairing()) {
      setShowUpgradePrompt(true);
      return;
    }

    if (!sessionResults) {
      toast({
        title: "No session data",
        description: "Please process menu images first.",
        variant: "destructive",
      });
      return;
    }

    console.log('=== GENERATING FRESH WINE PAIRINGS ===');
    console.log(`Selected ${selectedDishes.length} dishes from ${sessionResults.restaurantName}`);

    // Clear old pairing data to prevent stale data from showing
    console.log('Clearing previous pairing data...');
    sessionStorage.removeItem('sessionWinePairings');
    sessionStorage.removeItem('sessionSelectedDishes');
    sessionStorage.removeItem('pairingsGeneratedAt');

    setIsGeneratingPairings(true);

    try {
      // Track usage before generating
      const canProceed = await trackPairing();
      if (!canProceed) {
        setShowUpgradePrompt(true);
        return;
      }

      // Get selected dish details from session data
      const selectedDishDetails = sessionResults.menuItems.filter(item => 
        selectedDishes.includes(item.id)
      );

      console.log('Selected dish details:', selectedDishDetails);

      // CRITICAL FIX: STRICT session-only wine validation
      const sessionWines = sessionResults.wines || [];
      
      // ENHANCED VALIDATION: Ensure wines are session-only (no database fields)
      const cleanSessionWines = sessionWines.filter(wine => {
        // Session wines should NOT have database-specific fields
        const isSessionWine = !wine.restaurant_id && !wine.ww_style && !wine.created_at;
        if (!isSessionWine) {
          console.error('CONTAMINATED WINE DETECTED (has database fields):', wine);
        }
        return isSessionWine;
      }).map(wine => ({
        // Ensure only session wine fields are included
        name: wine.name || wine.wine_name,
        vintage: wine.vintage || '',
        varietal: wine.varietal || '',
        region: wine.region || '',
        price_glass: wine.price_glass || '',
        price_bottle: wine.price_bottle || '',
        wine_type: wine.wine_type || '',
        wine_style: wine.wine_style || '',
        description: wine.description || ''
      }));

      console.log('=== WINE DATA SOURCE VALIDATION ===');
      console.log(`Original session wines: ${sessionWines.length}`);
      console.log(`Clean session wines: ${cleanSessionWines.length}`);
      console.log('Clean session wines sample:', cleanSessionWines.slice(0, 2));

      // Strict validation: Ensure we have clean session wines
      if (!cleanSessionWines || cleanSessionWines.length === 0) {
        console.error('CRITICAL: No clean session wines found');
        console.log('Original session wines:', sessionWines);
        
        toast({
          title: "Wine list not processed",
          description: "We couldn't find any wines from your uploaded images. Please go back and ensure you've included clear photos of the wine list.",
          variant: "destructive",
        });
        return;
      }

      // Get user wine preferences
      let userPreferences = null;
      try {
        const { data: preferences } = await supabase
          .from('wine_preferences')
          .select('*')
          .eq('user_id', user?.id)
          .single();
        
        userPreferences = preferences;
        console.log('User preferences loaded:', userPreferences);
      } catch (error) {
        console.log('No wine preferences found, using defaults');
      }

      // Get session for authorization
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('No valid session found. Please log in again.');
      }

      // Prepare pairing request with STRICT SESSION-ONLY DATA
      const pairingRequest = {
        dishes: selectedDishDetails.map(dish => ({
          id: dish.id,
          name: dish.dish_name,
          description: dish.description,
          price: dish.price,
          ingredients: dish.ingredients,
          type: dish.dish_type
        })),
        availableWines: cleanSessionWines, // CRITICAL: Use only clean session wines
        userPreferences: userPreferences,
        budget: userPreferences?.budget || 50,
        restaurantName: sessionResults.restaurantName,
        restaurantId: sessionResults.restaurantId,
        sessionMode: true, // Flag for session-based pairing
        consolidatedMode: false // Use individual pairings
      };

      console.log('=== PAIRING REQUEST VALIDATION ===');
      console.log(`Dishes: ${pairingRequest.dishes.length}`);
      console.log(`Available wines: ${pairingRequest.availableWines.length}`);
      console.log('Wine source: CLEAN SESSION DATA ONLY');

      // Call wine pairing function
      const { data, error } = await supabase.functions.invoke('wine-pairing-fast', {
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
        body: pairingRequest
      });

      if (error) {
        console.error('Wine pairing function error:', error);
        throw new Error(`Pairing generation failed: ${error.message}`);
      }

      if (!data || !data.success) {
        console.error('Wine pairing failed:', data?.error);
        throw new Error(data?.error || 'Failed to generate wine pairings');
      }

      console.log('Fresh wine pairings generated successfully:', data.pairings);

      // Store NEW pairings in session storage with timestamp
      sessionStorage.setItem('sessionWinePairings', JSON.stringify(data.pairings));
      sessionStorage.setItem('sessionSelectedDishes', JSON.stringify(selectedDishDetails));
      sessionStorage.setItem('pairingsGeneratedAt', Date.now().toString());

      // Navigate immediately - the WelcomePopup will be closed by the parent component
      navigate('/pairings');

    } catch (error) {
      console.error('Error generating wine pairings:', error);
      
      toast({
        title: "Pairing generation failed",
        description: error.message || "Failed to generate wine pairings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingPairings(false);
    }
  };

  return {
    isGeneratingPairings,
    generateWinePairings,
    usageStats,
    showUpgradePrompt,
    setShowUpgradePrompt
  };
};
