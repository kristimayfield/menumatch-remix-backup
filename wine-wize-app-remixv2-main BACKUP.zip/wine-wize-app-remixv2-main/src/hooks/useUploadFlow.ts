import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useUploadState } from '@/hooks/useUploadState';
import { useImageUpload } from '@/hooks/useImageUpload';
import { useSessionOnlyMode } from '@/hooks/useSessionOnlyMode';
import { supabase } from '@/integrations/supabase/client';

export const useUploadFlow = () => {
  const { user, loading, authReady } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isSessionOnly, getSessionRestaurant } = useSessionOnlyMode();
  
  const {
    menuImages,
    wineImages,
    showCamera,
    cameraType,
    totalImages,
    userBudget,
    canAddMenuImage,
    canAddWineImage,
    maxImagesPerType,
    setMenuImages,
    setWineImages,
    setShowCamera,
    setCameraType,
    removeMenuImage,
    removeWineImage,
  } = useUploadState();

  const { handleCameraCapture } = useImageUpload();

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [showProcessingPopup, setShowProcessingPopup] = useState(false);
  const [processingStep, setProcessingStep] = useState<string>('');
  const [processingProgress, setProcessingProgress] = useState(0);

  // Get restaurant context
  const [selectedRestaurant, setSelectedRestaurant] = useState<{id: string, name: string} | null>(null);

  useEffect(() => {
    if (loading || !authReady) return;
    if (!user) return;

    if (isSessionOnly) {
      const sessionRestaurant = getSessionRestaurant();
      setSelectedRestaurant(sessionRestaurant);
    } else {
      const currentRestaurantId = localStorage.getItem('currentRestaurantId');
      const currentRestaurantName = localStorage.getItem('currentRestaurantName');
      
      if (currentRestaurantId && currentRestaurantName) {
        setSelectedRestaurant({
          id: currentRestaurantId,
          name: currentRestaurantName
        });
      } else {
        console.log('No restaurant context found, but allowing upload page access');
      }
    }
  }, [user, loading, authReady, isSessionOnly, getSessionRestaurant]);

  const handleCameraClick = (type: 'menu' | 'wine') => {
    // Check limits before opening camera
    if (type === 'menu' && !canAddMenuImage) {
      toast({
        title: "Upload limit reached",
        description: `Maximum ${maxImagesPerType} menu images allowed`,
        variant: "destructive",
      });
      return;
    }
    
    if (type === 'wine' && !canAddWineImage) {
      toast({
        title: "Upload limit reached",
        description: `Maximum ${maxImagesPerType} wine list images allowed`,
        variant: "destructive",
      });
      return;
    }

    setCameraType(type);
    setShowCamera(true);
  };

  const handleFileUpload = (type: 'menu' | 'wine', event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check limits before uploading
    if (type === 'menu' && !canAddMenuImage) {
      toast({
        title: "Upload limit reached",
        description: `Maximum ${maxImagesPerType} menu images allowed`,
        variant: "destructive",
      });
      return;
    }
    
    if (type === 'wine' && !canAddWineImage) {
      toast({
        title: "Upload limit reached",
        description: `Maximum ${maxImagesPerType} wine list images allowed`,
        variant: "destructive",
      });
      return;
    }

    handleCameraCapture(
      file,
      type,
      menuImages,
      wineImages,
      setMenuImages,
      setWineImages,
      () => {},
      () => {},
      () => {}
    );
  };

  const handleCameraCaptureLocal = (file: File) => {
    handleCameraCapture(
      file,
      cameraType,
      menuImages,
      wineImages,
      setMenuImages,
      setWineImages,
      () => {},
      () => {},
      () => {}
    );
    setShowCamera(false);
  };

  const handleProcessClick = async () => {
    if (!selectedRestaurant) {
      toast({
        title: "Restaurant required",
        description: "Please select a restaurant first",
        variant: "destructive",
      });
      navigate('/restaurant');
      return;
    }

    if (menuImages.length === 0 && wineImages.length === 0) {
      toast({
        title: "Images required",
        description: "Please upload at least one menu or wine image",
        variant: "destructive",
      });
      return;
    }

    console.log('=== STARTING OPTIMIZED PROCESSING ===');
    console.log('Menu images:', menuImages.length);
    console.log('Wine images:', wineImages.length);
    console.log('Restaurant:', selectedRestaurant);
    console.log('Session-only mode:', isSessionOnly);

    setIsProcessing(true);
    setShowProcessingPopup(true);
    setProcessingStep('preparing');
    setProcessingProgress(10);

    try {
      setProcessingStep('converting');
      setProcessingProgress(25);
      
      const allImages = [...menuImages, ...wineImages];
      
      // Parallel conversion for speed
      const base64ConversionPromises = allImages.map(async (file) => {
        return new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => {
            const base64 = reader.result as string;
            const base64Data = base64.split(',')[1];
            resolve(base64Data);
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      });

      const base64Images = await Promise.all(base64ConversionPromises);
      console.log('All images converted to base64 in parallel');

      setProcessingStep('analyzing');
      setProcessingProgress(50);

      // Get auth session
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.access_token) {
        throw new Error('No valid session found');
      }

      // Call the optimized edge function with session-only flag
      const { data, error } = await supabase.functions.invoke('analyze-menu-fast', {
        headers: {
          Authorization: `Bearer ${session.session.access_token}`,
        },
        body: {
          images: base64Images,
          menuCount: menuImages.length,
          wineCount: wineImages.length,
          restaurantName: selectedRestaurant.name,
          fastMode: true,
          sessionOnly: isSessionOnly // Add session-only flag
        }
      });

      if (error) {
        console.error('Edge function error:', error);
        throw new Error(`Analysis failed: ${error.message}`);
      }

      if (!data || !data.success) {
        console.error('Analysis failed:', data);
        throw new Error(data?.error || 'Analysis failed - no items found in images');
      }

      console.log('Analysis completed successfully:', data);
      setProcessingProgress(90);

      // Validate we have actual data
      const menuItemsCount = data.menuItems?.length || 0;
      const winesCount = data.wines?.length || 0;
      
      if (menuItemsCount === 0 && winesCount === 0) {
        throw new Error('No menu items or wines were found in the uploaded images. Please ensure images show clear menu content.');
      }

      // Store results in sessionStorage for dishes page
      const sessionResults = {
        menuItems: data.menuItems || [],
        wines: data.wines || [],
        restaurantName: selectedRestaurant.name,
        restaurantId: selectedRestaurant.id,
        timestamp: Date.now(),
        sessionOnly: isSessionOnly // Mark as session-only data
      };
      
      sessionStorage.setItem('currentSessionResults', JSON.stringify(sessionResults));
      sessionStorage.setItem('currentSessionRestaurant', JSON.stringify({
        id: selectedRestaurant.id,
        name: selectedRestaurant.name
      }));

      console.log(`Stored ${menuItemsCount} menu items and ${winesCount} wines in sessionStorage`);

      setProcessingProgress(100);
      setProcessingStep('complete');

      // Small delay to show completion, then navigate
      setTimeout(() => {
        setShowProcessingPopup(false);
        setIsProcessing(false);
        
        // Show appropriate success message
        if (menuItemsCount > 0 && winesCount > 0) {
          toast({
            title: isSessionOnly ? "Session analysis complete!" : "Processing complete!",
            description: `Found ${menuItemsCount} dishes and ${winesCount} wines`,
          });
        } else if (menuItemsCount > 0) {
          toast({
            title: isSessionOnly ? "Session menu processed!" : "Menu processed!",
            description: `Found ${menuItemsCount} dishes. No wines found in uploaded images.`,
          });
        } else if (winesCount > 0) {
          toast({
            title: isSessionOnly ? "Session wine list processed!" : "Wine list processed!",
            description: `Found ${winesCount} wines. No menu items found in uploaded images.`,
          });
        }
        
        console.log('Navigating to dishes page');
        navigate('/dishes');
      }, 500);

    } catch (error) {
      console.error('Processing error:', error);
      setShowProcessingPopup(false);
      setIsProcessing(false);
      
      toast({
        title: "Processing failed",
        description: error.message || "Failed to analyze images. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleChangeRestaurant = () => {
    navigate('/restaurant');
  };

  return {
    // State
    selectedRestaurant,
    menuImages,
    wineImages,
    showCamera,
    cameraType,
    totalImages,
    isProcessing,
    showProcessingPopup,
    processingStep,
    processingProgress,
    canAddMenuImage,
    canAddWineImage,
    maxImagesPerType,
    
    // Handlers
    handleCameraClick,
    handleFileUpload,
    handleCameraCapture: handleCameraCaptureLocal,
    handleProcessClick,
    handleChangeRestaurant,
    setShowCamera,
    setShowProcessingPopup,
    
    // Image management
    removeMenuImage,
    removeWineImage,
  };
};
