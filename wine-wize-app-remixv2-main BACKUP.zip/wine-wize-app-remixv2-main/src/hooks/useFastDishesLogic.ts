
import { useState, useEffect } from 'react';
import { useSessionResults } from './useSessionResults';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export const useFastDishesLogic = () => {
  const { sessionResults, sessionRestaurant, isLoading, hasValidSession } = useSessionResults();
  const { toast } = useToast();
  
  const [showNoDataModal, setShowNoDataModal] = useState(false);
  const [selectedDishes, setSelectedDishes] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [databaseMenuItems, setDatabaseMenuItems] = useState<any[]>([]);
  const [databaseWines, setDatabaseWines] = useState<any[]>([]);
  const [isDatabaseLoading, setIsDatabaseLoading] = useState(false);
  const [restaurantInfo, setRestaurantInfo] = useState<{ id: string; name: string } | null>(null);

  // Get menu items and wines - prioritize session data, fallback to database
  const menuItems = sessionResults?.menuItems || databaseMenuItems;
  const availableWines = sessionResults?.wines || databaseWines;

  // Get restaurant info - prioritize session, then localStorage, then database
  const currentRestaurant = sessionRestaurant || restaurantInfo;

  // Filter items based on search term
  const filteredItems = menuItems.filter(item =>
    item.dish_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.description && item.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Load restaurant info from localStorage if session data is missing
  useEffect(() => {
    if (!sessionRestaurant) {
      const storedId = localStorage.getItem('currentRestaurantId');
      const storedName = localStorage.getItem('currentRestaurantName');
      
      if (storedId && storedName) {
        console.log('Loading restaurant info from localStorage:', { id: storedId, name: storedName });
        setRestaurantInfo({ id: storedId, name: storedName });
      }
    }
  }, [sessionRestaurant]);

  // Load database data if no session data and restaurant is selected
  useEffect(() => {
    const loadDatabaseData = async () => {
      if (hasValidSession || isDatabaseLoading) return;
      
      const restaurantId = sessionRestaurant?.id || restaurantInfo?.id || localStorage.getItem('currentRestaurantId');
      
      if (!restaurantId) return;

      console.log('Loading database data for restaurant:', restaurantId);
      setIsDatabaseLoading(true);

      try {
        // Load menu items from database
        const { data: menuData, error: menuError } = await supabase
          .from('restaurant_menus')
          .select('*')
          .eq('restaurant_id', restaurantId)
          .eq('is_active', true);

        if (menuError) {
          console.error('Error loading menu data:', menuError);
        } else if (menuData) {
          console.log(`Loaded ${menuData.length} menu items from database`);
          setDatabaseMenuItems(menuData.map(item => ({
            ...item,
            id: item.id
          })));
        }

        // Load wines from database
        const { data: wineData, error: wineError } = await supabase
          .from('restaurant_wines')
          .select('*')
          .eq('restaurant_id', restaurantId)
          .eq('is_active', true);

        if (wineError) {
          console.error('Error loading wine data:', wineError);
        } else if (wineData) {
          console.log(`Loaded ${wineData.length} wines from database`);
          setDatabaseWines(wineData);
        }

      } catch (error) {
        console.error('Error loading database data:', error);
      } finally {
        setIsDatabaseLoading(false);
      }
    };

    loadDatabaseData();
  }, [hasValidSession, isDatabaseLoading, sessionRestaurant, restaurantInfo]);

  // Check for valid data (session or database) on component mount
  useEffect(() => {
    if (!isLoading && !isDatabaseLoading && !hasValidSession) {
      // Only show modal if we have no data at all (neither session nor database)
      if (menuItems.length === 0 && availableWines.length === 0) {
        console.warn('No menu or wine data found');
        setShowNoDataModal(true);
      }
    }
  }, [isLoading, isDatabaseLoading, hasValidSession, menuItems.length, availableWines.length]);

  // Data integrity validation
  useEffect(() => {
    if (sessionResults || databaseMenuItems.length > 0 || databaseWines.length > 0) {
      console.log('=== DISHES PAGE DATA INTEGRITY CHECK ===');
      console.log(`Menu items: ${menuItems.length} (session: ${sessionResults?.menuItems?.length || 0}, database: ${databaseMenuItems.length})`);
      console.log(`Wines: ${availableWines.length} (session: ${sessionResults?.wines?.length || 0}, database: ${databaseWines.length})`);
      console.log('Restaurant:', currentRestaurant?.name);
      
      if (menuItems.length === 0 && availableWines.length === 0) {
        console.warn('Data exists but no menu items or wines found');
        toast({
          title: "No menu data found",
          description: "Please go back and upload your menu images again.",
          variant: "destructive",
        });
      }

      // Validate wine data structure
      if (availableWines.length > 0) {
        const winesWithoutNames = availableWines.filter(wine => !wine.name && !wine.wine_name);
        if (winesWithoutNames.length > 0) {
          console.warn(`Found ${winesWithoutNames.length} wines without proper names`);
        }
        
        console.log('Sample wine data:', availableWines[0]);
      }
    }
  }, [sessionResults, menuItems.length, availableWines.length, currentRestaurant, toast, databaseMenuItems.length, databaseWines.length]);

  const handleDishSelect = (dishId: string) => {
    setSelectedDishes(prev => {
      if (prev.includes(dishId)) {
        return prev.filter(id => id !== dishId);
      } else {
        return [...prev, dishId];
      }
    });
  };

  const clearAllSelections = () => {
    setSelectedDishes([]);
  };

  return {
    sessionResults,
    sessionRestaurant: currentRestaurant, // Return the resolved restaurant info
    isLoading: isLoading || isDatabaseLoading,
    hasValidSession: hasValidSession || menuItems.length > 0 || availableWines.length > 0,
    showNoDataModal,
    menuItems,
    availableWines,
    filteredItems,
    selectedDishes,
    searchTerm,
    setSearchTerm,
    handleDishSelect,
    clearAllSelections,
    setShowNoDataModal,
  };
};
