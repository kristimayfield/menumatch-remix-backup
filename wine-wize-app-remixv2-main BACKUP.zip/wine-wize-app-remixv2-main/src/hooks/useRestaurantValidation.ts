
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface RestaurantValidationResult {
  isValid: boolean;
  isDuplicate: boolean;
  existingRestaurant?: {
    id: string;
    name: string;
    location: string;
    cuisine_type: string;
  };
  error?: string;
}

export const useRestaurantValidation = () => {
  const [isValidating, setIsValidating] = useState(false);

  const validateRestaurant = async (
    name: string,
    location: string
  ): Promise<RestaurantValidationResult> => {
    if (!name.trim() || !location.trim()) {
      return {
        isValid: false,
        isDuplicate: false,
        error: 'Both restaurant name and location are required'
      };
    }

    setIsValidating(true);
    try {
      // Check for duplicates using our database function
      const { data: isDuplicate, error: duplicateError } = await supabase
        .rpc('check_restaurant_duplicate', {
          check_name: name,
          check_location: location
        });

      if (duplicateError) {
        throw duplicateError;
      }

      if (isDuplicate) {
        // Get the existing restaurant details
        const { data: existing, error: searchError } = await supabase
          .rpc('search_restaurants_case_insensitive', {
            search_name: name,
            search_location: location
          });

        if (searchError) {
          throw searchError;
        }

        return {
          isValid: false,
          isDuplicate: true,
          existingRestaurant: existing?.[0]
        };
      }

      return {
        isValid: true,
        isDuplicate: false
      };
    } catch (error) {
      console.error('Restaurant validation error:', error);
      return {
        isValid: false,
        isDuplicate: false,
        error: 'Failed to validate restaurant. Please try again.'
      };
    } finally {
      setIsValidating(false);
    }
  };

  return {
    validateRestaurant,
    isValidating
  };
};
