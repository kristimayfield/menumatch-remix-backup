
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useSessionValidation } from './useSessionValidation';
import { useImageConverter } from './useImageConverter';
import { useRestaurantContext } from './useRestaurantContext';
import { useAnalysisRequest } from './useAnalysisRequest';
import { useProcessingResults } from './useProcessingResults';

export const useImageProcessing = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { validateSession } = useSessionValidation();
  const { convertImagesToBase64 } = useImageConverter();
  const { getRestaurantContext } = useRestaurantContext();
  const { sendAnalysisRequest } = useAnalysisRequest();
  const { handleProcessingSuccess, handleProcessingError } = useProcessingResults();

  const processImages = async (
    menuImages: File[],
    wineImages: File[],
    userBudget: number,
    selectedWineTypes: string[] = [],
    setProcessingStep: (step: string) => void,
    setProcessingProgress: (progress: number) => void,
    setIsProcessing: (processing: boolean) => void,
    setShowProcessingPopup: (show: boolean) => void
  ) => {
    if (menuImages.length === 0 && wineImages.length === 0) {
      console.error('No images provided for processing');
      toast({
        title: "No images to process",
        description: "Please capture some images first",
        variant: "destructive",
      });
      return;
    }

    console.log('=== STARTING IMAGE PROCESSING ===');
    console.log(`Processing ${menuImages.length} menu images and ${wineImages.length} wine images`);
    console.log(`User budget: ${userBudget}, Selected wine types:`, selectedWineTypes);

    setIsProcessing(true);
    setShowProcessingPopup(true);
    setProcessingStep('optimize');
    setProcessingProgress(10);

    try {
      // Enhanced session validation
      await validateSession();

      // Enhanced image processing with detailed logging
      setProcessingStep('optimize');
      setProcessingProgress(20);

      // Convert images to base64
      const base64Images = await convertImagesToBase64(menuImages, wineImages, setProcessingProgress);

      // Get restaurant context
      const restaurantName = getRestaurantContext();
      if (!restaurantName) {
        setShowProcessingPopup(false);
        setIsProcessing(false);
        return;
      }

      // Send analysis request with enhanced error handling
      console.log('Sending analysis request to edge function...');
      const data = await sendAnalysisRequest(
        base64Images,
        menuImages,
        wineImages,
        selectedWineTypes,
        userBudget,
        restaurantName,
        setProcessingProgress,
        setProcessingStep
      );

      console.log('Edge function response received:', data);

      // Strict success validation - no fallbacks or verification checks
      if (!data.success) {
        throw new Error(data.error || 'Analysis failed - edge function returned success: false');
      }

      if (!data.restaurantId) {
        throw new Error('Analysis failed - no restaurant ID returned');
      }

      if ((!data.menuItems || data.menuItems.length === 0) && 
          (!data.wines || data.wines.length === 0)) {
        throw new Error('Analysis failed - no menu items or wines were extracted from the images');
      }

      console.log('Processing succeeded with valid data');
      handleProcessingSuccess(data, setProcessingProgress, setProcessingStep, setShowProcessingPopup);

    } catch (error) {
      console.error('=== PROCESSING ERROR ===');
      console.error('Error details:', error);
      console.error('Stack trace:', error.stack);
      
      // Clear any stored restaurant data to prevent inconsistent state
      localStorage.removeItem('currentRestaurantId');
      localStorage.removeItem('currentRestaurantName');
      
      // Show clear error message for all failures
      handleProcessingError(error, false, setShowProcessingPopup);
      setIsProcessing(false);
    }

    console.log('=== PROCESSING COMPLETE ===');
  };

  return {
    processImages,
  };
};
