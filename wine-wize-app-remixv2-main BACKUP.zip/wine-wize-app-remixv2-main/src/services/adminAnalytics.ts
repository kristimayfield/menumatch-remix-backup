
import { supabase } from '@/integrations/supabase/client';

export interface SubscriptionUsageData {
  tier: string;
  totalUsers: number;
  averagePairingsPerMonth: number;
  totalPairingsThisMonth: number;
  usersNearLimit: number;
}

export interface UsageTrendData {
  month: string;
  glassTier: number;
  bottleTier: number;
  trialTier: number;
}

export const getSubscriptionUsageAnalytics = async (): Promise<SubscriptionUsageData[]> => {
  try {
    // Get current month start
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Get all subscribers with their usage this month
    const { data: subscribers, error: subscribersError } = await supabase
      .from('subscribers')
      .select('user_id, subscription_tier, email');

    if (subscribersError) throw subscribersError;

    // Get pairing usage for this month
    const { data: usageData, error: usageError } = await supabase
      .from('wine_interactions')
      .select('user_id')
      .eq('interaction_type', 'pairing_generated')
      .gte('created_at', monthStart.toISOString());

    if (usageError) throw usageError;

    // Group usage by user
    const userUsageCounts = usageData.reduce((acc, interaction) => {
      acc[interaction.user_id] = (acc[interaction.user_id] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Group subscribers by tier and calculate analytics
    const tierAnalytics = subscribers.reduce((acc, subscriber) => {
      const tier = subscriber.subscription_tier || 'trial';
      const userUsage = userUsageCounts[subscriber.user_id] || 0;
      const tierLimit = tier.includes('Glass') ? 20 : tier.includes('Bottle') ? -1 : 5;
      
      if (!acc[tier]) {
        acc[tier] = {
          tier,
          totalUsers: 0,
          totalPairings: 0,
          usersNearLimit: 0
        };
      }
      
      acc[tier].totalUsers += 1;
      acc[tier].totalPairings += userUsage;
      
      // Count users near limit (80% or more)
      if (tierLimit > 0 && userUsage >= tierLimit * 0.8) {
        acc[tier].usersNearLimit += 1;
      }
      
      return acc;
    }, {} as Record<string, any>);

    // Convert to array format with calculated averages
    return Object.values(tierAnalytics).map((analytics: any) => ({
      tier: analytics.tier,
      totalUsers: analytics.totalUsers,
      averagePairingsPerMonth: analytics.totalUsers > 0 ? 
        Math.round((analytics.totalPairings / analytics.totalUsers) * 100) / 100 : 0,
      totalPairingsThisMonth: analytics.totalPairings,
      usersNearLimit: analytics.usersNearLimit
    }));
  } catch (error) {
    console.error('Error fetching subscription analytics:', error);
    return [];
  }
};

export const getUsageTrends = async (): Promise<UsageTrendData[]> => {
  try {
    // Get usage data for the last 6 months
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const { data: interactions, error } = await supabase
      .from('wine_interactions')
      .select('user_id, created_at')
      .eq('interaction_type', 'pairing_generated')
      .gte('created_at', sixMonthsAgo.toISOString());

    if (error) throw error;

    // Get subscriber data to map users to tiers
    const { data: subscribers, error: subscribersError } = await supabase
      .from('subscribers')
      .select('user_id, subscription_tier');

    if (subscribersError) throw subscribersError;

    // Create user to tier mapping
    const userTierMap = subscribers.reduce((acc, sub) => {
      acc[sub.user_id] = sub.subscription_tier || 'trial';
      return acc;
    }, {} as Record<string, string>);

    // Group interactions by month and tier
    const monthlyData = interactions.reduce((acc, interaction) => {
      const month = new Date(interaction.created_at).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short' 
      });
      const tier = userTierMap[interaction.user_id] || 'trial';
      
      if (!acc[month]) {
        acc[month] = { glassTier: 0, bottleTier: 0, trialTier: 0 };
      }
      
      if (tier.includes('Glass')) {
        acc[month].glassTier += 1;
      } else if (tier.includes('Bottle')) {
        acc[month].bottleTier += 1;
      } else {
        acc[month].trialTier += 1;
      }
      
      return acc;
    }, {} as Record<string, any>);

    // Convert to array format
    return Object.entries(monthlyData).map(([month, data]) => ({
      month,
      ...data
    })).sort((a, b) => new Date(a.month).getTime() - new Date(b.month).getTime());
  } catch (error) {
    console.error('Error fetching usage trends:', error);
    return [];
  }
};
