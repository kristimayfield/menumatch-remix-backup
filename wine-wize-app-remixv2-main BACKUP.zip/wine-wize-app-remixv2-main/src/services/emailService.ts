
import { supabase } from '@/integrations/supabase/client';

export interface EmailRequest {
  to: string;
  subject: string;
  body: string;
  isHtml?: boolean;
}

export interface EmailResponse {
  success: boolean;
  message: string;
  timestamp?: string;
  details?: any;
}

export const sendNotificationEmail = async (emailData: EmailRequest): Promise<EmailResponse> => {
  try {
    console.log('🚀 SENDING EMAIL via Supabase Edge Function...', { 
      to: emailData.to, 
      subject: emailData.subject,
      bodyLength: emailData.body?.length || 0,
      isHtml: emailData.isHtml
    });

    // Call the Supabase edge function with proper error handling
    const { data, error } = await supabase.functions.invoke('send-ms365-email', {
      body: {
        to: emailData.to,
        subject: emailData.subject,
        body: emailData.body,
        isHtml: emailData.isHtml || false
      }
    });

    console.log('📨 Supabase function response:', { data, error });

    if (error) {
      console.error('❌ Supabase function error:', error);
      throw new Error(error.message || 'Failed to invoke email function');
    }

    if (!data) {
      console.error('❌ No data returned from email function');
      throw new Error('No response data from email function');
    }

    // Check if the response indicates an error
    if (data.error) {
      console.error('❌ Email function returned error:', data);
      throw new Error(data.details || data.error || 'Email function failed');
    }

    console.log('✅ Email sent successfully:', data);
    return {
      success: true,
      message: 'Email sent successfully via MS 365',
      timestamp: data.timestamp || new Date().toISOString(),
      details: data.details
    };
  } catch (error) {
    console.error('💥 Email service error:', error);
    return {
      success: false,
      message: 'Failed to send email via MS 365',
      details: error.message || 'Unknown error occurred'
    };
  }
};

// Enhanced email templates for common notifications
export const emailTemplates = {
  welcome: (firstName: string) => ({
    subject: 'Welcome to Wine Wize!',
    body: `
      <h2>Welcome to Wine Wize, ${firstName}!</h2>
      <p>Thank you for joining our wine pairing community. We're excited to help you discover perfect wine pairings for your favorite dishes.</p>
      <p>Get started by uploading your first menu or exploring our wine recommendations.</p>
      <p>Cheers!<br>The Wine Wize Team</p>
    `,
    isHtml: true
  }),

  passwordReset: (resetLink: string) => ({
    subject: 'Reset Your Wine Wize Password',
    body: `
      <h2>Password Reset Request</h2>
      <p>You requested to reset your password for your Wine Wize account.</p>
      <p><a href="${resetLink}" style="background: #7C3AED; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Reset Password</a></p>
      <p>If you didn't request this, please ignore this email.</p>
      <p>Best regards,<br>The Wine Wize Team</p>
    `,
    isHtml: true
  }),

  pairingReady: (restaurantName: string, dishCount: number) => ({
    subject: 'Your Wine Pairings Are Ready!',
    body: `
      <h2>Your Wine Pairings Are Ready!</h2>
      <p>We've analyzed the menu from ${restaurantName} and found perfect wine pairings for ${dishCount} dishes.</p>
      <p>Log in to Wine Wize to explore your personalized recommendations.</p>
      <p>Enjoy your dining experience!<br>The Wine Wize Team</p>
    `,
    isHtml: true
  }),

  adminNotification: (subject: string, message: string) => ({
    subject: `Wine Wize Admin: ${subject}`,
    body: `
      <h2>Admin Notification</h2>
      <p>${message}</p>
      <p>This is an automated notification from the Wine Wize system.</p>
      <p>Best regards,<br>Wine Wize System</p>
    `,
    isHtml: true
  })
};
