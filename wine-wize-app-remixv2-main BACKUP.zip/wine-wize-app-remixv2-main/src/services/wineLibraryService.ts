
import { supabase } from '@/integrations/supabase/client';
import { detectWineTypeFromName, validateWineStyle } from '@/utils/wineTypeDetection';

interface WineData {
  wineName: string;
  description: string;
  wineType: string;
  wineStyle: string;
  confidenceLevel: string;
  price: string;
}

export const addWineToLibrary = async (
  userId: string,
  wine: WineData,
  dishName: string
) => {
  // Detect wine type and validate wine style before saving
  const detectedWineType = detectWineTypeFromName(wine.wineName);
  const finalWineType = detectedWineType || wine.wineType;
  const validatedWineStyle = validateWineStyle(wine.wineStyle, finalWineType, wine.wineName);
  
  console.log(`Saving wine: ${wine.wineName} -> Type: ${finalWineType}, Style: ${validatedWineStyle}`);
  
  // Add to user's wine library
  const { data: libraryEntry, error: libraryError } = await supabase
    .from('user_wine_library')
    .insert({
      user_id: userId,
      wine_name: wine.wineName,
      wine_description: wine.description,
      wine_style: validatedWineStyle,
      confidence_level: wine.confidenceLevel,
      price: wine.price,
      dish_paired_with: dishName
    })
    .select()
    .single();

  if (libraryError) throw libraryError;

  // Add to master wine library (with conflict handling)
  await supabase
    .from('master_wine_library')
    .upsert({
      wine_name: wine.wineName,
      wine_description: wine.description,
      wine_style: validatedWineStyle,
      confidence_level: wine.confidenceLevel,
      price: wine.price
    }, {
      onConflict: 'wine_name,wine_style'
    });

  // Schedule rating reminder (12 hours from now)
  const reminderTime = new Date();
  reminderTime.setHours(reminderTime.getHours() + 12);
  
  await supabase
    .from('wine_rating_reminders')
    .insert({
      user_id: userId,
      wine_library_id: libraryEntry.id,
      scheduled_for: reminderTime.toISOString()
    });

  // Track interaction
  await supabase
    .from('wine_interactions')
    .insert({
      user_id: userId,
      interaction_type: 'add_to_library',
      wine_name: wine.wineName,
      wine_style: validatedWineStyle,
      dish_name: dishName
    });

  return libraryEntry;
};

export const trackWineInteraction = async (
  userId: string,
  interactionType: string,
  wineName: string,
  wineStyle: string,
  dishName: string
) => {
  await supabase
    .from('wine_interactions')
    .insert({
      user_id: userId,
      interaction_type: interactionType,
      wine_name: wineName,
      wine_style: wineStyle,
      dish_name: dishName
    });
};
