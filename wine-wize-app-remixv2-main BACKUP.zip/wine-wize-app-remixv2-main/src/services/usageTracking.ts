
import { supabase } from '@/integrations/supabase/client';

export interface UsageStats {
  pairingsUsed: number;
  pairingsLimit: number;
  isLimitReached: boolean;
  subscriptionTier: string;
}

export const TIER_LIMITS = {
  trial: 5,
  'Glass Monthly': 20,
  'Glass Annual': 20,
  'Bottle Monthly': -1, // Unlimited
  'Bottle Annual': -1, // Unlimited
  free: 5
};

export const trackPairingUsage = async (userId: string): Promise<void> => {
  try {
    // Get current month start
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Track this pairing generation
    const { error: insertError } = await supabase
      .from('wine_interactions')
      .insert({
        user_id: userId,
        interaction_type: 'pairing_generated',
        wine_name: 'Pairing Session',
        wine_style: 'N/A',
        dish_name: 'Multiple Dishes'
      });

    if (insertError) throw insertError;
  } catch (error) {
    console.error('Error tracking pairing usage:', error);
  }
};

export const getUserUsageStats = async (userId: string, subscriptionTier?: string): Promise<UsageStats> => {
  try {
    // Get current month start
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Count pairings generated this month
    const { data: usageData, error } = await supabase
      .from('wine_interactions')
      .select('id')
      .eq('user_id', userId)
      .eq('interaction_type', 'pairing_generated')
      .gte('created_at', monthStart.toISOString());

    if (error) throw error;

    const pairingsUsed = usageData?.length || 0;
    const tier = subscriptionTier || 'trial';
    const pairingsLimit = TIER_LIMITS[tier as keyof typeof TIER_LIMITS] || TIER_LIMITS.trial;
    const isLimitReached = pairingsLimit > 0 && pairingsUsed >= pairingsLimit;

    return {
      pairingsUsed,
      pairingsLimit,
      isLimitReached,
      subscriptionTier: tier
    };
  } catch (error) {
    console.error('Error fetching usage stats:', error);
    return {
      pairingsUsed: 0,
      pairingsLimit: TIER_LIMITS.trial,
      isLimitReached: false,
      subscriptionTier: 'trial'
    };
  }
};
