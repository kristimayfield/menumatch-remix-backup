
export interface OptimizedImage {
  file: File;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
}

export const optimizeImage = async (file: File, maxWidth = 1920, maxHeight = 1080, quality = 0.8): Promise<OptimizedImage> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const img = new Image();

    img.onload = () => {
      // Calculate new dimensions while maintaining aspect ratio
      let { width, height } = img;
      
      // More aggressive sizing for large images
      if (file.size > 10 * 1024 * 1024) { // 10MB+ files
        const ratio = Math.min(1280 / width, 720 / height);
        width *= ratio;
        height *= ratio;
      } else if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width *= ratio;
        height *= ratio;
      }

      canvas.width = width;
      canvas.height = height;

      // Draw and compress
      ctx.drawImage(img, 0, 0, width, height);
      
      // Use lower quality for very large files
      const finalQuality = file.size > 5 * 1024 * 1024 ? Math.min(quality, 0.6) : quality;
      
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const optimizedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now(),
            });

            console.log(`Image optimized: ${file.size} -> ${blob.size} bytes (${Math.round((1 - blob.size / file.size) * 100)}% reduction)`);

            resolve({
              file: optimizedFile,
              originalSize: file.size,
              compressedSize: blob.size,
              compressionRatio: Math.round((1 - blob.size / file.size) * 100)
            });
          }
        },
        'image/jpeg',
        finalQuality
      );
    };

    img.src = URL.createObjectURL(file);
  });
};

export const validateImageQuality = async (file: File): Promise<{ isValid: boolean; feedback?: string }> => {
  // Enhanced validation with size limits
  if (file.size > 50 * 1024 * 1024) { // 50MB absolute limit
    return { isValid: false, feedback: "Image file is too large (max 50MB). Please use a smaller image." };
  }

  if (!file.type.startsWith('image/')) {
    return { isValid: false, feedback: "Please select a valid image file" };
  }

  // Auto-approve most images to eliminate quality check popup delays
  return { isValid: true };
};
