
export const convertFileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    console.log(`Converting file to base64: ${file.name} (${file.size} bytes)`);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64 = reader.result as string;
      const base64Data = base64.split(',')[1];
      console.log(`Base64 conversion complete. Length: ${base64Data.length} characters`);
      resolve(base64Data);
    };
    reader.onerror = error => {
      console.error('Base64 conversion failed:', error);
      reject(error);
    };
  });
};
