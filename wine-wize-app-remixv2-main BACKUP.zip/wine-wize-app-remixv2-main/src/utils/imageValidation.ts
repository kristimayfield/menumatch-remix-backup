
export const validateImagePayload = (allImages: File[]) => {
  const totalSize = allImages.reduce((sum, file) => sum + file.size, 0);
  console.log(`Total image payload size: ${(totalSize / 1024 / 1024).toFixed(2)}MB`);
  
  if (totalSize > 25 * 1024 * 1024) {
    console.error('Total payload too large:', totalSize);
    throw new Error('Total image size too large. Please use fewer or smaller images.');
  }

  return totalSize;
};

export const validateRequestPayload = (requestPayload: any) => {
  if (!requestPayload.images || !Array.isArray(requestPayload.images) || requestPayload.images.length === 0) {
    throw new Error('Invalid request payload: images array is empty or malformed');
  }

  const payloadSizeCheck = JSON.stringify(requestPayload);
  const payloadSize = payloadSizeCheck.length;
  console.log(`Request payload prepared and validated. Size: ${(payloadSize / 1024).toFixed(0)}KB`);
  
  if (payloadSize > 25 * 1024 * 1024) {
    console.error('Request payload too large:', payloadSize);
    throw new Error('Request too large. Please use fewer or smaller images.');
  }

  return payloadSize;
};
