
import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthContextType, SubscriptionInfo } from './auth/types';
import { useAuthInit } from './auth/useAuthInit';
import { useSessionManager } from '@/hooks/useSessionManager';
import * as authServices from './auth/services';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const {
    user,
    session,
    loading,
    authReady,
    setUser,
    setSession,
    setLoading
  } = useAuthInit();

  const { clearUserSpecificData } = useSessionManager();

  const [subscriptionInfo, setSubscriptionInfo] = useState<SubscriptionInfo>({
    subscribed: false,
    subscription_tier: null,
    subscription_end: null
  });

  const handleSignOut = async () => {
    setLoading(true);
    await authServices.signOut();
    setSession(null);
    setUser(null);
    setSubscriptionInfo({ subscribed: false, subscription_tier: null, subscription_end: null });
    
    // Clear all session data on sign out
    clearUserSpecificData();
    
    setLoading(false);
  };

  const handleRefreshSession = async () => {
    const data = await authServices.refreshSession();
    
    if (data.session) {
      setSession(data.session);
      setUser(data.session.user);
    } else {
      setSession(null);
      setUser(null);
      // Clear session data if refresh fails
      clearUserSpecificData();
    }
  };

  const handleCheckSubscription = async () => {
    if (!user) return;
    
    try {
      const data = await authServices.checkSubscription();
      setSubscriptionInfo({
        subscribed: data.subscribed,
        subscription_tier: data.subscription_tier,
        subscription_end: data.subscription_end
      });
    } catch (error) {
      console.error('Failed to check subscription:', error);
    }
  };

  const handleCreateCheckout = async (priceId: string, planType: string) => {
    try {
      const data = await authServices.createCheckout(priceId, planType);
      return data;
    } catch (error) {
      return { error: error instanceof Error ? error.message : 'Unknown error' };
    }
  };

  const handleOpenCustomerPortal = async () => {
    try {
      const data = await authServices.openCustomerPortal();
      return data;
    } catch (error) {
      return { error: error instanceof Error ? error.message : 'Unknown error' };
    }
  };

  const enhancedSignUp = async (
    email: string, 
    password: string, 
    firstName: string, 
    lastName: string, 
    location: string
  ) => {
    // Clear any existing session data before sign up
    clearUserSpecificData();
    
    const result = await authServices.signUp(email, password, firstName, lastName, location);
    
    return result;
  };

  const enhancedSignIn = async (email: string, password: string) => {
    // Clear any existing session data before sign in
    clearUserSpecificData();
    
    const result = await authServices.signIn(email, password);
    
    return result;
  };

  // Check subscription when user changes
  useEffect(() => {
    if (user && authReady) {
      handleCheckSubscription();
    }
  }, [user, authReady]);

  const value = {
    user,
    session,
    loading,
    authReady,
    subscriptionInfo,
    signUp: enhancedSignUp,
    signIn: enhancedSignIn,
    signOut: handleSignOut,
    resetPassword: authServices.resetPassword,
    saveWinePreferences: authServices.saveWinePreferences,
    refreshSession: handleRefreshSession,
    checkSubscription: handleCheckSubscription,
    createCheckout: handleCreateCheckout,
    openCustomerPortal: handleOpenCustomerPortal,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
