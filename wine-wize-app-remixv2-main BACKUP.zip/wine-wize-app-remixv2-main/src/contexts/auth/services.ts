
import { supabase } from '@/integrations/supabase/client';
import { ensureUserProfile, syncToCRM } from './utils';

export const signUp = async (
  email: string, 
  password: string, 
  firstName: string, 
  lastName: string, 
  location: string
) => {
  // Remove email redirect since we're not using email confirmation
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        first_name: firstName,
        last_name: lastName,
        location: location
      }
    }
  });

  // If signup successful and user created, sync to CRM and ensure profile
  if (!error && data.user) {
    console.log('User created successfully, syncing data...');
    
    // Ensure the user profile is created/updated (fallback if trigger fails)
    await ensureUserProfile(data.user.id, email, firstName, lastName, location);
    
    // Sync to CRM
    await syncToCRM(data.user.id, email, firstName, lastName, location);
  }

  return { error };
};

export const signIn = async (email: string, password: string) => {
  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { error };
};

export const signOut = async () => {
  await supabase.auth.signOut();
};

export const resetPassword = async (email: string) => {
  const redirectUrl = `${window.location.origin}/`;
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: redirectUrl
  });
  return { error };
};

export const saveWinePreferences = async (userId: string, preferences: any) => {
  const { error } = await supabase
    .from('wine_preferences')
    .insert({
      user_id: userId,
      ...preferences
    });
  return { error };
};

export const refreshSession = async () => {
  try {
    console.log('Manually refreshing session...');
    const { data, error } = await supabase.auth.refreshSession();
    if (error) {
      console.error('Manual session refresh failed:', error);
      throw error;
    }
    
    console.log('Manual session refresh successful');
    return data;
  } catch (error) {
    console.error('Error refreshing session:', error);
    throw error;
  }
};

export const validateTokenExpiry = async () => {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    
    if (error || !session) {
      console.warn('No valid session found during token validation');
      return { isValid: false, session: null };
    }
    
    const now = Math.floor(Date.now() / 1000);
    const tokenExp = session.expires_at || 0;
    const timeUntilExpiry = tokenExp - now;
    
    // Consider token invalid if it expires within 1 minute
    const isValid = timeUntilExpiry > 60;
    
    console.log(`Token validation: ${isValid ? 'valid' : 'invalid'}, expires in ${timeUntilExpiry}s`);
    
    return { isValid, session, timeUntilExpiry };
  } catch (error) {
    console.error('Token validation error:', error);
    return { isValid: false, session: null };
  }
};

export const checkSubscription = async () => {
  try {
    const { data, error } = await supabase.functions.invoke('check-subscription');
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error checking subscription:', error);
    throw error;
  }
};

export const createCheckout = async (priceId: string, planType: string) => {
  try {
    const { data, error } = await supabase.functions.invoke('create-checkout', {
      body: { priceId, planType }
    });
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error creating checkout:', error);
    throw error;
  }
};

export const openCustomerPortal = async () => {
  try {
    const { data, error } = await supabase.functions.invoke('customer-portal');
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error opening customer portal:', error);
    throw error;
  }
};
