export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      favorite_wines: {
        Row: {
          created_at: string
          description: string
          id: string
          name: string
          pairing_note: string
          price: string
          user_id: string
          varietal: string
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          name: string
          pairing_note: string
          price: string
          user_id: string
          varietal: string
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          name?: string
          pairing_note?: string
          price?: string
          user_id?: string
          varietal?: string
        }
        Relationships: []
      }
      master_wine_library: {
        Row: {
          confidence_level: string
          created_at: string
          id: string
          price: string
          times_selected: number | null
          updated_at: string
          wine_description: string
          wine_name: string
          wine_style: string
        }
        Insert: {
          confidence_level: string
          created_at?: string
          id?: string
          price: string
          times_selected?: number | null
          updated_at?: string
          wine_description: string
          wine_name: string
          wine_style: string
        }
        Update: {
          confidence_level?: string
          created_at?: string
          id?: string
          price?: string
          times_selected?: number | null
          updated_at?: string
          wine_description?: string
          wine_name?: string
          wine_style?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          first_name: string
          id: string
          last_name: string
          location: string
          monthly_searches_used: number | null
          role: string | null
          stripe_customer_id: string | null
          subscription_level: string
          subscription_status: string | null
          subscription_type: string
          trial_end_date: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          first_name: string
          id: string
          last_name: string
          location: string
          monthly_searches_used?: number | null
          role?: string | null
          stripe_customer_id?: string | null
          subscription_level?: string
          subscription_status?: string | null
          subscription_type?: string
          trial_end_date?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          first_name?: string
          id?: string
          last_name?: string
          location?: string
          monthly_searches_used?: number | null
          role?: string | null
          stripe_customer_id?: string | null
          subscription_level?: string
          subscription_status?: string | null
          subscription_type?: string
          trial_end_date?: string
          updated_at?: string
        }
        Relationships: []
      }
      quick_vino_tips: {
        Row: {
          category: string | null
          created_at: string
          display_order: number | null
          id: string
          is_active: boolean
          tip_text: string
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          display_order?: number | null
          id?: string
          is_active?: boolean
          tip_text: string
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          display_order?: number | null
          id?: string
          is_active?: boolean
          tip_text?: string
          updated_at?: string
        }
        Relationships: []
      }
      restaurant_menus: {
        Row: {
          created_at: string
          description: string | null
          dish_name: string
          dish_type: string | null
          id: string
          ingredients: string[] | null
          is_active: boolean | null
          price: string | null
          restaurant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          dish_name: string
          dish_type?: string | null
          id?: string
          ingredients?: string[] | null
          is_active?: boolean | null
          price?: string | null
          restaurant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          dish_name?: string
          dish_type?: string | null
          id?: string
          ingredients?: string[] | null
          is_active?: boolean | null
          price?: string | null
          restaurant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "restaurant_menus_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["id"]
          },
        ]
      }
      restaurant_wines: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          name: string
          price_bottle: string | null
          price_glass: string | null
          region: string | null
          restaurant_id: string
          updated_at: string
          varietal: string | null
          vintage: string | null
          wine_type: string | null
          ww_style: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          price_bottle?: string | null
          price_glass?: string | null
          region?: string | null
          restaurant_id: string
          updated_at?: string
          varietal?: string | null
          vintage?: string | null
          wine_type?: string | null
          ww_style?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          price_bottle?: string | null
          price_glass?: string | null
          region?: string | null
          restaurant_id?: string
          updated_at?: string
          varietal?: string | null
          vintage?: string | null
          wine_type?: string | null
          ww_style?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "restaurant_wines_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["id"]
          },
        ]
      }
      restaurants: {
        Row: {
          created_at: string
          created_by: string | null
          cuisine_type: string | null
          id: string
          last_menu_update: string | null
          location: string | null
          manual_entry: boolean | null
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          cuisine_type?: string | null
          id?: string
          last_menu_update?: string | null
          location?: string | null
          manual_entry?: boolean | null
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          cuisine_type?: string | null
          id?: string
          last_menu_update?: string | null
          location?: string | null
          manual_entry?: boolean | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          stripe_customer_id: string | null
          subscribed: boolean
          subscription_end: string | null
          subscription_tier: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_wine_library: {
        Row: {
          confidence_level: string
          created_at: string
          dish_paired_with: string
          id: string
          price: string
          rating: number | null
          updated_at: string
          user_id: string
          wine_description: string
          wine_name: string
          wine_style: string
        }
        Insert: {
          confidence_level: string
          created_at?: string
          dish_paired_with: string
          id?: string
          price: string
          rating?: number | null
          updated_at?: string
          user_id: string
          wine_description: string
          wine_name: string
          wine_style: string
        }
        Update: {
          confidence_level?: string
          created_at?: string
          dish_paired_with?: string
          id?: string
          price?: string
          rating?: number | null
          updated_at?: string
          user_id?: string
          wine_description?: string
          wine_name?: string
          wine_style?: string
        }
        Relationships: []
      }
      wine_interactions: {
        Row: {
          created_at: string
          dish_name: string | null
          id: string
          interaction_type: string
          rating: number | null
          user_id: string
          wine_name: string
          wine_style: string | null
        }
        Insert: {
          created_at?: string
          dish_name?: string | null
          id?: string
          interaction_type: string
          rating?: number | null
          user_id: string
          wine_name: string
          wine_style?: string | null
        }
        Update: {
          created_at?: string
          dish_name?: string | null
          id?: string
          interaction_type?: string
          rating?: number | null
          user_id?: string
          wine_name?: string
          wine_style?: string | null
        }
        Relationships: []
      }
      wine_preferences: {
        Row: {
          acidity: string | null
          alcohol: string | null
          budget: number
          created_at: string
          id: string
          preferred_style: string | null
          red_wine_rank: number | null
          rose_wine_rank: number | null
          sparkling_wine_rank: number | null
          sweetness: string | null
          tannin: string | null
          updated_at: string
          user_id: string
          white_wine_rank: number | null
          ww_red_style: string | null
          ww_white_style: string | null
        }
        Insert: {
          acidity?: string | null
          alcohol?: string | null
          budget?: number
          created_at?: string
          id?: string
          preferred_style?: string | null
          red_wine_rank?: number | null
          rose_wine_rank?: number | null
          sparkling_wine_rank?: number | null
          sweetness?: string | null
          tannin?: string | null
          updated_at?: string
          user_id: string
          white_wine_rank?: number | null
          ww_red_style?: string | null
          ww_white_style?: string | null
        }
        Update: {
          acidity?: string | null
          alcohol?: string | null
          budget?: number
          created_at?: string
          id?: string
          preferred_style?: string | null
          red_wine_rank?: number | null
          rose_wine_rank?: number | null
          sparkling_wine_rank?: number | null
          sweetness?: string | null
          tannin?: string | null
          updated_at?: string
          user_id?: string
          white_wine_rank?: number | null
          ww_red_style?: string | null
          ww_white_style?: string | null
        }
        Relationships: []
      }
      wine_rating_reminders: {
        Row: {
          created_at: string
          id: string
          scheduled_for: string
          sent: boolean | null
          user_id: string
          wine_library_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          scheduled_for: string
          sent?: boolean | null
          user_id: string
          wine_library_id: string
        }
        Update: {
          created_at?: string
          id?: string
          scheduled_for?: string
          sent?: boolean | null
          user_id?: string
          wine_library_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wine_rating_reminders_wine_library_id_fkey"
            columns: ["wine_library_id"]
            isOneToOne: false
            referencedRelation: "user_wine_library"
            referencedColumns: ["id"]
          },
        ]
      }
      wine_varietal_definitions: {
        Row: {
          common_names: string[]
          created_at: string
          id: string
          varietal_name: string
          wine_color: string
        }
        Insert: {
          common_names?: string[]
          created_at?: string
          id?: string
          varietal_name: string
          wine_color: string
        }
        Update: {
          common_names?: string[]
          created_at?: string
          id?: string
          varietal_name?: string
          wine_color?: string
        }
        Relationships: []
      }
      wines: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          name: string
          price_bottle: string | null
          price_glass: string | null
          region: string | null
          restaurant_id: string | null
          updated_at: string
          varietal: string | null
          vintage: string | null
          wine_style: string | null
          wine_type: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          name: string
          price_bottle?: string | null
          price_glass?: string | null
          region?: string | null
          restaurant_id?: string | null
          updated_at?: string
          varietal?: string | null
          vintage?: string | null
          wine_style?: string | null
          wine_type?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          name?: string
          price_bottle?: string | null
          price_glass?: string | null
          region?: string | null
          restaurant_id?: string | null
          updated_at?: string
          varietal?: string | null
          vintage?: string | null
          wine_style?: string | null
          wine_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wines_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["id"]
          },
        ]
      }
      ww_wine_style_definitions: {
        Row: {
          created_at: string
          description: string
          id: string
          keywords: string[]
          style_name: string
          updated_at: string
          wine_color: string
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          keywords?: string[]
          style_name: string
          updated_at?: string
          wine_color: string
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          keywords?: string[]
          style_name?: string
          updated_at?: string
          wine_color?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_restaurant_duplicate: {
        Args: { check_name: string; check_location: string }
        Returns: boolean
      }
      create_or_find_restaurant_by_user: {
        Args: {
          restaurant_name: string
          restaurant_location?: string
          restaurant_cuisine?: string
          user_id_param?: string
        }
        Returns: string
      }
      increment_wine_selection: {
        Args: { wine_name_param: string; wine_style_param: string }
        Returns: undefined
      }
      is_admin: {
        Args: { user_id: string }
        Returns: boolean
      }
      search_restaurants_case_insensitive: {
        Args: { search_name: string; search_location?: string }
        Returns: {
          id: string
          name: string
          location: string
          cuisine_type: string
          last_menu_update: string
          created_at: string
          updated_at: string
        }[]
      }
      update_restaurant_menu_timestamp: {
        Args: { restaurant_uuid: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
