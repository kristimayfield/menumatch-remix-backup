
import React from 'react';
import { Link } from 'react-router-dom';
import { Loader2, Wine, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import BackButton from '@/components/navigation/BackButton';

interface UploadActionsProps {
  totalImages: number;
  isProcessing: boolean;
  onProcessClick: () => void;
  disabled?: boolean;
}

const UploadActions = ({ totalImages, isProcessing, onProcessClick, disabled = false }: UploadActionsProps) => {
  const hasMinimumImages = totalImages >= 2;

  return (
    <>
      {/* Process Button */}
      {totalImages > 0 && (
        <div className="text-center mb-8">
          <Button
            onClick={onProcessClick}
            disabled={isProcessing || disabled || !hasMinimumImages}
            className={`px-8 py-4 text-lg transition-all duration-200 ${
              isProcessing 
                ? 'bg-gray-400 opacity-50 cursor-not-allowed text-gray-600' 
                : hasMinimumImages 
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Wine className="w-5 h-5 mr-2" />
                Process Images ({totalImages})
              </>
            )}
          </Button>
          {!hasMinimumImages && totalImages > 0 && (
            <p className="text-sm text-gray-500 mt-2">
              Please upload at least one menu and one wine image to process
            </p>
          )}
        </div>
      )}

      {/* Navigation */}
      <div className="flex gap-4 mb-20">
        <BackButton 
          fallbackPath="/restaurant"
          className="flex-1 justify-center border border-slate-300 bg-white hover:bg-slate-50"
          label="Back"
        />
        <Link to="/dishes" className="flex-1">
          <Button 
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            disabled={totalImages === 0 || disabled || isProcessing}
          >
            Continue to Dish Selection
          </Button>
        </Link>
      </div>
    </>
  );
};

export default UploadActions;
