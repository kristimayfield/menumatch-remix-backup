
import React, { useState, useEffect } from 'react';
import { ArrowRight, Upload, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Restaurant } from '@/types/restaurant';

interface RestaurantSearchWithImportProps {
  selectedRestaurant: Restaurant;
  onImportMenu: () => void;
  onUploadImages: () => void;
}

const RestaurantSearchWithImport: React.FC<RestaurantSearchWithImportProps> = ({
  selectedRestaurant,
  onImportMenu,
  onUploadImages
}) => {
  const [hasMenuData, setHasMenuData] = useState(false);
  const [isCheckingMenuData, setIsCheckingMenuData] = useState(true);

  useEffect(() => {
    const checkForExistingMenuData = async () => {
      if (!selectedRestaurant?.id) {
        setHasMenuData(false);
        setIsCheckingMenuData(false);
        return;
      }

      try {
        // Check if restaurant has any menu items
        const { data: menuItems, error } = await supabase
          .from('restaurant_menus')
          .select('id')
          .eq('restaurant_id', selectedRestaurant.id)
          .eq('is_active', true)
          .limit(1);

        if (error) {
          console.error('Error checking menu data:', error);
          setHasMenuData(false);
        } else {
          setHasMenuData(menuItems && menuItems.length > 0);
        }
      } catch (error) {
        console.error('Error checking menu data:', error);
        setHasMenuData(false);
      } finally {
        setIsCheckingMenuData(false);
      }
    };

    checkForExistingMenuData();
  }, [selectedRestaurant?.id]);

  return (
    <Card className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
      <div className="text-center mb-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-2">
          What would you like to do?
        </h3>
        <p className="text-slate-600 text-sm">
          Choose how you'd like to proceed with <strong>{selectedRestaurant.name}</strong>
        </p>
      </div>
      
      <div className="space-y-3">
        <Button
          onClick={onImportMenu}
          disabled={isCheckingMenuData || !hasMenuData}
          className={`w-full py-4 h-auto flex-col gap-2 transition-all duration-200 ${
            hasMenuData && !isCheckingMenuData
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white'
              : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white opacity-40 cursor-not-allowed hover:from-purple-600 hover:to-pink-600'
          }`}
        >
          <div className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            <span className="font-medium">Import {selectedRestaurant.name} Menu and Wine List</span>
          </div>
          <span className="text-sm opacity-90">
            {isCheckingMenuData 
              ? 'Checking for existing menu data...'
              : hasMenuData 
                ? 'Use existing menu data to select dishes'
                : 'No existing menu data available'
            }
          </span>
        </Button>
        
        <Button
          onClick={onUploadImages}
          variant="outline"
          className="w-full py-4 h-auto flex-col gap-2 border-slate-300"
        >
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            <span className="font-medium">Upload my own images</span>
          </div>
          <span className="text-sm text-slate-600">Take new photos of menu and wine list</span>
        </Button>
      </div>
      
      <div className="flex items-center justify-center gap-4 mt-6 text-xs text-slate-500">
        <span className="flex items-center gap-1">
          <div className="w-2 h-2 bg-purple-400 rounded-full" />
          Menu Analysis
        </span>
        <span className="flex items-center gap-1">
          <div className="w-2 h-2 bg-pink-400 rounded-full" />
          Wine Pairing
        </span>
        <span className="flex items-center gap-1">
          <div className="w-2 h-2 bg-amber-400 rounded-full" />
          AI Recommendations
        </span>
      </div>
    </Card>
  );
};

export default RestaurantSearchWithImport;
