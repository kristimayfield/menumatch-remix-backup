
import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Restaurant } from '@/types/restaurant';

interface RestaurantSearchActionsProps {
  selectedRestaurant: Restaurant | null;
  showNotFound: boolean;
  onContinueToMenu: () => void;
}

const RestaurantSearchActions = ({
  selectedRestaurant,
  showNotFound,
  onContinueToMenu
}: RestaurantSearchActionsProps) => {
  // Don't show anything if no restaurant is selected and no "not found" state
  if (!selectedRestaurant && !showNotFound) {
    return null;
  }

  // Selected restaurant state
  if (selectedRestaurant) {
    return (
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6">
        <div className="text-center mb-4">
          <h4 className="text-lg font-semibold text-slate-800 mb-2">Ready for the Next Step?</h4>
          <p className="text-slate-600 text-sm">
            Upload menu and wine list photos to get AI-powered pairing recommendations
          </p>
        </div>
        
        <Button 
          onClick={onContinueToMenu}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-4 text-lg font-medium rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
        >
          <span>Continue to Upload Images</span>
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
        
        <div className="flex items-center justify-center gap-4 mt-4 text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <div className="w-2 h-2 bg-purple-400 rounded-full" />
            Menu Photos
          </span>
          <span className="flex items-center gap-1">
            <div className="w-2 h-2 bg-pink-400 rounded-full" />
            Wine List Photos
          </span>
          <span className="flex items-center gap-1">
            <div className="w-2 h-2 bg-amber-400 rounded-full" />
            AI Analysis
          </span>
        </div>
      </div>
    );
  }

  // Not found state
  if (showNotFound) {
    return (
      <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
        <h3 className="text-lg font-semibold text-slate-800 mb-3">
          Restaurant not found, but no worries!
        </h3>
        <p className="text-slate-600 mb-4">
          You can add it manually above, or continue without selecting a specific restaurant to get personalized wine recommendations.
        </p>
        
        <Button 
          onClick={onContinueToMenu}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 rounded-xl"
        >
          Continue Without Restaurant Selection
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    );
  }

  return null;
};

export default RestaurantSearchActions;
