
import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useRestaurantValidation } from '@/hooks/useRestaurantValidation';
import DuplicateWarningModal from './DuplicateWarningModal';
import RestaurantFormFields from './RestaurantFormFields';
import FormActions from './FormActions';

interface AddRestaurantFormProps {
  onRestaurantAdded: (restaurant: any) => void;
  onCancel: () => void;
}

const AddRestaurantForm: React.FC<AddRestaurantFormProps> = ({
  onRestaurantAdded,
  onCancel
}) => {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [cuisineType, setCuisineType] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{
    show: boolean;
    existingRestaurant?: any;
  }>({ show: false });

  const { user } = useAuth();
  const { toast } = useToast();
  const { validateRestaurant, isValidating } = useRestaurantValidation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !location.trim()) {
      toast({
        title: "Missing required fields",
        description: "Both restaurant name and location are required.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    setDuplicateWarning({ show: false });

    try {
      // Validate restaurant for duplicates
      const validation = await validateRestaurant(name, location);
      
      if (!validation.isValid) {
        if (validation.isDuplicate && validation.existingRestaurant) {
          setDuplicateWarning({
            show: true,
            existingRestaurant: validation.existingRestaurant
          });
          setIsSubmitting(false);
          return;
        }
        
        toast({
          title: "Validation error",
          description: validation.error || "Please check your input and try again.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      }

      // Create new restaurant using the database function
      const { data: restaurantId, error } = await supabase
        .rpc('create_or_find_restaurant_by_user', {
          restaurant_name: name.trim(),
          restaurant_location: location.trim(),
          restaurant_cuisine: cuisineType.trim() || null,
          user_id_param: user?.id
        });

      if (error) {
        throw error;
      }

      // Fetch the created restaurant details
      const { data: newRestaurant, error: fetchError } = await supabase
        .from('restaurants')
        .select('*')
        .eq('id', restaurantId)
        .single();

      if (fetchError) {
        throw fetchError;
      }

      console.log('Successfully created restaurant:', newRestaurant);
      
      toast({
        title: "Restaurant added",
        description: `${name} has been added successfully.`,
      });

      onRestaurantAdded(newRestaurant);
      
      // Reset form
      setName('');
      setLocation('');
      setCuisineType('');
      
    } catch (error) {
      console.error('Error creating restaurant:', error);
      toast({
        title: "Error adding restaurant",
        description: "Failed to add the restaurant. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUseDuplicate = () => {
    if (duplicateWarning.existingRestaurant) {
      onRestaurantAdded(duplicateWarning.existingRestaurant);
      setDuplicateWarning({ show: false });
      setName('');
      setLocation('');
      setCuisineType('');
    }
  };

  const handleFormSubmit = () => {
    // Create a synthetic form event for handleSubmit
    const syntheticEvent = {
      preventDefault: () => {}
    } as React.FormEvent;
    handleSubmit(syntheticEvent);
  };

  const isFormValid = Boolean(name.trim() && location.trim());

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6">
      <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
        <Plus className="w-5 h-5" />
        Add New Restaurant
      </h3>

      <DuplicateWarningModal
        isVisible={duplicateWarning.show}
        existingRestaurant={duplicateWarning.existingRestaurant}
        onUseDuplicate={handleUseDuplicate}
        onEditDetails={() => setDuplicateWarning({ show: false })}
      />

      <form onSubmit={handleSubmit}>
        <RestaurantFormFields
          name={name}
          location={location}
          cuisineType={cuisineType}
          onNameChange={setName}
          onLocationChange={setLocation}
          onCuisineTypeChange={setCuisineType}
          isDisabled={isSubmitting || isValidating}
        />

        <FormActions
          onSubmit={handleFormSubmit}
          onCancel={onCancel}
          isSubmitting={isSubmitting}
          isValidating={isValidating}
          isFormValid={isFormValid}
        />
      </form>
    </div>
  );
};

export default AddRestaurantForm;
