
import React from 'react';
import WineConfidenceBadge from './WineConfidenceBadge';

interface WineCardHeaderProps {
  wineName: string;
  wineType: string;
  wineStyle: string;
  confidenceLevel: string;
}

const WineCardHeader = ({ wineName, wineType, confidenceLevel }: WineCardHeaderProps) => {
  return (
    <div className="mb-3">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h4 className="font-bold text-slate-800 text-base leading-tight flex-1">
          {wineName}
        </h4>
        <WineConfidenceBadge confidenceLevel={confidenceLevel} />
      </div>
      
      <div className="flex items-center gap-2 mb-2">
        <span className="text-sm text-purple-600 font-medium bg-purple-50 px-2 py-1 rounded-full">
          {wineType}
        </span>
      </div>
    </div>
  );
};

export default WineCardHeader;
