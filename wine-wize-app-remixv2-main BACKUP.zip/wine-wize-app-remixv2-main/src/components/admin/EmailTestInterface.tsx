
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { EmailTestForm } from './email/EmailTestForm';
import { EmailTestResultDisplay } from './email/EmailTestResult';
import { EmailRequirements } from './email/EmailRequirements';
import { EmailFormData, EmailTestResult } from './email/types';
import { sendNotificationEmail } from '@/services/emailService';

export const EmailTestInterface = () => {
  const [formData, setFormData] = useState<EmailFormData>({
    to: '',
    subject: 'Test Email from Wine Wize',
    body: 'This is a test email sent from the Wine Wize application using MS 365 integration.',
    isHtml: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<EmailTestResult | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const sendTestEmail = async () => {
    if (!formData.to || !formData.subject || !formData.body) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    setTestResult(null);

    try {
      console.log('🧪 Starting email test...', { 
        to: formData.to, 
        subject: formData.subject,
        bodyLength: formData.body.length,
        isHtml: formData.isHtml
      });

      // Use the email service instead of calling Supabase directly
      const result = await sendNotificationEmail({
        to: formData.to,
        subject: formData.subject,
        body: formData.body,
        isHtml: formData.isHtml
      });

      console.log('📧 Email test result:', result);

      if (result.success) {
        setTestResult({
          success: true,
          message: result.message,
          timestamp: result.timestamp || new Date().toISOString(),
          details: result.details
        });
        toast({
          title: "Email Sent Successfully! ✅",
          description: "Test email was sent via MS 365 integration",
        });
      } else {
        setTestResult({
          success: false,
          message: result.message,
          details: result.details,
          timestamp: new Date().toISOString()
        });
        toast({
          title: "Email Failed ❌",
          description: `Failed to send email: ${result.details}`,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('💥 Unexpected error during email test:', error);
      setTestResult({
        success: false,
        message: 'Unexpected error occurred',
        details: error.message || 'Unknown error',
        timestamp: new Date().toISOString()
      });
      toast({
        title: "Error ⚠️",
        description: "An unexpected error occurred while sending the email",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
      // Ensure we stay on the admin page - no navigation away
      // The component should remain mounted and visible
    }
  };

  const handleBackToAdmin = () => {
    // Clear any test results and stay on admin page
    setTestResult(null);
    setFormData({
      to: '',
      subject: 'Test Email from Wine Wize',
      body: 'This is a test email sent from the Wine Wize application using MS 365 integration.',
      isHtml: false
    });
    // Force navigate to admin to ensure we're on the right page
    navigate('/admin', { replace: true });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5" />
          MS 365 Email Test Interface
        </CardTitle>
        <CardDescription>
          Test your MS 365 email integration by sending a test email through Microsoft Graph API
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <EmailTestForm
          formData={formData}
          isLoading={isLoading}
          onInputChange={handleInputChange}
          onSendEmail={sendTestEmail}
        />

        {testResult && (
          <div className="space-y-4">
            <EmailTestResultDisplay result={testResult} />
            <div className="flex justify-center">
              <button
                onClick={handleBackToAdmin}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Continue with Admin Dashboard
              </button>
            </div>
          </div>
        )}

        <EmailRequirements />
      </CardContent>
    </Card>
  );
};
