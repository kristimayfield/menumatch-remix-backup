import React from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertCircle } from 'lucide-react';
import { EmailTestResult } from './types';

interface EmailTestResultProps {
  result: EmailTestResult;
}

export const EmailTestResultDisplay: React.FC<EmailTestResultProps> = ({ result }) => {
  // Handle details that might be an object or string
  const formatDetails = (details: any): string => {
    if (!details) return '';
    if (typeof details === 'string') return details;
    if (typeof details === 'object') {
      // If it's an object with email details, format it nicely
      if (details.to && details.subject) {
        return `Sent to: ${details.to}, Subject: ${details.subject}${details.fromEmail ? `, From: ${details.fromEmail}` : ''}`;
      }
      // Otherwise, stringify the object
      return JSON.stringify(details);
    }
    return String(details);
  };

  return (
    <Alert className={result.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
      <div className="flex items-center gap-2">
        {result.success ? (
          <CheckCircle className="h-4 w-4 text-green-600" />
        ) : (
          <AlertCircle className="h-4 w-4 text-red-600" />
        )}
        <AlertDescription className="flex-1">
          <div className="font-medium mb-1">{result.message}</div>
          <div className="text-sm text-gray-600">
            Timestamp: {new Date(result.timestamp).toLocaleString()}
          </div>
          {result.details && (
            <div className="text-sm text-gray-600 mt-1">
              Details: {formatDetails(result.details)}
            </div>
          )}
        </AlertDescription>
      </div>
    </Alert>
  );
};
