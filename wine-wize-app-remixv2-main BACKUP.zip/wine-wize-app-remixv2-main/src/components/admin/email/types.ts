
export interface EmailTestResult {
  success: boolean;
  message: string;
  timestamp: string;
  details?: string;
}

export interface EmailFormData {
  to: string;
  subject: string;
  body: string;
  isHtml: boolean;
}
