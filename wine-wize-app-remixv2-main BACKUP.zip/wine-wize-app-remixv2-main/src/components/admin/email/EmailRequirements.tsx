
import React from 'react';

export const EmailRequirements: React.FC = () => {
  return (
    <div className="text-sm text-gray-600 space-y-2">
      <div className="font-medium">Required Environment Variables:</div>
      <ul className="list-disc list-inside space-y-1 text-xs">
        <li>MS365_TENANT_ID - Your Azure AD tenant ID</li>
        <li>MS365_CLIENT_ID - Your Azure app registration client ID</li>
        <li>MS365_CLIENT_SECRET - Your Azure app registration client secret</li>
        <li>MS365_FROM_EMAIL - The email address to send from</li>
      </ul>
    </div>
  );
};
