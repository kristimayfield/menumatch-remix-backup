
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Loader2, Mail } from 'lucide-react';
import { EmailFormData } from './types';

interface EmailTestFormProps {
  formData: EmailFormData;
  isLoading: boolean;
  onInputChange: (field: string, value: string | boolean) => void;
  onSendEmail: () => void;
}

export const EmailTestForm: React.FC<EmailTestFormProps> = ({
  formData,
  isLoading,
  onInputChange,
  onSendEmail
}) => {
  const isFormValid = formData.to && formData.subject && formData.body;

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="to">To Email Address *</Label>
        <Input
          id="to"
          type="email"
          placeholder="recipient@example.com"
          value={formData.to}
          onChange={(e) => onInputChange('to', e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject">Subject *</Label>
        <Input
          id="subject"
          placeholder="Email subject"
          value={formData.subject}
          onChange={(e) => onInputChange('subject', e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="body">Email Body *</Label>
        <Textarea
          id="body"
          placeholder="Email content"
          value={formData.body}
          onChange={(e) => onInputChange('body', e.target.value)}
          rows={4}
          required
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="isHtml"
          checked={formData.isHtml}
          onCheckedChange={(checked) => onInputChange('isHtml', checked)}
        />
        <Label htmlFor="isHtml">Send as HTML</Label>
      </div>

      <Button 
        onClick={onSendEmail} 
        disabled={isLoading || !isFormValid}
        className="w-full"
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Sending Email...
          </>
        ) : (
          <>
            <Mail className="mr-2 h-4 w-4" />
            Send Test Email
          </>
        )}
      </Button>
    </div>
  );
};
