
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RefreshCw, Users, TrendingUp, AlertTriangle, Mail, BarChart3, Settings, Shield } from 'lucide-react';
import { useAdminAnalytics } from '@/hooks/useAdminAnalytics';
import SubscriptionUsageChart from './SubscriptionUsageChart';
import TierComparisonChart from './TierComparisonChart';
import { EmailTestInterface } from './EmailTestInterface';
import RLSTestInterface from './RLSTestInterface';

const AdminDashboard: React.FC = () => {
  const { usageData, trendData, isLoading, error, refetch } = useAdminAnalytics();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-600">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600 mb-4">{error}</p>
        <Button onClick={refetch} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  const totalUsers = usageData.reduce((sum, tier) => sum + tier.totalUsers, 0);
  const totalPairings = usageData.reduce((sum, tier) => sum + tier.totalPairingsThisMonth, 0);
  const usersNearLimit = usageData.reduce((sum, tier) => sum + tier.usersNearLimit, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Super Admin Dashboard</h1>
          <p className="text-slate-600">Subscription usage analytics and system management</p>
        </div>
        <Button onClick={refetch} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh Data
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              Across all subscription tiers
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Pairings</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPairings}</div>
            <p className="text-xs text-muted-foreground">
              Total pairings this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg per User</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalUsers > 0 ? Math.round((totalPairings / totalUsers) * 100) / 100 : 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Pairings per user this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Near Limit</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{usersNearLimit}</div>
            <p className="text-xs text-muted-foreground">
              Users near their monthly limit
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Admin Tools Tabs */}
      <Tabs defaultValue="analytics" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="rls-testing" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            RLS Testing
          </TabsTrigger>
          <TabsTrigger value="email-testing" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email Testing
          </TabsTrigger>
          <TabsTrigger value="system-tools" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            System Tools
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="space-y-6">
          {/* Subscription Tier Details */}
          <Card>
            <CardHeader>
              <CardTitle>Subscription Tier Breakdown</CardTitle>
              <CardDescription>
                Detailed usage statistics by subscription tier
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {usageData.map((tier) => (
                  <div key={tier.tier} className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-semibold text-lg">{tier.tier}</h3>
                      <span className="text-sm text-slate-500">{tier.totalUsers} users</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-slate-600">Avg Pairings/Month</p>
                        <p className="font-medium">{tier.averagePairingsPerMonth}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Total This Month</p>
                        <p className="font-medium">{tier.totalPairingsThisMonth}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Near Limit</p>
                        <p className="font-medium">{tier.usersNearLimit} users</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TierComparisonChart data={usageData} />
            <SubscriptionUsageChart data={trendData} />
          </div>
        </TabsContent>

        <TabsContent value="rls-testing" className="space-y-6">
          <RLSTestInterface />
        </TabsContent>

        <TabsContent value="email-testing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Email System Testing
              </CardTitle>
              <CardDescription>
                Test your MS 365 email integration and verify kristimayfield@wine-wize.com can send emails
              </CardDescription>
            </CardHeader>
            <CardContent>
              <EmailTestInterface />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system-tools" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Database Management</CardTitle>
                <CardDescription>Monitor and manage database operations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Database Status</span>
                    <span className="text-green-600 font-medium">Online</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Active Connections</span>
                    <span className="font-medium">12/100</span>
                  </div>
                  <Button variant="outline" size="sm" className="w-full">
                    View Database Logs
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Health</CardTitle>
                <CardDescription>Monitor application performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">API Response Time</span>
                    <span className="text-green-600 font-medium">~250ms</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Edge Functions</span>
                    <span className="text-green-600 font-medium">All Online</span>
                  </div>
                  <Button variant="outline" size="sm" className="w-full">
                    View System Metrics
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
