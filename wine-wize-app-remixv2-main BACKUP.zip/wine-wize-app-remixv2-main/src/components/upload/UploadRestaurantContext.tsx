
import React from 'react';
import { MapPin, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSessionOnlyMode } from '@/hooks/useSessionOnlyMode';

interface UploadRestaurantContextProps {
  restaurant: { id: string; name: string } | null;
  onChangeRestaurant: () => void;
}

const UploadRestaurantContext = ({ restaurant, onChangeRestaurant }: UploadRestaurantContextProps) => {
  const { isSessionOnly } = useSessionOnlyMode();
  
  if (!restaurant) return null;

  return (
    <div className="mb-8 p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {isSessionOnly ? (
            <Clock className="w-5 h-5 text-amber-600" />
          ) : (
            <MapPin className="w-5 h-5 text-purple-600" />
          )}
          <div>
            <h3 className="font-semibold text-slate-800 flex items-center gap-2">
              {isSessionOnly ? 'Session Mode' : 'Selected Restaurant'}
              {isSessionOnly && (
                <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full">
                  Temporary
                </span>
              )}
            </h3>
            <p className="text-slate-600">
              {isSessionOnly ? 'Menu analysis for current session only' : restaurant.name}
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          onClick={onChangeRestaurant}
          className="text-purple-600 border-purple-200 hover:bg-purple-50"
        >
          {isSessionOnly ? 'Select Restaurant' : 'Change Restaurant'}
        </Button>
      </div>
    </div>
  );
};

export default UploadRestaurantContext;
