
import React from 'react';
import CameraCapture from '@/components/CameraCapture';

interface UploadCameraModalProps {
  isOpen: boolean;
  cameraType: 'menu' | 'wine';
  onCapture: (file: File) => void;
  onClose: () => void;
}

const UploadCameraModal = ({ isOpen, cameraType, onCapture, onClose }: UploadCameraModalProps) => {
  if (!isOpen) return null;

  return (
    <CameraCapture
      onCapture={onCapture}
      onClose={onClose}
      type={cameraType}
    />
  );
};

export default UploadCameraModal;
