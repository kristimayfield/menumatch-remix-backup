
import React from 'react';
import { Wine, Search, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import DishesTable from './DishesTable';

interface DishesContentProps {
  restaurantName: string;
  menuItems: any[];
  filteredItems: any[];
  selectedDishes: string[];
  searchTerm: string;
  isGeneratingPairings: boolean;
  onSearchChange: (term: string) => void;
  onDishSelect: (dishId: string) => void;
  onClearAllSelections: () => void;
  onGeneratePairings: () => void;
}

const DishesContent = ({
  restaurantName,
  menuItems,
  filteredItems,
  selectedDishes,
  searchTerm,
  isGeneratingPairings,
  onSearchChange,
  onDishSelect,
  onClearAllSelections,
  onGeneratePairings
}: DishesContentProps) => {
  return (
    <div className="container mx-auto px-4 py-8 pt-28">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-purple-600 mb-2">
          🍽️ Select Your Dishes
        </h1>
        <p className="text-slate-600">
          Choose the dishes you'd like wine pairings for from {restaurantName}
        </p>
      </div>

      {/* Data integrity info for testing */}
      <div className="bg-slate-50 rounded-lg p-4 mb-6 text-sm text-slate-600">
        <strong>Menu Analysis:</strong> Found {menuItems.length} dishes from your uploaded menu images
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          type="text"
          placeholder="Search dishes..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10 w-full"
        />
      </div>

      {/* Selection Summary */}
      {selectedDishes.length > 0 && (
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between">
            <span className="text-purple-800 font-medium">
              {selectedDishes.length} dish{selectedDishes.length !== 1 ? 'es' : ''} selected
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={onClearAllSelections}
              className="text-purple-600 border-purple-300 hover:bg-purple-100"
            >
              <Trash2 className="w-4 h-4 mr-1" />
              Clear All
            </Button>
          </div>
        </div>
      )}

      {/* Dishes Table - Restored Original Design */}
      <DishesTable
        filteredItems={filteredItems}
        selectedDishes={selectedDishes}
        onDishSelect={onDishSelect}
        menuItemsLength={menuItems.length}
      />

      {/* Generate Pairings Button */}
      {selectedDishes.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-4 md:relative md:bg-transparent md:border-0 md:p-0">
          <Button
            onClick={onGeneratePairings}
            disabled={isGeneratingPairings}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-4 text-lg font-semibold"
          >
            {isGeneratingPairings ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                Generating Perfect Pairings...
              </>
            ) : (
              <>
                <Wine className="w-5 h-5 mr-2" />
                Get Wine Pairings for {selectedDishes.length} Dish{selectedDishes.length !== 1 ? 'es' : ''}
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
};

export default DishesContent;
