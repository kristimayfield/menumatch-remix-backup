
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Loader2, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import BackButton from '@/components/navigation/BackButton';

interface DishesActionBarProps {
  selectedDishes: string[];
  isGeneratingPairings: boolean;
  onClearAllSelections: () => void;
  onGeneratePairings: () => void;
}

const DishesActionBar = ({ 
  selectedDishes, 
  isGeneratingPairings, 
  onClearAllSelections, 
  onGeneratePairings 
}: DishesActionBarProps) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-4 shadow-lg z-50">
      <div className="container mx-auto max-w-4xl">
        {/* Selection Count and Clear Button */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <div className="inline-flex items-center bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
              {selectedDishes.length}/4 dishes selected
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onClearAllSelections}
              disabled={selectedDishes.length === 0}
              className="text-xs"
            >
              Clear All
            </Button>
          </div>
        </div>

        {/* Main Action Button */}
        <div className="space-y-3">
          <Button 
            onClick={onGeneratePairings}
            disabled={selectedDishes.length === 0 || isGeneratingPairings}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 h-12"
          >
            {isGeneratingPairings ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Pairings...
              </>
            ) : (
              <>
                Find Perfect Wine Pairings
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>

          {/* Navigation Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <BackButton 
              fallbackPath="/upload"
              label="Go Back"
              className="w-full justify-center border border-slate-300 bg-white hover:bg-slate-50"
            />
            <Link to="/welcome" className="w-full">
              <Button variant="outline" className="w-full flex items-center gap-2">
                <RotateCcw className="w-4 h-4" />
                Start Over
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DishesActionBar;
