import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, PieChart, Building2, Bell } from 'lucide-react';
import ActivityChart from '@/components/analytics/ActivityChart';
import WineStyleChart from '@/components/analytics/WineStyleChart';
import ChartErrorBoundary from '@/components/analytics/ChartErrorBoundary';
import TopRestaurants from '@/components/analytics/TopRestaurants';
import PriceAnalyticsChart from '@/components/dashboard/PriceAnalyticsChart';
import RatingRemindersAudit from '@/components/notifications/RatingRemindersAudit';

interface DashboardTabsProps {
  analytics: {
    monthlyActivity: Array<{ month: string; count: number }>;
    wineStyleBreakdown: Array<{ style: string; count: number; percentage: number }>;
    topRestaurants: Array<{ name: string; count: number }>;
    ratingDistribution: Array<{ rating: number; count: number }>;
  };
  avgPriceData: Array<{ month: string; avgPrice: number }>;
  annualAverage: number;
}

const DashboardTabs: React.FC<DashboardTabsProps> = ({
  analytics,
  avgPriceData,
  annualAverage
}) => {
  return (
    <Tabs defaultValue="activity" className="space-y-6">
      <TabsList className="grid w-full grid-cols-5 bg-white border border-slate-200">
        <TabsTrigger value="activity" className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4" />
          Activity
        </TabsTrigger>
        <TabsTrigger value="styles" className="flex items-center gap-2">
          <PieChart className="w-4 h-4" />
          Wine Styles
        </TabsTrigger>
        <TabsTrigger value="restaurants" className="flex items-center gap-2">
          <Building2 className="w-4 h-4" />
          Restaurants
        </TabsTrigger>
        <TabsTrigger value="pricing" className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4" />
          Pricing
        </TabsTrigger>
        <TabsTrigger value="reminders" className="flex items-center gap-2">
          <Bell className="w-4 h-4" />
          Reminders
        </TabsTrigger>
      </TabsList>

      <TabsContent value="activity" className="space-y-4">
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Monthly Pairing Activity
          </h3>
          <ActivityChart data={analytics.monthlyActivity} />
        </div>
      </TabsContent>

      <TabsContent value="styles" className="space-y-4">
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <PieChart className="w-5 h-5" />
            Wine Style Preferences
          </h3>
          <ChartErrorBoundary>
            <WineStyleChart data={analytics.wineStyleBreakdown} />
          </ChartErrorBoundary>
        </div>
      </TabsContent>

      <TabsContent value="restaurants" className="space-y-4">
        <TopRestaurants data={analytics.topRestaurants} />
      </TabsContent>

      <TabsContent value="pricing" className="space-y-4">
        <PriceAnalyticsChart
          data={avgPriceData}
          annualAverage={annualAverage}
        />
      </TabsContent>

      <TabsContent value="reminders" className="space-y-4">
        <RatingRemindersAudit />
      </TabsContent>
    </Tabs>
  );
};

export default DashboardTabs;
