import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useSessionOnlyMode } from '@/hooks/useSessionOnlyMode';
import RestaurantSearchInput from '@/components/restaurant/RestaurantSearchInput';
import AddRestaurantForm from '@/components/restaurant/AddRestaurantForm';
import SelectedRestaurantDisplay from '@/components/restaurant/SelectedRestaurantDisplay';
import RestaurantSearchActions from '@/components/restaurant/RestaurantSearchActions';
import { Button } from '@/components/ui/button';
import { Plus, ArrowRight } from 'lucide-react';
import { Restaurant } from '@/types/restaurant';

interface RestaurantSearchProps {
  restaurants: Restaurant[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  filteredRestaurants: Restaurant[];
  onRestaurantSelect: (restaurant: Restaurant) => void;
  onContinueToMenu: () => void;
}

const RestaurantSearch: React.FC<RestaurantSearchProps> = ({ 
  restaurants,
  searchTerm,
  setSearchTerm,
  filteredRestaurants,
  onRestaurantSelect, 
  onContinueToMenu 
}) => {
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { enableSessionOnlyMode } = useSessionOnlyMode();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setSelectedRestaurant(null);
    setShowDropdown(e.target.value.trim().length > 0);
  };

  const handleRestaurantSelect = (restaurant: Restaurant) => {
    setSelectedRestaurant(restaurant);
    setSearchTerm(restaurant.name);
    setShowDropdown(false);
    setShowAddForm(false);
    onRestaurantSelect(restaurant);
    
    toast({
      title: "Restaurant selected!",
      description: `You've selected ${restaurant.name}`,
    });
  };

  const handleRestaurantAdded = (restaurant: Restaurant) => {
    handleRestaurantSelect(restaurant);
  };

  const handleFocus = () => {
    if (searchTerm && filteredRestaurants.length > 0) {
      setShowDropdown(true);
    }
  };

  const handleCancelAddForm = () => {
    setShowAddForm(false);
  };

  const handleContinueWithoutRestaurant = () => {
    enableSessionOnlyMode();
    toast({
      title: "Session-only mode enabled",
      description: "Your menu analysis will be temporary for this session only",
    });
    navigate('/upload');
  };

  // Determine current state for UI
  const hasSearched = searchTerm.trim().length > 0;
  const hasResults = filteredRestaurants.length > 0;
  const showNotFound = hasSearched && !hasResults && !selectedRestaurant;

  return (
    <div className="bg-gradient-to-r from-purple-600 to-pink-600 bg-opacity-10 rounded-2xl p-6 shadow-lg border border-slate-100 mb-6" style={{background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.1) 0%, rgba(219, 39, 119, 0.1) 100%)'}}>
      <div className="bg-white rounded-xl p-6">
        <h2 className="text-xl font-semibold text-slate-800 mb-4">Where are you dining tonight?</h2>
        
        <RestaurantSearchInput
          searchTerm={searchTerm}
          filteredRestaurants={filteredRestaurants}
          showDropdown={showDropdown}
          onSearchChange={handleSearchChange}
          onFocus={handleFocus}
          onRestaurantSelect={handleRestaurantSelect}
        />

        {/* Selected Restaurant Display */}
        {selectedRestaurant && (
          <SelectedRestaurantDisplay
            selectedRestaurant={selectedRestaurant}
          />
        )}

        {/* Add Restaurant Section */}
        {!selectedRestaurant && (
          <div className="mt-6">
            {/* Show "Add Restaurant" button or form */}
            {!showAddForm ? (
              <div className="space-y-4">
                {showNotFound && (
                  <div className="text-center py-4">
                    <p className="text-slate-600 mb-4">Restaurant not found in our database.</p>
                  </div>
                )}
                <Button
                  onClick={() => setShowAddForm(true)}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add New Restaurant
                </Button>
                
                {/* Continue Without Restaurant Option */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-slate-200" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="bg-white px-2 text-slate-500">or</span>
                  </div>
                </div>
                
                <Button
                  onClick={handleContinueWithoutRestaurant}
                  variant="outline"
                  className="w-full border-slate-300 text-slate-600 hover:bg-slate-50 flex items-center gap-2"
                >
                  <ArrowRight className="w-4 h-4" />
                  Continue Without Restaurant Selection
                </Button>
                
                <p className="text-xs text-slate-500 text-center">
                  Menu analysis will be temporary for this session only
                </p>
              </div>
            ) : (
              <AddRestaurantForm
                onRestaurantAdded={handleRestaurantAdded}
                onCancel={handleCancelAddForm}
              />
            )}
          </div>
        )}

        {/* Consolidated Action Section */}
        <RestaurantSearchActions
          selectedRestaurant={selectedRestaurant}
          showNotFound={showNotFound}
          onContinueToMenu={onContinueToMenu}
        />
      </div>
    </div>
  );
};

export default RestaurantSearch;
