
import React from 'react';
import { Wine } from 'lucide-react';

interface WineStyleData {
  style: string;
  count: number;
  percentage: number;
}

interface WineStyleChartProps {
  data: WineStyleData[];
}

const COLORS = ['#9333EA', '#EC4899', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6'];

const WineStyleChart: React.FC<WineStyleChartProps> = ({ data }) => {
  console.log('WineStyleChart received data:', data);

  // Safety check for data
  if (!data || !Array.isArray(data) || data.length === 0) {
    console.log('WineStyleChart: No valid data provided');
    return (
      <div className="text-center text-slate-500 py-12">
        <Wine className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>Add wines to your library to see style preferences</p>
      </div>
    );
  }

  // Validate data structure
  const validData = data.filter(item => 
    item && 
    typeof item.style === 'string' && 
    typeof item.count === 'number' && 
    typeof item.percentage === 'number' &&
    item.count > 0
  );

  console.log('WineStyleChart: Valid data after filtering:', validData);

  if (validData.length === 0) {
    console.log('WineStyleChart: No valid data items after filtering');
    return (
      <div className="text-center text-slate-500 py-12">
        <Wine className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>Add wines to your library to see style preferences</p>
      </div>
    );
  }

  // Create pie chart segments
  const total = validData.reduce((sum, item) => sum + item.count, 0);
  let currentAngle = 0;
  const radius = 80;
  const centerX = 120;
  const centerY = 120;

  const segments = validData.map((item, index) => {
    const percentage = (item.count / total) * 100;
    const startAngle = currentAngle;
    const endAngle = currentAngle + (percentage / 100) * 360;
    currentAngle = endAngle;

    // Convert angles to radians
    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;

    // Calculate path coordinates
    const x1 = centerX + radius * Math.cos(startRad);
    const y1 = centerY + radius * Math.sin(startRad);
    const x2 = centerX + radius * Math.cos(endRad);
    const y2 = centerY + radius * Math.sin(endRad);

    const largeArcFlag = percentage > 50 ? 1 : 0;

    const pathData = [
      `M ${centerX} ${centerY}`,
      `L ${x1} ${y1}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`,
      'Z'
    ].join(' ');

    return {
      ...item,
      pathData,
      color: COLORS[index % COLORS.length],
      percentage: Math.round(percentage)
    };
  });

  return (
    <div className="h-64 flex flex-col items-center">
      <div className="flex-1 flex items-center justify-center">
        <svg width="240" height="240" viewBox="0 0 240 240">
          {segments.map((segment, index) => (
            <g key={index}>
              <path
                d={segment.pathData}
                fill={segment.color}
                stroke="white"
                strokeWidth="2"
                className="hover:opacity-80 transition-opacity cursor-pointer"
              />
            </g>
          ))}
        </svg>
      </div>
      
      {/* Legend */}
      <div className="grid grid-cols-2 gap-2 mt-4 w-full max-w-md">
        {segments.map((segment, index) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div 
              className="w-3 h-3 rounded-full flex-shrink-0"
              style={{ backgroundColor: segment.color }}
            />
            <span className="text-slate-700 truncate">
              {segment.style} ({segment.count})
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WineStyleChart;
