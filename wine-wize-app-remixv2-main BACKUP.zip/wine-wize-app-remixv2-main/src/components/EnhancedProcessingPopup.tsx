
import React, { useState, useEffect } from 'react';
import { Loader2, Wine, Lightbulb, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';

interface EnhancedProcessingPopupProps {
  isOpen: boolean;
  onClose: () => void;
  currentStep: string;
  progress: number;
  menuCount?: number;
  wineCount?: number;
}

interface WineTip {
  id: string;
  tip_text: string;
  category: string | null;
}

const EnhancedProcessingPopup = ({ 
  isOpen, 
  onClose, 
  currentStep, 
  progress,
  menuCount = 0,
  wineCount = 0 
}: EnhancedProcessingPopupProps) => {
  const [currentTip, setCurrentTip] = useState<WineTip | null>(null);
  const [allTips, setAllTips] = useState<WineTip[]>([]);
  const [showTips, setShowTips] = useState(false);
  const [tipIndex, setTipIndex] = useState(0);
  const [processingTime, setProcessingTime] = useState(0);

  useEffect(() => {
    if (!isOpen) {
      setShowTips(false);
      setProcessingTime(0);
      setTipIndex(0);
      setCurrentTip(null);
      return;
    }

    // Start processing timer
    const timer = setInterval(() => {
      setProcessingTime(prev => prev + 1);
    }, 1000);

    // Show tips after 5 seconds
    const tipsTimer = setTimeout(() => {
      setShowTips(true);
      fetchWineTips();
    }, 5000);

    return () => {
      clearInterval(timer);
      clearTimeout(tipsTimer);
    };
  }, [isOpen]);

  // Cycle tips every 10 seconds
  useEffect(() => {
    if (!showTips || allTips.length === 0) return;

    const cycleTimer = setInterval(() => {
      setTipIndex(prev => (prev + 1) % allTips.length);
    }, 10000);

    return () => clearInterval(cycleTimer);
  }, [showTips, allTips.length]);

  // Update current tip when index changes
  useEffect(() => {
    if (allTips.length > 0) {
      setCurrentTip(allTips[tipIndex]);
    }
  }, [tipIndex, allTips]);

  const fetchWineTips = async () => {
    try {
      const { data, error } = await supabase
        .from('quick_vino_tips')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (error) {
        console.error('Error fetching wine tips:', error);
        return;
      }

      if (data && data.length > 0) {
        // Shuffle tips for variety
        const shuffled = [...data].sort(() => Math.random() - 0.5);
        setAllTips(shuffled);
        setCurrentTip(shuffled[0]);
      }
    } catch (error) {
      console.error('Error fetching wine tips:', error);
    }
  };

  const getProcessingMessage = () => {
    switch (currentStep) {
      case 'preparing':
        return 'Preparing your images...';
      case 'converting':
        return 'Converting images...';
      case 'analyzing':
        return 'Analyzing menu content...';
      case 'complete':
        return 'Analysis complete!';
      default:
        return 'Processing your images...';
    }
  };

  if (!showTips) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md bg-white border border-purple-200">
          <div className="text-center py-8">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Loader2 className="w-10 h-10 text-purple-600 animate-spin" />
            </div>
            
            <h3 className="text-2xl font-bold text-slate-800 mb-3">
              Processing Your Images
            </h3>
            
            <p className="text-lg text-purple-600 font-medium mb-6">
              {getProcessingMessage()}
            </p>

            {(menuCount > 0 || wineCount > 0) && (
              <div className="bg-purple-50 rounded-lg p-4 mb-6">
                <p className="text-sm text-slate-600">
                  Processing {menuCount} menu image{menuCount !== 1 ? 's' : ''} 
                  {menuCount > 0 && wineCount > 0 ? ' and ' : ''}
                  {wineCount > 0 && `${wineCount} wine list image${wineCount !== 1 ? 's' : ''}`}
                </p>
              </div>
            )}

            {/* Progress Bar */}
            <div className="w-full bg-purple-100 rounded-full h-3 mb-4">
              <div 
                className="bg-gradient-to-r from-purple-600 to-pink-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            
            <div className="text-sm text-slate-500">
              Processing time: {processingTime}s
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-white border border-purple-200">
        <div className="text-center py-8">
          <div className="w-20 h-20 bg-gradient-to-br from-amber-100 to-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lightbulb className="w-10 h-10 text-amber-600" />
          </div>
          
          <h3 className="text-2xl font-bold text-slate-800 mb-4">
            Quick Vino Tip!
          </h3>
          
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-6 mb-6">
            <p className="text-slate-700 text-lg leading-relaxed">
              {currentTip?.tip_text || 'Loading tip...'}
            </p>
            {currentTip?.category && (
              <div className="mt-4">
                <span className="inline-block bg-purple-200 text-purple-800 text-sm px-3 py-1 rounded-full font-medium">
                  {currentTip.category}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-center gap-3 mb-6">
            <Loader2 className="w-5 h-5 text-purple-600 animate-spin" />
            <span className="text-slate-600">
              Still processing... {processingTime}s
            </span>
          </div>

          {allTips.length > 1 && (
            <div className="text-sm text-slate-500">
              Tip {tipIndex + 1} of {allTips.length} • New tip every 10 seconds
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EnhancedProcessingPopup;
