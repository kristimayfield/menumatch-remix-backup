
import React from 'react';
import ProgressSteps from './ProgressSteps';
import Header from './Header';
import BackButton from './navigation/BackButton';

const DishesHeader = () => {
  return (
    <div className="pb-32 md:pb-8">
      <Header />
      <div className="container mx-auto px-4 py-8 pt-28 max-w-4xl">
        {/* Header with centered title and left-aligned back button */}
        <div className="relative flex items-center justify-center mb-8">
          <div className="absolute left-0">
            <BackButton fallbackPath="/upload" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Select Dishes</h1>
        </div>

        {/* Progress Steps */}
        <ProgressSteps currentStep={4} />

        {/* Main Content */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-purple-600 mb-4 flex items-center justify-center gap-2">
            🍽️✨ Choose Your Dishes
          </h2>
          <p className="text-slate-600 text-lg mb-4">
            Select up to 4 menu items to get personalized wine pairing recommendations crafted by AI sommelier expertise.
          </p>
        </div>
      </div>
    </div>
  );
};

export default DishesHeader;
