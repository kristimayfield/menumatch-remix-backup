
import React, { useState } from 'react';
import { Wine, Users, Loader2, ChefHat } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

interface ConsolidatedPairingCardProps {
  selectedDishes: string[];
  onPairingsGenerated: (pairings: any[]) => void;
}

const ConsolidatedPairingCard = ({ selectedDishes, onPairingsGenerated }: ConsolidatedPairingCardProps) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const generateConsolidatedPairings = async () => {
    if (selectedDishes.length === 0) {
      toast({
        title: "No dishes selected",
        description: "Please select dishes first to get consolidated recommendations.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);

    try {
      // Get session data
      const sessionResults = sessionStorage.getItem('currentSessionResults');
      if (!sessionResults) {
        throw new Error('No session data found');
      }

      const parsedResults = JSON.parse(sessionResults);
      
      // Get selected dish details
      const selectedDishDetails = parsedResults.menuItems.filter((item: any) => 
        selectedDishes.includes(item.id)
      );

      // Get available wines
      const availableWines = parsedResults.wines || [];

      if (availableWines.length === 0) {
        toast({
          title: "No wines available",
          description: "No wines found for pairing recommendations.",
          variant: "destructive",
        });
        return;
      }

      // Get user preferences
      let userPreferences = null;
      try {
        const { data: preferences } = await supabase
          .from('wine_preferences')
          .select('*')
          .eq('user_id', user?.id)
          .single();
        
        userPreferences = preferences;
      } catch (error) {
        console.log('No wine preferences found, using defaults');
      }

      // Get session for authorization
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('No valid session found');
      }

      // Call wine pairing function with consolidated mode
      const { data, error } = await supabase.functions.invoke('wine-pairing-fast', {
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
        body: {
          dishes: selectedDishDetails.map(dish => ({
            id: dish.id,
            name: dish.dish_name,
            description: dish.description,
            price: dish.price,
            ingredients: dish.ingredients,
            type: dish.dish_type
          })),
          availableWines: availableWines,
          userPreferences: userPreferences,
          budget: userPreferences?.budget || 50,
          restaurantName: parsedResults.restaurantName,
          restaurantId: parsedResults.restaurantId,
          consolidatedMode: true // This triggers the consolidated analysis
        }
      });

      if (error) {
        throw new Error(`Pairing generation failed: ${error.message}`);
      }

      if (!data || !data.success) {
        throw new Error(data?.error || 'Failed to generate consolidated pairings');
      }

      console.log('Consolidated pairings generated:', data.pairings);
      onPairingsGenerated(data.pairings);

      toast({
        title: "Table recommendations ready!",
        description: `Found ${data.pairings?.length || 0} wines that pair perfectly with all your dishes`,
      });

    } catch (error) {
      console.error('Error generating consolidated pairings:', error);
      
      toast({
        title: "Generation failed",
        description: error.message || "Failed to generate table recommendations. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-4 md:p-6 mb-8">
      <div className="flex flex-col md:flex-row md:items-start gap-3 md:gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-amber-100 to-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mx-auto md:mx-0">
          <Users className="w-6 h-6 text-amber-600" />
        </div>
        
        <div className="flex-1 text-center md:text-left">
          <h3 className="text-lg md:text-xl font-bold text-amber-800 mb-2">
            🍽️ Ordering for the Table?
          </h3>
          
          <p className="text-amber-700 mb-4 leading-relaxed text-sm md:text-base">
            Get wine recommendations that complement <strong>all your selected dishes</strong> perfectly. 
            Ideal when you're sharing one or two bottles for the entire table!
          </p>

          {selectedDishes.length > 0 && (
            <div className="bg-white/50 rounded-lg p-3 mb-4">
              <p className="text-sm text-amber-700 flex flex-col md:flex-row items-center justify-center md:justify-start gap-1 md:gap-2">
                <ChefHat className="w-4 h-4" />
                <span>Analyzing {selectedDishes.length} selected dish{selectedDishes.length > 1 ? 'es' : ''} for table pairing</span>
              </p>
            </div>
          )}
          
          <Button
            onClick={generateConsolidatedPairings}
            disabled={isGenerating || selectedDishes.length === 0}
            className="w-full md:w-auto bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-semibold px-4 md:px-6 py-3 text-sm md:text-base"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                <span className="hidden md:inline">Analyzing Table Pairings...</span>
                <span className="md:hidden">Analyzing...</span>
              </>
            ) : (
              <>
                <Wine className="w-4 h-4 mr-2" />
                <span className="hidden md:inline">Get Table Wine Recommendations</span>
                <span className="md:hidden">Get Table Wines</span>
              </>
            )}
          </Button>
          
          {selectedDishes.length === 0 && (
            <p className="text-xs md:text-sm text-amber-600 mt-2">
              Please select some dishes first to get table recommendations
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ConsolidatedPairingCard;
