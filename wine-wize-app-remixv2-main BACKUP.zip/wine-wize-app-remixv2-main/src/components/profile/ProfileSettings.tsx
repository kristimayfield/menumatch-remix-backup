
import React from 'react';
import { Link } from 'react-router-dom';
import { Settings, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

const ProfileSettings: React.FC = () => {
  const { openCustomerPortal, subscriptionInfo } = useAuth();

  const handleManageSubscription = async () => {
    const result = await openCustomerPortal();
    if (result.url) {
      window.open(result.url, '_blank');
    } else if (result.error) {
      console.error('Portal error:', result.error);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
      <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
        <Settings className="w-5 h-5" />
        Settings
      </h3>
      
      <div className="space-y-3">
        <Link to="/wine-preferences">
          <Button variant="outline" className="w-full justify-start">
            Wine Preferences
          </Button>
        </Link>
        {subscriptionInfo.subscribed && (
          <Button 
            variant="outline" 
            className="w-full justify-start"
            onClick={handleManageSubscription}
          >
            <Crown className="w-4 h-4 mr-2" />
            Manage Subscription
          </Button>
        )}
        <Button variant="outline" className="w-full justify-start">
          Notifications
        </Button>
        <Button variant="outline" className="w-full justify-start">
          Account Settings
        </Button>
      </div>
    </div>
  );
};

export default ProfileSettings;
