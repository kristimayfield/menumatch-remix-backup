
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProgressSteps from '@/components/ProgressSteps';
import Header from '@/components/Header';
import BackButton from '@/components/navigation/BackButton';

const UploadHeader = () => {
  const navigate = useNavigate();

  const startOver = () => {
    navigate('/welcome');
  };

  return (
    <div className="pb-32 md:pb-8">
      <Header />
      <div className="container mx-auto px-4 py-8 pt-28">
        {/* Header with centered title and left-aligned back button */}
        <div className="relative flex items-center justify-center mb-8">
          <div className="absolute left-0">
            <BackButton fallbackPath="/restaurant" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Upload</h1>
          <div className="absolute right-0">
            <Button 
              onClick={startOver}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              Start Over
            </Button>
          </div>
        </div>

        <ProgressSteps currentStep={3} />
      </div>
    </div>
  );
};

export default UploadHeader;
